/**
 * Navigation FSM（导航状态机）（规范要求）
 * 标准化导航状态流转：开始 → 运行 → 暂停 → 恢复 → 完成
 */

(function() {
    'use strict';

    /**
     * 导航状态枚举
     */
    const NavState = {
        IDLE: "IDLE",
        STARTING: "STARTING",
        ACTIVE: "ACTIVE",
        PAUSED: "PAUSED",
        RECOVERING: "RECOVERING",
        FINISHED: "FINISHED"
    };

    window.NavigationFSM = {
        state: NavState.IDLE,
        startTime: null,
        pauseTime: null,
        history: [],
        maxHistory: 50,
        
        /**
         * 开始导航
         */
        start(destination = null) {
            if (this.state === NavState.ACTIVE) {
                console.warn('⚠️ [NavigationFSM] 导航已在进行中', { module: 'navigation_fsm' });
                return false;
            }
            
            const oldState = this.state;
            this.state = NavState.STARTING;
            this.startTime = Date.now();
            
            console.log(`🔄 [NavigationFSM] 状态转换: ${oldState} → ${NavState.STARTING}`, { module: 'navigation_fsm' });
            
            // 记录历史
            this._recordTransition(oldState, NavState.STARTING, { destination });
            
            // 短暂延迟后进入ACTIVE状态（模拟启动过程）
            setTimeout(() => {
                if (this.state === NavState.STARTING) {
                    this.state = NavState.ACTIVE;
                    console.log(`✅ [NavigationFSM] 状态转换: ${NavState.STARTING} → ${NavState.ACTIVE}`, { module: 'navigation_fsm' });
                    this._recordTransition(NavState.STARTING, NavState.ACTIVE, { destination });
                    
                    // 触发情绪事件
                    if (window.emotion_event) {
                        window.emotion_event('navigation_started', 'medium', { destination });
                    }
                }
            }, 100);
            
            return true;
        },
        
        /**
         * 暂停导航
         */
        pause(reason = "用户暂停") {
            if (this.state !== NavState.ACTIVE) {
                console.warn(`⚠️ [NavigationFSM] 无法暂停，当前状态: ${this.state}`, { module: 'navigation_fsm' });
                return false;
            }
            
            const oldState = this.state;
            this.state = NavState.PAUSED;
            this.pauseTime = Date.now();
            
            console.log(`⏸️ [NavigationFSM] 状态转换: ${oldState} → ${NavState.PAUSED} (原因: ${reason})`, { module: 'navigation_fsm' });
            this._recordTransition(oldState, NavState.PAUSED, { reason });
            
            // 触发情绪事件
            if (window.emotion_event) {
                window.emotion_event('navigation_paused', 'medium', { reason });
            }
            
            return true;
        },
        
        /**
         * 恢复导航
         */
        resume() {
            if (this.state !== NavState.PAUSED) {
                console.warn(`⚠️ [NavigationFSM] 无法恢复，当前状态: ${this.state}`, { module: 'navigation_fsm' });
                return false;
            }
            
            const oldState = this.state;
            this.state = NavState.RECOVERING;
            
            console.log(`🔄 [NavigationFSM] 状态转换: ${oldState} → ${NavState.RECOVERING}`, { module: 'navigation_fsm' });
            this._recordTransition(oldState, NavState.RECOVERING, {});
            
            // 短暂延迟后进入ACTIVE状态
            setTimeout(() => {
                if (this.state === NavState.RECOVERING) {
                    this.state = NavState.ACTIVE;
                    const pauseDuration = this.pauseTime ? Date.now() - this.pauseTime : 0;
                    this.pauseTime = null;
                    
                    console.log(`✅ [NavigationFSM] 状态转换: ${NavState.RECOVERING} → ${NavState.ACTIVE}`, { module: 'navigation_fsm' });
                    this._recordTransition(NavState.RECOVERING, NavState.ACTIVE, { pauseDuration });
                    
                    // 触发情绪事件
                    if (window.emotion_event) {
                        window.emotion_event('navigation_resumed', 'medium', { pauseDuration });
                    }
                }
            }, 100);
            
            return true;
        },
        
        /**
         * 完成导航
         */
        finish(success = true) {
            if (this.state !== NavState.ACTIVE && this.state !== NavState.PAUSED) {
                console.warn(`⚠️ [NavigationFSM] 无法完成，当前状态: ${this.state}`, { module: 'navigation_fsm' });
                return false;
            }
            
            const oldState = this.state;
            this.state = NavState.FINISHED;
            const duration = this.startTime ? Date.now() - this.startTime : 0;
            
            console.log(`🏁 [NavigationFSM] 状态转换: ${oldState} → ${NavState.FINISHED} (成功: ${success}, 耗时: ${duration}ms)`, { module: 'navigation_fsm' });
            this._recordTransition(oldState, NavState.FINISHED, { success, duration });
            
            // 触发情绪事件
            if (window.emotion_event) {
                window.emotion_event('navigation_completed', 'medium', { success, duration });
            }
            
            return true;
        },
        
        /**
         * 重置状态机
         */
        reset() {
            const oldState = this.state;
            this.state = NavState.IDLE;
            this.startTime = null;
            this.pauseTime = null;
            
            console.log(`🔄 [NavigationFSM] 状态重置: ${oldState} → ${NavState.IDLE}`, { module: 'navigation_fsm' });
            this._recordTransition(oldState, NavState.IDLE, { reason: 'reset' });
        },
        
        /**
         * 处理导航事件
         */
        handleEvent(navData) {
            if (!navData) {
                return;
            }
            
            // 根据事件数据更新状态（如果需要）
            const { action, direction, distance } = navData;
            
            // 如果导航完成
            if (action === 'stop' || action === 'complete') {
                if (this.state === NavState.ACTIVE) {
                    this.finish(true);
                }
            }
            
            // 记录事件（用于状态机日志）
            this._recordEvent(navData);
        },
        
        /**
         * 记录状态转换
         */
        _recordTransition(from, to, meta) {
            this.history.push({
                type: 'transition',
                from,
                to,
                timestamp: Date.now(),
                meta
            });
            
            if (this.history.length > this.maxHistory) {
                this.history.shift();
            }
        },
        
        /**
         * 记录事件
         */
        _recordEvent(eventData) {
            this.history.push({
                type: 'event',
                state: this.state,
                data: eventData,
                timestamp: Date.now()
            });
            
            if (this.history.length > this.maxHistory) {
                this.history.shift();
            }
        },
        
        /**
         * 获取当前状态信息
         */
        getState() {
            return {
                state: this.state,
                startTime: this.startTime,
                pauseTime: this.pauseTime,
                duration: this.startTime ? Date.now() - this.startTime : 0,
                pauseDuration: this.pauseTime ? Date.now() - this.pauseTime : 0
            };
        },
        
        /**
         * 获取历史记录
         */
        getHistory(limit = 10) {
            return this.history.slice(-limit);
        }
    };
    
    console.log('✅ NavigationFSM模块加载完成', { module: 'navigation_fsm' });
})();


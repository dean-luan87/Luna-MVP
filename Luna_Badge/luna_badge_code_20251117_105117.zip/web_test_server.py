#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Luna Badge 完整功能测试服务器
支持所有核心功能的手机端测试
"""

import os
import sys
import logging
import base64
import io
import tempfile
import time
from flask import Flask, request, jsonify, render_template_string, send_file
from flask_cors import CORS
import cv2
import numpy as np
from PIL import Image
from typing import Dict, Any, List, Optional

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# 全局模块
vision_engine = None
step_detector = None
signboard_detector = None
hazard_detector = None
whisper_recognizer = None
# 快速TTS缓存系统
fast_tts_cache = None

def init_fast_tts_cache():
    """初始化快速TTS缓存系统"""
    global fast_tts_cache
    try:
        from core.fast_tts_cache import FastTTSCache
        fast_tts_cache = FastTTSCache(cache_dir="tts_cache")
        logger.info("✅ 快速TTS缓存系统初始化成功", extra={"module": "tts", "meta": {"component": "fast_tts_cache"}})
        
        # 后台预生成常用短语（不阻塞）
        import threading
        import asyncio
        def pregenerate():
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(fast_tts_cache.pregenerate_common_phrases())
                loop.close()
            except Exception as e:
                logger.warning(f"⚠️ 预生成常用短语失败: {e}", extra={"module": "tts", "meta": {"component": "fast_tts_cache", "operation": "pregenerate"}})
        
        thread = threading.Thread(target=pregenerate, daemon=True)
        thread.start()
        logger.info("🔄 后台预生成常用短语已启动", extra={"module": "tts", "meta": {"component": "fast_tts_cache"}})
        
    except Exception as e:
        logger.warning(f"⚠️ 快速TTS缓存系统初始化失败: {e}", extra={"module": "tts", "meta": {"component": "fast_tts_cache", "error": str(e)}})
        fast_tts_cache = None
path_planner = None
navigation_manager = None
scene_memory_system = None
facility_detector = None
traffic_light_detector = None
crowd_density_detector = None
queue_detector = None
doorplate_reader = None
local_map_generator = None
log_manager = None  # 日志管理器

# 实时响应系统
time_sync_bus = None
rt_scheduler = None
policy_graph = None
vision_state_estimator = None
audio_state_estimator = None
graceful_degrader = None
performance_metrics = {
    'vision_latency': [],
    'audio_latency': [],
    'memory_usage': [],
    'fps': []
}

# 可借鉴代码模块（视角+语音导航优化）
saliency_roi = None  # 显著性ROI提取（STAViS）
temporal_fusion = None  # 时序融合（BEVFormer）
visual_language_fusion = None  # 视觉-语言融合（Talk2Nav）
visual_localization = None  # 视觉定位（ORB-SLAM2）

def init_all_modules():
    """初始化所有模块"""
    global vision_engine, step_detector, signboard_detector, hazard_detector
    global whisper_recognizer, tts_manager
    global path_planner, navigation_manager, scene_memory_system
    global facility_detector, traffic_light_detector, crowd_density_detector
    global queue_detector, doorplate_reader, local_map_generator
    global log_manager
    global saliency_roi, temporal_fusion, visual_language_fusion, visual_localization
    global unified_vision_engine
    
    success_count = 0
    
    # 1. 视觉OCR引擎
    try:
        from core.vision_ocr_engine import VisionOCREngine
        logger.info("正在初始化视觉OCR引擎...", extra={"module": "vision", "meta": {"component": "vision_ocr_engine"}})
        vision_engine = VisionOCREngine(use_yolo=True, use_ocr=True, yolo_imgsz=1280)
        if vision_engine.load_models():
            logger.info("✅ 视觉OCR引擎初始化成功", extra={"module": "vision", "meta": {"component": "vision_ocr_engine"}})
            success_count += 1
        else:
            logger.warning("⚠️ 视觉OCR引擎初始化失败", extra={"module": "vision", "meta": {"component": "vision_ocr_engine"}})
    except Exception as e:
        logger.warning(f"⚠️ 视觉OCR引擎初始化异常: {e}", extra={"module": "vision", "meta": {"component": "vision_ocr_engine", "error": str(e)}})
    
    # 2. 台阶检测器
    try:
        from core.step_detector import StepDetector
        logger.info("正在初始化台阶检测器...", extra={"module": "vision", "meta": {"component": "step_detector"}})
        step_detector = StepDetector()
        logger.info("✅ 台阶检测器初始化成功", extra={"module": "vision", "meta": {"component": "step_detector"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 台阶检测器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "step_detector", "error": str(e)}})
    
    # 3. 标识牌检测器
    try:
        from core.signboard_detector import SignboardDetector
        logger.info("正在初始化标识牌检测器...", extra={"module": "vision", "meta": {"component": "signboard_detector"}})
        signboard_detector = SignboardDetector()
        logger.info("✅ 标识牌检测器初始化成功", extra={"module": "vision", "meta": {"component": "signboard_detector"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 标识牌检测器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "signboard_detector", "error": str(e)}})
    
    # 4. 危险检测器
    try:
        from core.hazard_detector import HazardDetector
        logger.info("正在初始化危险检测器...", extra={"module": "vision", "meta": {"component": "hazard_detector"}})
        hazard_detector = HazardDetector()
        logger.info("✅ 危险检测器初始化成功", extra={"module": "vision", "meta": {"component": "hazard_detector"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 危险检测器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "hazard_detector", "error": str(e)}})
    
    # 5. 语音识别器（延迟加载）
    try:
        from core.whisper_recognizer import WhisperRecognizer
        logger.info("语音识别器将在首次使用时加载...")
        whisper_recognizer = WhisperRecognizer(model_name="base", language="zh")
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 语音识别器初始化异常: {e}")
    
    # 6. TTS管理器
    try:
        from core.tts_manager import TTSManager
        logger.info("正在初始化TTS管理器...", extra={"module": "tts", "meta": {"component": "tts_manager"}})
        tts_manager = TTSManager()
        logger.info("✅ TTS管理器初始化成功", extra={"module": "tts", "meta": {"component": "tts_manager"}})
        
        # 设置全局TTS管理器（规范要求）
        try:
            from backend.tts.unified_tts import set_tts_manager
            set_tts_manager(tts_manager)
            logger.info("✅ 统一TTS接口已设置", extra={"module": "tts", "meta": {"component": "unified_tts"}})
        except Exception as e:
            logger.warning(f"⚠️ 统一TTS接口设置失败: {e}", extra={"module": "tts", "meta": {"component": "unified_tts", "error": str(e)}})
        
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ TTS管理器初始化异常: {e}", extra={"module": "tts", "meta": {"component": "tts_manager", "error": str(e)}})
    
    # 7. 场景记忆系统（导航基础）
    try:
        from core.scene_memory_system import get_scene_memory_system
        logger.info("正在初始化场景记忆系统...", extra={"module": "navigation", "meta": {"component": "scene_memory_system"}})
        scene_memory_system = get_scene_memory_system()
        logger.info("✅ 场景记忆系统初始化成功", extra={"module": "navigation", "meta": {"component": "scene_memory_system"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 场景记忆系统初始化异常: {e}", extra={"module": "navigation", "meta": {"component": "scene_memory_system", "error": str(e)}})
    
    # 8. 路径规划器
    try:
        from core.path_planner import PathPlanner
        logger.info("正在初始化路径规划器...", extra={"module": "navigation", "meta": {"component": "path_planner"}})
        if scene_memory_system:
            path_planner = PathPlanner(scene_memory_system)
            logger.info("✅ 路径规划器初始化成功", extra={"module": "navigation", "meta": {"component": "path_planner"}})
            success_count += 1
        else:
            logger.warning("⚠️ 场景记忆系统未初始化，跳过路径规划器", extra={"module": "navigation", "meta": {"component": "path_planner"}})
    except Exception as e:
        logger.warning(f"⚠️ 路径规划器初始化异常: {e}", extra={"module": "navigation", "meta": {"component": "path_planner", "error": str(e)}})
    
    # 初始化快速TTS缓存系统
    init_fast_tts_cache()
    try:
        from core.navigation_manager import NavigationManager
        logger.info("正在初始化导航管理器...", extra={"module": "navigation", "meta": {"component": "navigation_manager"}})
        
        # 定义TTS播报回调函数
        def tts_broadcast_callback(text: str, style: str = "calm"):
            """TTS播报回调"""
            if tts_manager:
                try:
                    # 异步播报，不阻塞导航
                    import threading
                    def async_speak():
                        try:
                            tts_manager.speak(text, style)
                        except Exception as e:
                            logger.warning(f"⚠️ TTS播报失败: {e}", extra={"module": "tts", "meta": {"component": "tts_broadcast", "error": str(e)}})
                    thread = threading.Thread(target=async_speak)
                    thread.daemon = True
                    thread.start()
                except Exception as e:
                    logger.warning(f"⚠️ TTS播报线程启动失败: {e}", extra={"module": "tts", "meta": {"component": "tts_broadcast", "error": str(e)}})
            else:
                logger.info(f"🔊 [模拟播报] {text} (风格: {style})", extra={"module": "tts", "meta": {"component": "tts_broadcast", "style": style}})
        
        navigation_manager = NavigationManager(tts_callback=tts_broadcast_callback)
        logger.info("✅ 导航管理器初始化成功（已启用语音播报）", extra={"module": "navigation", "meta": {"component": "navigation_manager"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 导航管理器初始化异常: {e}", extra={"module": "navigation", "meta": {"component": "navigation_manager", "error": str(e)}})
    
    # 10. 公共设施检测器
    try:
        from core.facility_detector import FacilityDetector
        logger.info("正在初始化公共设施检测器...", extra={"module": "vision", "meta": {"component": "facility_detector"}})
        facility_detector = FacilityDetector()
        logger.info("✅ 公共设施检测器初始化成功", extra={"module": "vision", "meta": {"component": "facility_detector"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 公共设施检测器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "facility_detector", "error": str(e)}})
    
    # 11. 红绿灯检测器
    try:
        from core.traffic_light_detector import TrafficLightDetector
        logger.info("正在初始化红绿灯检测器...", extra={"module": "vision", "meta": {"component": "traffic_light_detector"}})
        traffic_light_detector = TrafficLightDetector()
        logger.info("✅ 红绿灯检测器初始化成功", extra={"module": "vision", "meta": {"component": "traffic_light_detector"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 红绿灯检测器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "traffic_light_detector", "error": str(e)}})
    
    # 12. 人群密度检测器
    try:
        from core.crowd_density_detector import CrowdDensityDetector
        logger.info("正在初始化人群密度检测器...", extra={"module": "vision", "meta": {"component": "crowd_density_detector"}})
        crowd_density_detector = CrowdDensityDetector()
        logger.info("✅ 人群密度检测器初始化成功", extra={"module": "vision", "meta": {"component": "crowd_density_detector"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 人群密度检测器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "crowd_density_detector", "error": str(e)}})
    
    # 13. 排队检测器
    try:
        from core.queue_detector import QueueDetector
        logger.info("正在初始化排队检测器...", extra={"module": "vision", "meta": {"component": "queue_detector"}})
        queue_detector = QueueDetector()
        logger.info("✅ 排队检测器初始化成功", extra={"module": "vision", "meta": {"component": "queue_detector"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 排队检测器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "queue_detector", "error": str(e)}})
    
    # 14. 门牌号识别器
    try:
        from core.doorplate_reader import DoorplateReader
        logger.info("正在初始化门牌号识别器...", extra={"module": "vision", "meta": {"component": "doorplate_reader"}})
        doorplate_reader = DoorplateReader()
        logger.info("✅ 门牌号识别器初始化成功", extra={"module": "vision", "meta": {"component": "doorplate_reader"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 门牌号识别器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "doorplate_reader", "error": str(e)}})
    
    # 15. 本地地图生成器
    try:
        from core.local_map_generator import LocalMapGenerator
        logger.info("正在初始化本地地图生成器...", extra={"module": "navigation", "meta": {"component": "local_map_generator"}})
        local_map_generator = LocalMapGenerator()
        logger.info("✅ 本地地图生成器初始化成功", extra={"module": "navigation", "meta": {"component": "local_map_generator"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 本地地图生成器初始化异常: {e}", extra={"module": "navigation", "meta": {"component": "local_map_generator", "error": str(e)}})
    
    # 16. 日志管理器
    try:
        from core.log_manager import LogManager
        logger.info("正在初始化日志管理器...", extra={"module": "system", "meta": {"component": "log_manager"}})
        log_manager = LogManager(user_id="web_test_user", log_dir="logs/web_test")
        logger.info("✅ 日志管理器初始化成功", extra={"module": "system", "meta": {"component": "log_manager"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 日志管理器初始化异常: {e}", extra={"module": "system", "meta": {"component": "log_manager", "error": str(e)}})
    
    # 17. 实时响应系统
    try:
        from core.realtime_system import (
            get_time_sync_bus, get_rt_scheduler, get_policy_graph,
            StateEstimator, GracefulDegrader
        )
        from core.realtime_policies import DEFAULT_POLICY_RULES
        
        logger.info("正在初始化实时响应系统...")
        time_sync_bus = get_time_sync_bus()
        rt_scheduler = get_rt_scheduler()
        policy_graph = get_policy_graph()
        policy_graph.load_rules(DEFAULT_POLICY_RULES)
        
        # 注册策略动作
        def tts_action(text: str = None):
            """TTS播报动作"""
            if text and tts_manager:
                rt_scheduler.enqueue_high(lambda: tts_manager.speak_sync(text))
        
        def nav_start_action():
            """导航启动动作"""
            logger.info("策略触发：启动导航")
            # 这里可以添加导航启动逻辑
        
        policy_graph.register_actions({
            'tts': tts_action,
            'nav.start': nav_start_action
        })
        
        # 状态估计器
        vision_state_estimator = StateEstimator(alpha=0.7)  # 视觉状态平滑
        audio_state_estimator = StateEstimator(alpha=0.8)   # 音频状态平滑
        
        # 优雅降级器
        def monitor_performance():
            """性能监控回调"""
            try:
                import psutil
                process = psutil.Process()
                memory_mb = process.memory_info().rss / 1024 / 1024
            except:
                memory_mb = 0
            
            # 从调度器获取延迟p95
            scheduler_metrics = rt_scheduler.get_metrics()
            p95 = scheduler_metrics.get('p95', 0)
            
            # 计算FPS
            fps_history = performance_metrics.get('fps', [])
            fps = fps_history[-1] if fps_history else 30
            
            return {'p95': p95, 'heap': memory_mb, 'fps': fps}
        
        def apply_degrade(level):
            """应用降级级别"""
            logger.info(f"📉 应用降级级别: {level.value}")
            # 这里可以根据级别调整检测频率、分辨率等
            # 暂时只记录日志
        
        graceful_degrader = GracefulDegrader(monitor_performance, apply_degrade)
        
        logger.info("✅ 实时响应系统初始化成功", extra={"module": "system", "meta": {"component": "realtime_system"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 实时响应系统初始化异常: {e}", extra={"module": "system", "meta": {"component": "realtime_system", "error": str(e)}})
    
    # 18. 可借鉴代码模块（视角+语音导航优化）
    try:
        from core.saliency_roi import SaliencyROI
        logger.info("正在初始化显著性ROI提取器（STAViS）...", extra={"module": "vision", "meta": {"component": "saliency_roi"}})
        saliency_roi = SaliencyROI()
        logger.info("✅ 显著性ROI提取器初始化成功", extra={"module": "vision", "meta": {"component": "saliency_roi"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 显著性ROI提取器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "saliency_roi", "error": str(e)}})
    
    try:
        from core.temporal_fusion import TemporalFusion
        logger.info("正在初始化时序融合器（BEVFormer）...", extra={"module": "vision", "meta": {"component": "temporal_fusion"}})
        temporal_fusion = TemporalFusion(window_size=3, vote_threshold=2)
        logger.info("✅ 时序融合器初始化成功", extra={"module": "vision", "meta": {"component": "temporal_fusion"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 时序融合器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "temporal_fusion", "error": str(e)}})
    
    try:
        from core.visual_language_fusion import VisualLanguageFusion
        logger.info("正在初始化视觉-语言融合器（Talk2Nav）...", extra={"module": "vision", "meta": {"component": "visual_language_fusion"}})
        visual_language_fusion = VisualLanguageFusion()
        logger.info("✅ 视觉-语言融合器初始化成功", extra={"module": "vision", "meta": {"component": "visual_language_fusion"}})
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 视觉-语言融合器初始化异常: {e}", extra={"module": "vision", "meta": {"component": "visual_language_fusion", "error": str(e)}})
    
    try:
        from core.visual_localization import VisualLocalization
        logger.info("正在初始化视觉定位系统（ORB-SLAM2）...")
        visual_localization = VisualLocalization()
        logger.info("✅ 视觉定位系统初始化成功")
        success_count += 1
    except Exception as e:
        logger.warning(f"⚠️ 视觉定位系统初始化异常: {e}", extra={"module": "vision", "meta": {"component": "visual_localization", "error": str(e)}})
    
    # ========== 初始化统一视觉引擎（规范要求）==========
    try:
        from backend.engines.vision_engine import get_vision_engine
        unified_vision_engine = get_vision_engine(
            vision_ocr_engine=vision_engine,
            step_detector=step_detector,
            signboard_detector=signboard_detector,
            hazard_detector=hazard_detector,
            facility_detector=facility_detector,
            traffic_light_detector=traffic_light_detector,
            crowd_density_detector=crowd_density_detector,
            queue_detector=queue_detector,
            doorplate_reader=doorplate_reader
        )
        logger.info("✅ 统一视觉引擎初始化成功", extra={"module": "vision", "meta": {"component": "unified_vision_engine"}})
    except Exception as e:
        logger.warning(f"⚠️ 统一视觉引擎初始化异常: {e}", extra={"module": "vision", "meta": {"component": "unified_vision_engine", "error": str(e)}})
    
    logger.info(f"✅ 模块初始化完成: {success_count}/21 个模块成功", extra={"module": "system", "meta": {"success_count": success_count, "total_modules": 21}})
    return success_count > 0

def image_to_numpy(image_data):
    """将图片数据转换为numpy数组"""
    try:
        # 处理不同类型的输入
        if isinstance(image_data, str):
            # 如果是base64字符串
            image_data = base64.b64decode(image_data)
        elif hasattr(image_data, 'read'):
            # 如果是文件对象
            image_data = image_data.read()
        
        # 检查数据是否为空
        if not image_data or len(image_data) == 0:
            logger.error("图片数据为空")
            return None
        
        # 尝试打开图片
        try:
            image = Image.open(io.BytesIO(image_data))
        except Exception as e:
            logger.error(f"PIL打开图片失败: {e}, 数据长度: {len(image_data)}")
            # 尝试使用cv2直接读取
            try:
                nparr = np.frombuffer(image_data, np.uint8)
                img_bgr = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                if img_bgr is not None:
                    logger.info("使用cv2.imdecode成功读取图片")
                    return img_bgr
            except Exception as e2:
                logger.error(f"cv2.imdecode也失败: {e2}")
            return None
        
        # 转换颜色模式
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # 转换为numpy数组
        img_array = np.array(image)
        img_bgr = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
        
        logger.debug(f"图片转换成功: 尺寸={img_bgr.shape}")
        return img_bgr
    except Exception as e:
        logger.error(f"图片转换失败: {e}", exc_info=True)
        return None

# HTML模板（完整版）
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <title>Luna 完整功能测试</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 { text-align: center; color: #333; margin-bottom: 20px; font-size: 28px; }
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 2px solid #eee;
        }
        .tab {
            flex: 1;
            padding: 12px;
            text-align: center;
            background: #f5f5f5;
            border: none;
            border-radius: 8px 8px 0 0;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
        }
        .tab.active {
            background: #667eea;
            color: white;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        video { width: 100%; border-radius: 15px; background: #000; }
        canvas { display: none; }
        .btn {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 10px;
            transition: all 0.3s;
        }
        .btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        .btn-secondary { background: #f0f0f0; color: #333; }
        .btn-danger { background: #ff6b6b; color: white; }
        .btn-success { background: #51cf66; color: white; }
        .btn:active { transform: scale(0.98); opacity: 0.9; }
        .file-input { display: none; }
        .result-section {
            margin-top: 20px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 15px;
            display: none;
        }
        .result-section.active { display: block; }
        .result-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
            color: #333;
        }
        .result-item {
            background: white;
            padding: 12px;
            margin-bottom: 8px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }
        .result-text { font-size: 15px; color: #333; margin-bottom: 5px; }
        .result-confidence { font-size: 13px; color: #666; }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            margin-left: 8px;
        }
        .badge-success { background: #51cf66; color: white; }
        .badge-warning { background: #ffd43b; color: #333; }
        .badge-danger { background: #ff6b6b; color: white; }
        .loading {
            text-align: center;
            padding: 20px;
            display: none;
        }
        .loading.active { display: block; }
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 15px;
            border-radius: 10px;
            margin-top: 15px;
            display: none;
        }
        .error.active { display: block; }
        .audio-controls {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        .audio-controls button {
            flex: 1;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌟 Luna 完整功能测试</h1>
        
        <!-- 测试按钮 - 用于验证JavaScript是否工作 -->
        <div id="testButton" style="padding:10px; margin-bottom:10px; background:#fff3cd; border-radius:5px; text-align:center; border:2px solid #ffc107;">
            <button id="testJsButton" style="padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:5px; cursor:pointer; font-size:16px;">
                🧪 点击测试JavaScript是否工作
            </button>
        </div>
        
        <div class="tabs">
            <button class="tab active" data-tab="product">🌟 完整产品模式</button>
            <button class="tab" data-tab="vision">👁️ 视觉识别</button>
            <button class="tab" data-tab="voice">🎤 语音功能</button>
            <button class="tab" data-tab="comprehensive">🔍 综合检测</button>
            <button class="tab" data-tab="navigation">🧭 离线导航</button>
            <button class="tab" data-tab="logs">📊 日志管理</button>
        </div>
        
        <!-- 完整产品模式标签页 -->
        <div id="product-tab" class="tab-content active">
            <div style="background:#e8f5e9; border:2px solid #4CAF50; border-radius:8px; padding:20px; margin-bottom:20px;">
                <h2 style="margin:0 0 15px 0; color:#2E7D32;">🌟 Luna 完整产品模式</h2>
                <div style="font-size:14px; line-height:1.8; color:#1B5E20;">
                    <strong>💡 产品模式说明：</strong><br>
                    • 开启摄像头后自动进入完整模式<br>
                    • 自动视觉识别 + 实时语音播报<br>
                    • 持续语音监听 + 语音对话交互<br>
                    • 自动检测障碍并播报警告<br>
                    • 模拟真实产品使用体验
                </div>
            </div>
            
            <!-- 视频显示区域 -->
            <div style="margin-bottom:20px; text-align:center;">
                <video id="productVideo" autoplay playsinline webkit-playsinline style="width:100%; max-width:640px; border-radius:8px; background:#000;"></video>
                <canvas id="productCanvas" style="display:none;"></canvas>
            </div>
            
            <div style="text-align:center; margin-bottom:20px;">
                <button id="startProductModeBtn" class="btn btn-success" style="width:100%; padding:20px; font-size:20px; font-weight:bold;">
                    🚀 启动完整产品模式
                </button>
                <button id="stopProductModeBtn" class="btn btn-danger" style="width:100%; padding:20px; margin-top:15px; font-size:18px; display:none;">
                    ⏹️ 停止产品模式
                </button>
            </div>
            
            <div id="productModeStatus" style="padding:15px; background:#f5f5f5; border-radius:8px; margin-bottom:15px; display:none;">
                <div style="font-size:16px; font-weight:bold; margin-bottom:10px; color:#4CAF50;">✅ 产品模式运行中</div>
                <div id="productStatusDetails" style="font-size:14px; color:#666;"></div>
                <!-- 调试信息显示区域（iPhone Safari无法使用控制台） -->
                <div id="debugInfo" style="margin-top:15px; padding:10px; background:#fff; border:1px solid #ddd; border-radius:5px; font-size:12px; font-family:monospace; max-height:200px; overflow-y:auto; display:none;">
                    <div style="font-weight:bold; margin-bottom:5px; color:#666;">🔍 调试信息：</div>
                    <div id="debugLog" style="line-height:1.6; color:#333;"></div>
                </div>
            </div>
            
            <div id="productGuidance" style="padding:15px; background:white; border:2px solid #4CAF50; border-radius:8px; margin-bottom:15px; display:none;">
                <div style="font-size:18px; text-align:center; margin-bottom:15px; font-weight:bold;" id="guidanceDirection">⬆️ FORWARD</div>
                <div id="guidanceMessages" style="font-size:14px; line-height:1.8;"></div>
            </div>
            
            <div id="productVoiceStatus" style="padding:15px; background:#e3f2fd; border-radius:8px; margin-bottom:15px; display:none;">
                <div style="font-size:14px; font-weight:bold; margin-bottom:8px;">🎤 语音状态</div>
                <div id="voiceStatusText" style="font-size:13px; color:#1976D2;">正在监听...</div>
                <div id="voiceRecognitionResult" style="margin-top:10px; padding:10px; background:white; border-radius:5px; font-size:13px; display:none;"></div>
                <div id="voicePlaybackStatus" style="margin-top:10px; padding:10px; background:#fff3cd; border-radius:5px; font-size:13px; display:none;">
                    <div style="color:#856404;">🔊 正在播放语音...</div>
                    <div id="playbackText" style="margin-top:5px; color:#666;"></div>
                </div>
            </div>
        </div>
        
        <!-- 视觉识别标签页 -->
        <div id="vision-tab" class="tab-content">
            <div style="background:#fff3cd; border:1px solid #ffc107; border-radius:8px; padding:12px; margin-bottom:15px; font-size:14px; color:#856404;">
                <strong>💡 Safari浏览器提示：</strong><br>
                如果摄像头无法使用，请使用"选择图片"功能上传照片进行识别。
            </div>
            <video id="video" autoplay playsinline webkit-playsinline></video>
            <canvas id="canvas"></canvas>
            
            <button id="startCameraBtn" class="btn btn-primary">📷 打开摄像头</button>
            <button class="btn btn-primary" id="captureBtn" style="display:none;">📸 拍照识别</button>
            <button class="btn btn-secondary" id="stopBtn" style="display:none;">⏹️ 关闭摄像头</button>
            
            <label for="fileInput" class="btn btn-secondary" style="background:#28a745; color:white;">
                📁 选择图片（推荐Safari使用）
            </label>
            <input type="file" id="fileInput" class="file-input" accept="image/*" capture="environment">
            
            <button id="testStepBtn" class="btn btn-success">🪜 台阶检测</button>
            <button id="testSignboardBtn" class="btn btn-success">🚏 标识牌检测</button>
            <button id="testHazardBtn" class="btn btn-danger">⚠️ 危险检测</button>
            <button id="testFacilityBtn" class="btn btn-success">🏛️ 公共设施</button>
            <button id="testTrafficLightBtn" class="btn btn-success">🚦 红绿灯</button>
            <button id="testCrowdDensityBtn" class="btn btn-success">👥 人群密度</button>
            <button id="testQueueBtn" class="btn btn-success">📋 排队检测</button>
            <button id="testDoorplateBtn" class="btn btn-success">🚪 门牌号</button>
        </div>
        
        <!-- 实时视觉导航 -->
        <div style="margin-top: 20px; padding: 15px; background: #f0f8ff; border-radius: 8px; border: 2px solid #4CAF50;">
            <h3 style="margin-bottom: 15px; color: #2E7D32;">🎥 实时视觉导航</h3>
            <div style="background:#e8f5e9; border:1px solid #4CAF50; border-radius:8px; padding:12px; margin-bottom:15px; font-size:14px; color:#1B5E20;">
                <strong>💡 功能说明：</strong><br>
                • 开启摄像头后，实时分析画面<br>
                • 自动识别方向标识、门牌号、标识牌<br>
                • 提供前进路线指引（直行/左转/右转）<br>
                • 检测台阶和危险并自动警告<br>
                • 适合小范围内导航（如医院走廊、商场）
            </div>
            <button id="startVisualNavBtn" class="btn btn-success" style="width:100%; padding:15px; font-size:16px; font-weight:bold;">
                🎥 开始实时视觉导航
            </button>
            <button id="stopVisualNavBtn" class="btn btn-secondary" style="width:100%; padding:15px; margin-top:10px; font-size:16px;">
                ⏹️ 停止视觉导航
            </button>
            <div id="visualGuidanceResult" style="margin-top:15px; padding:10px; background:white; border-radius:8px; display:none;">
                <div id="guidanceMessages" style="font-size:14px; line-height:1.8;"></div>
            </div>
        </div>
        
        <!-- 语音功能标签页 -->
        <div id="voice-tab" class="tab-content">
            <h3 style="margin-bottom: 15px;">语音识别</h3>
            <button id="startRecordBtn" class="btn btn-primary">🎤 开始录音</button>
            <button class="btn btn-secondary" id="stopRecordBtn" style="display:none;">⏹️ 停止录音</button>
            
            <div id="recordingStatus" style="text-align:center; margin:15px 0; color:#667eea; font-weight:bold; display:none;">
                🔴 正在录音...
            </div>
            
            <h3 style="margin-top: 30px; margin-bottom: 15px;">语音合成</h3>
            <textarea id="ttsText" placeholder="输入要合成的文字（最多5000字符，超过将自动分段）" 
                maxlength="5000" 
                style="width:100%; padding:12px; border:2px solid #eee; border-radius:8px; margin-bottom:5px; font-size:16px; min-height:100px; resize:vertical; font-family:inherit;"></textarea>
            <div style="text-align:right; color:#666; font-size:12px; margin-bottom:10px;">
                <span id="charCount">0</span> / 5000 字符
            </div>
            
            <!-- 音量控制 -->
            <div style="margin:15px 0; padding:15px; background:#f8f9fa; border-radius:8px;">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                    <span style="font-weight:bold; color:#333;">🔊 音量控制：</span>
                    <span id="volumeDisplay" style="font-weight:bold; color:#667eea; min-width:50px;">100%</span>
                </div>
                <div style="display:flex; gap:5px;">
                    <button id="volumeDownBtn" class="btn btn-secondary" style="flex:1; padding:10px; font-size:14px;">🔉 降低</button>
                    <button id="volumeUpBtn" class="btn btn-secondary" style="flex:1; padding:10px; font-size:14px;">🔊 提高</button>
                </div>
                <div style="margin-top:10px; font-size:12px; color:#666;">
                    💡 提示：也可以使用手机音量键控制（部分浏览器支持）
                </div>
            </div>
            
            <div class="audio-controls">
                <button id="ttsCheerfulBtn" class="btn btn-success">😊 欢快</button>
                <button id="ttsCalmBtn" class="btn btn-success">😌 平静</button>
                <button id="ttsUrgentBtn" class="btn btn-success">⚡ 紧急</button>
            </div>
        </div>
        
        <!-- 综合检测标签页 -->
        <div id="comprehensive-tab" class="tab-content">
            <div style="background:#fff3cd; border:1px solid #ffc107; border-radius:8px; padding:15px; margin-bottom:15px; font-size:14px; color:#856404;">
                <strong>🔍 综合检测功能：</strong><br>
                同时运行所有视觉检测模块，包括：<br>
                • 基础视觉识别（YOLO + OCR）<br>
                • 台阶检测、标识牌检测、危险检测<br>
                • 公共设施检测、红绿灯检测<br>
                • 人群密度检测、排队检测、门牌号识别<br>
                生成完整的分析报告
            </div>
            <button id="comprehensiveDetectionBtn" class="btn btn-primary">🔍 综合检测</button>
            <p style="margin-top: 15px; color: #666; font-size: 14px;">
                点击按钮后，将对当前图片进行所有检测模块的分析
            </p>
        </div>
        
        <!-- 离线导航标签页 -->
        <div id="navigation-tab" class="tab-content">
            <div style="background:#e7f3ff; border:1px solid #2196F3; border-radius:8px; padding:15px; margin-bottom:15px; font-size:14px; color:#1976D2;">
                <strong>🧭 离线导航功能：</strong><br>
                • 完全离线工作，无需WiFi连接<br>
                • 基于本地地图数据和场景记忆<br>
                • 支持路径规划、导航控制、位置更新<br>
                <strong style="color:#d32f2f; margin-top:8px; display:block;">🔊 实时语音播报：</strong><br>
                • 自动播报转弯提示（"前方XX米到达XX"）<br>
                • 检测到障碍时自动播报警告（"请注意，前方有台阶"）<br>
                • 到达目的地时播报完成提示<br>
                • 建议：先规划路径，再开始导航，然后定期更新位置
            </div>
            
            <h3 style="margin-bottom: 15px;">路径规划</h3>
            <div style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:8px; font-weight:bold;">起点：</label>
                <input type="text" id="navStart" placeholder="例如：挂号处" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; margin-bottom:10px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:8px; font-weight:bold;">目的地（多个用逗号分隔）：</label>
                <input type="text" id="navDestinations" placeholder="例如：检查室,报告领取" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; margin-bottom:10px;">
            </div>
            <button id="planRouteBtn" class="btn btn-primary">🗺️ 规划路径</button>
            <button id="loadPathsBtn" class="btn btn-secondary">📋 查看可用路径</button>
            
            <h3 style="margin-top: 30px; margin-bottom: 15px;">导航控制</h3>
            <div style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:8px; font-weight:bold;">目的地：</label>
                <input type="text" id="navDestination" placeholder="例如：检查室" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; margin-bottom:10px;">
            </div>
            <div style="display:flex; gap:10px; margin-bottom:15px;">
                <button id="startNavBtn" class="btn btn-success" style="flex:1;">▶️ 开始导航</button>
                <button id="pauseNavBtn" class="btn btn-secondary" style="flex:1;">⏸️ 暂停</button>
            </div>
            <div style="display:flex; gap:10px; margin-bottom:15px;">
                <button id="resumeNavBtn" class="btn btn-secondary" style="flex:1;">▶️ 恢复</button>
                <button id="cancelNavBtn" class="btn btn-danger" style="flex:1;">❌ 取消</button>
            </div>
            <button id="completeNavBtn" class="btn btn-success">✅ 完成导航</button>
            <button id="getNavStatusBtn" class="btn btn-secondary">📊 查看状态</button>
            
            <h3 style="margin-top: 30px; margin-bottom: 15px;">位置更新（GPS模拟）</h3>
            <div style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:8px; font-weight:bold;">纬度：</label>
                <input type="number" id="navLat" placeholder="例如：31.2304" step="0.0001" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; margin-bottom:10px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:8px; font-weight:bold;">经度：</label>
                <input type="number" id="navLng" placeholder="例如：121.4737" step="0.0001" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; margin-bottom:10px;">
            </div>
            <button id="updatePositionBtn" class="btn btn-primary">📍 更新位置</button>
            <button id="getCurrentLocationBtn" class="btn btn-secondary">🌍 获取当前位置（需要GPS权限）</button>
        </div>
        
        <!-- 日志管理标签页 -->
        <div id="logs-tab" class="tab-content">
            <div style="background:#e7f3ff; border:1px solid #2196F3; border-radius:8px; padding:15px; margin-bottom:15px; font-size:14px; color:#1976D2;">
                <strong>📊 日志管理功能：</strong><br>
                • 自动记录所有API调用和功能使用情况<br>
                • 实时查看最新日志（自动刷新）<br>
                • 查看日志统计信息（按来源、级别、意图分类）<br>
                • 上传日志到后台进行分析<br>
                • 下载日志文件（JSON格式）
            </div>
            
            <h3 style="margin-bottom: 15px;">实时日志</h3>
            <div style="margin-bottom: 15px;">
                <button class="btn btn-success" id="startRealtimeLogsBtn" style="width:100%; margin-bottom:10px;">▶️ 开始实时日志</button>
                <button class="btn btn-danger" id="stopRealtimeLogsBtn" style="width:100%; margin-bottom:10px; display:none;">⏹️ 停止实时日志</button>
                <div id="realtimeLogsContainer" style="display:none; background:#f5f5f5; border:1px solid #ddd; border-radius:8px; padding:15px; max-height:400px; overflow-y:auto; font-family:monospace; font-size:12px;">
                    <div id="realtimeLogsContent" style="line-height:1.6;"></div>
                </div>
            </div>
            
            <h3 style="margin-bottom: 15px;">日志操作</h3>
            <div style="margin-bottom: 15px;">
                <label style="display:block; margin-bottom:8px; font-weight:bold;">日期（可选，格式：YYYY-MM-DD）：</label>
                <input type="date" id="logDate" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; margin-bottom:10px;">
            </div>
            <div style="display:flex; gap:10px; margin-bottom:15px;">
                <button id="viewLogsBtn" class="btn btn-primary" style="flex:1;">📋 查看日志</button>
                <button id="getLogStatsBtn" class="btn btn-success" style="flex:1;">📊 统计信息</button>
            </div>
            <div style="display:flex; gap:10px; margin-bottom:15px;">
                <button id="uploadLogsBtn" class="btn btn-success" style="flex:1;">📤 上传日志</button>
                <button id="downloadLogsBtn" class="btn btn-secondary" style="flex:1;">💾 下载日志</button>
            </div>
        </div>
        
        <div class="loading" id="loading">
            <div class="spinner"></div>
            <p style="margin-top: 15px;">正在处理中...</p>
        </div>
        
        <div class="error" id="error"></div>
        
        <div class="result-section" id="resultSection">
            <div class="result-title">检测结果</div>
            <div id="results"></div>
        </div>
    </div>

    <script>
        // 全局错误处理 - 确保错误不会阻止页面运行
        window.addEventListener('error', function(e) {
            console.error('全局JavaScript错误:', e.error, e.message, e.filename, e.lineno);
            // 显示错误到页面
            try {
                const errorDiv = document.getElementById('error');
                if (errorDiv) {
                    errorDiv.textContent = 'JavaScript错误: ' + (e.message || '未知错误');
                    errorDiv.classList.add('active');
                }
            } catch (err) {
                console.error('无法显示错误:', err);
            }
            
            // 记录到统一日志（如果存在）
            if (window.lunaLog) {
                window.lunaLog('error', 'JavaScript错误', {
                    message: e.message,
                    filename: e.filename,
                    lineno: e.lineno,
                    error: e.error ? e.error.toString() : '未知错误'
                });
            }
            
            // 触发情绪事件（如果存在）
            if (window.emotion_event) {
                window.emotion_event('system_error', 'high', {
                    type: 'javascript_error',
                    message: e.message,
                    filename: e.filename,
                    lineno: e.lineno
                });
            }
        });
        
        // Promise未捕获错误处理（规范要求）
        window.addEventListener('unhandledrejection', function(e) {
            console.error('未捕获的Promise错误:', e.reason);
            // 显示错误到页面
            try {
                const errorDiv = document.getElementById('error');
                if (errorDiv) {
                    errorDiv.textContent = 'Promise错误: ' + (e.reason?.message || e.reason || '未知错误');
                    errorDiv.classList.add('active');
                }
            } catch (err) {
                console.error('无法显示错误:', err);
            }
            
            // 记录到统一日志（如果存在）
            if (window.lunaLog) {
                window.lunaLog('error', '未捕获的Promise错误', {
                    reason: e.reason?.message || String(e.reason),
                    error: e.reason
                });
            }
            
            // 触发情绪事件（如果存在）
            if (window.emotion_event) {
                window.emotion_event('system_error', 'high', {
                    type: 'unhandled_promise_rejection',
                    reason: e.reason?.message || String(e.reason)
                });
            }
            
            // 阻止默认行为（避免在控制台显示）
            e.preventDefault();
        });
        
        // 确保页面加载完成
        console.log('✅ JavaScript开始执行');
        
        let stream = null;
        let mediaRecorder = null;
        let audioChunks = [];
        let currentImageBlob = null;
        let productModeActive = false;  // 产品模式状态
        
        // ========== 全局定时器管理（规范要求）==========
        window.__intervals = window.__intervals || {};
        
        // 清理所有定时器的函数
        function clearAllIntervals() {
            Object.keys(window.__intervals).forEach(key => {
                if (window.__intervals[key]) {
                    clearInterval(window.__intervals[key]);
                    delete window.__intervals[key];
                }
            });
        }
        
        // 页面卸载时清理所有定时器
        window.addEventListener('beforeunload', () => {
            clearAllIntervals();
        });
        
        // ========== 统一事件绑定系统（规范要求：移除HTML内联onclick）==========
        /**
         * 统一的事件绑定函数
         * 在DOMContentLoaded时绑定所有事件，替代HTML内联onclick
         */
        function setupEventListeners() {
            // 测试按钮
            const testJsButton = document.getElementById('testJsButton');
            if (testJsButton) {
                testJsButton.addEventListener('click', () => {
                    alert('✅ JavaScript工作正常！');
                    console.log('测试按钮被点击');
                });
            }
            
            // Tab切换按钮（使用data-tab属性）
            document.querySelectorAll('.tab[data-tab]').forEach(btn => {
                const tabId = btn.getAttribute('data-tab');
                if (tabId) {
                    btn.addEventListener('click', (e) => {
                        switchTab(tabId, e);
                    });
                }
            });
            
            // 产品模式按钮
            const startProductModeBtn = document.getElementById('startProductModeBtn');
            if (startProductModeBtn) {
                startProductModeBtn.addEventListener('click', () => {
                    startProductMode();
                });
            }
            
            const stopProductModeBtn = document.getElementById('stopProductModeBtn');
            if (stopProductModeBtn) {
                stopProductModeBtn.addEventListener('click', () => {
                    stopProductMode();
                });
            }
            
            // 视觉识别按钮
            const startCameraBtn = document.getElementById('startCameraBtn');
            if (startCameraBtn) {
                startCameraBtn.addEventListener('click', () => {
                    startCamera();
                });
            }
            
            const captureBtn = document.getElementById('captureBtn');
            if (captureBtn) {
                captureBtn.addEventListener('click', () => {
                    capturePhoto();
                });
            }
            
            const stopBtn = document.getElementById('stopBtn');
            if (stopBtn) {
                stopBtn.addEventListener('click', () => {
                    stopCamera();
                });
            }
            
            // 文件选择
            const fileInput = document.getElementById('fileInput');
            if (fileInput) {
                fileInput.addEventListener('change', (e) => {
                    handleFileSelect(e);
                });
            }
            
            // 检测功能按钮
            const testButtonMap = {
                'testStepBtn': testStepDetection,
                'testSignboardBtn': testSignboardDetection,
                'testHazardBtn': testHazardDetection,
                'testFacilityBtn': testFacilityDetection,
                'testTrafficLightBtn': testTrafficLightDetection,
                'testCrowdDensityBtn': testCrowdDensityDetection,
                'testQueueBtn': testQueueDetection,
                'testDoorplateBtn': testDoorplateDetection
            };
            
            Object.keys(testButtonMap).forEach(btnId => {
                const btn = document.getElementById(btnId);
                if (btn && typeof testButtonMap[btnId] === 'function') {
                    btn.addEventListener('click', () => {
                        testButtonMap[btnId]();
                    });
                }
            });
            
            // 视觉导航按钮
            const startVisualNavBtn = document.getElementById('startVisualNavBtn');
            if (startVisualNavBtn) {
                startVisualNavBtn.addEventListener('click', () => {
                    startVisualNavigation();
                });
            }
            
            const stopVisualNavBtn = document.getElementById('stopVisualNavBtn');
            if (stopVisualNavBtn) {
                stopVisualNavBtn.addEventListener('click', () => {
                    stopVisualNavigation();
                });
            }
            
            // 语音功能按钮
            const startRecordBtn = document.getElementById('startRecordBtn');
            if (startRecordBtn) {
                startRecordBtn.addEventListener('click', () => {
                    startRecording();
                });
            }
            
            const stopRecordBtn = document.getElementById('stopRecordBtn');
            if (stopRecordBtn) {
                stopRecordBtn.addEventListener('click', () => {
                    stopRecording();
                });
            }
            
            // 音量控制按钮
            const volumeDownBtn = document.getElementById('volumeDownBtn');
            if (volumeDownBtn) {
                volumeDownBtn.addEventListener('click', () => {
                    adjustVolume(-0.1);
                });
            }
            
            const volumeUpBtn = document.getElementById('volumeUpBtn');
            if (volumeUpBtn) {
                volumeUpBtn.addEventListener('click', () => {
                    adjustVolume(0.1);
                });
            }
            
            // TTS测试按钮
            const ttsCheerfulBtn = document.getElementById('ttsCheerfulBtn');
            if (ttsCheerfulBtn) {
                ttsCheerfulBtn.addEventListener('click', () => {
                    testTTS('cheerful');
                });
            }
            
            const ttsCalmBtn = document.getElementById('ttsCalmBtn');
            if (ttsCalmBtn) {
                ttsCalmBtn.addEventListener('click', () => {
                    testTTS('calm');
                });
            }
            
            const ttsUrgentBtn = document.getElementById('ttsUrgentBtn');
            if (ttsUrgentBtn) {
                ttsUrgentBtn.addEventListener('click', () => {
                    testTTS('urgent');
                });
            }
            
            // 综合检测按钮
            const comprehensiveDetectionBtn = document.getElementById('comprehensiveDetectionBtn');
            if (comprehensiveDetectionBtn) {
                comprehensiveDetectionBtn.addEventListener('click', () => {
                    comprehensiveDetection();
                });
            }
            
            // 导航功能按钮
            const planRouteBtn = document.getElementById('planRouteBtn');
            if (planRouteBtn) {
                planRouteBtn.addEventListener('click', () => {
                    planRoute();
                });
            }
            
            const loadPathsBtn = document.getElementById('loadPathsBtn');
            if (loadPathsBtn) {
                loadPathsBtn.addEventListener('click', () => {
                    loadAvailablePaths();
                });
            }
            
            const startNavBtn = document.getElementById('startNavBtn');
            if (startNavBtn) {
                startNavBtn.addEventListener('click', () => {
                    startNavigation();
                });
            }
            
            const pauseNavBtn = document.getElementById('pauseNavBtn');
            if (pauseNavBtn) {
                pauseNavBtn.addEventListener('click', () => {
                    pauseNavigation();
                });
            }
            
            const resumeNavBtn = document.getElementById('resumeNavBtn');
            if (resumeNavBtn) {
                resumeNavBtn.addEventListener('click', () => {
                    resumeNavigation();
                });
            }
            
            const cancelNavBtn = document.getElementById('cancelNavBtn');
            if (cancelNavBtn) {
                cancelNavBtn.addEventListener('click', () => {
                    cancelNavigation();
                });
            }
            
            const completeNavBtn = document.getElementById('completeNavBtn');
            if (completeNavBtn) {
                completeNavBtn.addEventListener('click', () => {
                    completeNavigation();
                });
            }
            
            const getNavStatusBtn = document.getElementById('getNavStatusBtn');
            if (getNavStatusBtn) {
                getNavStatusBtn.addEventListener('click', () => {
                    getNavigationStatus();
                });
            }
            
            // 位置功能按钮
            const updatePositionBtn = document.getElementById('updatePositionBtn');
            if (updatePositionBtn) {
                updatePositionBtn.addEventListener('click', () => {
                    updatePosition();
                });
            }
            
            const getCurrentLocationBtn = document.getElementById('getCurrentLocationBtn');
            if (getCurrentLocationBtn) {
                getCurrentLocationBtn.addEventListener('click', () => {
                    getCurrentLocation();
                });
            }
            
            // 日志功能按钮
            const startRealtimeLogsBtn = document.getElementById('startRealtimeLogsBtn');
            if (startRealtimeLogsBtn) {
                startRealtimeLogsBtn.addEventListener('click', () => {
                    startRealtimeLogs();
                });
            }
            
            const stopRealtimeLogsBtn = document.getElementById('stopRealtimeLogsBtn');
            if (stopRealtimeLogsBtn) {
                stopRealtimeLogsBtn.addEventListener('click', () => {
                    stopRealtimeLogs();
                });
            }
            
            const viewLogsBtn = document.getElementById('viewLogsBtn');
            if (viewLogsBtn) {
                viewLogsBtn.addEventListener('click', () => {
                    viewLogs();
                });
            }
            
            const getLogStatsBtn = document.getElementById('getLogStatsBtn');
            if (getLogStatsBtn) {
                getLogStatsBtn.addEventListener('click', () => {
                    getLogStatistics();
                });
            }
            
            const uploadLogsBtn = document.getElementById('uploadLogsBtn');
            if (uploadLogsBtn) {
                uploadLogsBtn.addEventListener('click', () => {
                    uploadLogs();
                });
            }
            
            const downloadLogsBtn = document.getElementById('downloadLogsBtn');
            if (downloadLogsBtn) {
                downloadLogsBtn.addEventListener('click', () => {
                    downloadLogs();
                });
            }
            
            // 其他按钮（通过data-action属性识别）
            document.querySelectorAll('[data-action]').forEach(btn => {
                const action = btn.getAttribute('data-action');
                if (action && typeof window[action] === 'function') {
                    btn.addEventListener('click', () => {
                        window[action]();
                    });
                }
            });
        }
        
        // 在DOM加载完成后设置事件监听器
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', setupEventListeners);
        } else {
            setupEventListeners();
        }
        
        // 全局音频上下文和音量控制
        let globalAudioContext = null;
        let currentAudioVolume = 1.0;  // 当前音量（0.0-1.0）
        let audioUnlocked = false;  // 音频是否已解锁（通过用户交互）
        
        // 初始化音频上下文（用于解锁音频播放）
        function initAudioContext() {
            try {
                if (!globalAudioContext) {
                    globalAudioContext = new (window.AudioContext || window.webkitAudioContext)();
                }
                return globalAudioContext;
            } catch (e) {
                console.warn('音频上下文初始化失败:', e);
                return null;
            }
        }
        
        // 解锁音频播放（需要在用户交互时调用）
        async function unlockAudio() {
            if (audioUnlocked) return true;
            
            try {
                const ctx = initAudioContext();
                if (!ctx) return false;
                
                // 创建静音音频并播放，用于解锁音频权限
                const buffer = ctx.createBuffer(1, 1, 22050);
                const source = ctx.createBufferSource();
                source.buffer = buffer;
                source.connect(ctx.destination);
                source.start(0);
                
                // 等待一小段时间确保音频已解锁
                await new Promise(resolve => setTimeout(resolve, 100));
                
                audioUnlocked = true;
                console.log('✅ 音频已解锁');
                return true;
            } catch (e) {
                console.warn('音频解锁失败:', e);
                return false;
            }
        }
        
        // 调整音量（全局函数，供按钮调用）- 必须先定义
        function adjustVolume(delta) {
            try {
                currentAudioVolume = Math.max(0.0, Math.min(1.0, currentAudioVolume + delta));
                
                // 更新所有正在播放的音频音量
                if (window.currentPlayingAudios) {
                    window.currentPlayingAudios.forEach(audio => {
                        if (audio && !audio.paused) {
                            audio.volume = currentAudioVolume;
                        }
                    });
                }
                
                // 更新音量显示
                const volumeDisplay = document.getElementById('volumeDisplay');
                if (volumeDisplay) {
                    volumeDisplay.textContent = Math.round(currentAudioVolume * 100) + '%';
                }
                
                // 显示音量提示
                if (typeof showVolumeIndicator === 'function') {
                    showVolumeIndicator(currentAudioVolume);
                }
                console.log(`🔊 音量: ${Math.round(currentAudioVolume * 100)}%`);
            } catch (e) {
                console.error('调整音量失败:', e);
            }
        }
        
        // 音量键事件监听（移动端）
        function setupVolumeControls() {
            try {
                // 监听音量键（通过媒体键事件）
                document.addEventListener('keydown', (e) => {
                    try {
                        // 音量上键（某些浏览器）
                        if (e.key === 'VolumeUp' || e.code === 'VolumeUp') {
                            e.preventDefault();
                            if (typeof adjustVolume === 'function') {
                                adjustVolume(0.1);
                            }
                        }
                        // 音量下键
                        else if (e.key === 'VolumeDown' || e.code === 'VolumeDown') {
                            e.preventDefault();
                            if (typeof adjustVolume === 'function') {
                                adjustVolume(-0.1);
                            }
                        }
                    } catch (err) {
                        console.error('音量键处理错误:', err);
                    }
                });
                
                // 注意：Media Session API 不支持音量控制动作（volumeup/volumedown）
                // 音量控制已通过键盘事件监听实现（见 setupVolumeControls 函数）
                // 如果需要媒体控制，可以使用支持的标准动作：'play', 'pause', 'nexttrack', 'previoustrack', 'seekbackward', 'seekforward'
                // if ('mediaSession' in navigator) {
                //     try {
                //         // 只设置支持的标准媒体动作
                //         // navigator.mediaSession.setActionHandler('play', () => { ... });
                //         // navigator.mediaSession.setActionHandler('pause', () => { ... });
                //     } catch (err) {
                //         console.warn('媒体会话API不支持:', err);
                //     }
                // }
                // 注意：不监听touchstart事件，避免干扰页面正常操作
            } catch (e) {
                console.error('设置音量控制失败:', e);
            }
        }
        
        // 显示音量指示器
        function showVolumeIndicator(volume) {
            const indicator = document.getElementById('volumeIndicator') || createVolumeIndicator();
            const percentage = Math.round(volume * 100);
            indicator.textContent = `🔊 ${percentage}%`;
            indicator.style.display = 'block';
            indicator.style.opacity = '1';
            
            setTimeout(() => {
                indicator.style.opacity = '0';
                setTimeout(() => {
                    indicator.style.display = 'none';
                }, 300);
            }, 1500);
        }
        
        // 创建音量指示器
        function createVolumeIndicator() {
            const indicator = document.createElement('div');
            indicator.id = 'volumeIndicator';
            indicator.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: rgba(0, 0, 0, 0.8);
                color: white;
                padding: 20px 40px;
                border-radius: 10px;
                font-size: 24px;
                font-weight: bold;
                z-index: 10000;
                display: none;
                transition: opacity 0.3s;
                pointer-events: none;
            `;
            document.body.appendChild(indicator);
            return indicator;
        }
        
        // 初始化音频功能（延迟执行，避免阻塞页面）
        function initAudioFeatures() {
            try {
                // 延迟初始化，确保所有函数都已定义
                setTimeout(() => {
                    try {
                        if (typeof initAudioContext === 'function') {
                            initAudioContext();
                        }
                        if (typeof setupVolumeControls === 'function') {
                            setupVolumeControls();
                        }
                        
                        // 在用户首次交互时解锁音频
                        const unlockOnInteraction = () => {
                            try {
                                if (typeof unlockAudio === 'function') {
                                    unlockAudio();
                                }
                                document.removeEventListener('click', unlockOnInteraction);
                                document.removeEventListener('touchstart', unlockOnInteraction);
                            } catch (e) {
                                console.error('解锁音频失败:', e);
                            }
                        };
                        document.addEventListener('click', unlockOnInteraction, { once: true });
                        document.addEventListener('touchstart', unlockOnInteraction, { once: true });
                    } catch (e) {
                        console.error('初始化音频功能失败:', e);
                    }
                }, 200);
            } catch (e) {
                console.error('音频功能初始化失败:', e);
            }
        }
        
        // 在页面加载时初始化（简化版，避免阻塞页面）
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initAudioFeatures);
        } else {
            // DOM已经加载完成
            setTimeout(initAudioFeatures, 100);
        }
        
        // 全局音频元素追踪
        window.currentPlayingAudios = window.currentPlayingAudios || [];
        let lastVoiceRecognitionTime = 0;  // 上次语音识别时间
        let lastLogTimestamp = null;  // 上次获取的日志时间戳
        
        // 获取DOM元素的辅助函数（延迟获取，避免在元素创建前访问）
        function getVideo() {
            return document.getElementById('video');
        }
        
        function getCanvas() {
            return document.getElementById('canvas');
        }
        
        // 为了兼容旧代码，保留变量引用（延迟初始化）
        let video = null;
        let canvas = null;
        
        function initDOMElements() {
            if (!video) video = getVideo();
            if (!canvas) canvas = getCanvas();
        }
        
        // 在DOM加载后初始化元素引用
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initDOMElements);
        } else {
            initDOMElements();
        }
        
        // 在使用video和canvas的函数中，确保它们已初始化
        function ensureDOMElements() {
            if (!video) video = getVideo();
            if (!canvas) canvas = getCanvas();
        }
        
        function switchTab(tabName, event) {
            // 确保函数暴露到全局作用域
            window.switchTab = switchTab;
            console.log('switchTab被调用:', tabName, event);
            // 防止默认行为
            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }
            try {
                // 移除所有标签的active状态
                const tabs = document.querySelectorAll('.tab');
                const contents = document.querySelectorAll('.tab-content');
                console.log('找到标签数:', tabs.length, '内容数:', contents.length);
                
                tabs.forEach(t => t.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));
                
                // 添加当前标签的active状态
                let clickedTab = null;
                if (event && event.target) {
                    clickedTab = event.target;
                    console.log('使用event.target');
                } else {
                    // 如果没有event对象，通过tabName查找对应的按钮
                    clickedTab = document.querySelector(`.tab[onclick*="${tabName}"]`);
                    console.log('通过选择器查找:', clickedTab);
                }
                
                if (clickedTab) {
                    clickedTab.classList.add('active');
                    console.log('标签已激活');
                } else {
                    console.warn('未找到对应的标签按钮');
                }
                
                // 显示对应的内容
                const contentId = tabName + '-tab';
                const content = document.getElementById(contentId);
                console.log('查找内容:', contentId, content);
                if (content) {
                    content.classList.add('active');
                    console.log('内容已显示');
                } else {
                    console.error('未找到内容区域:', contentId);
                }
            } catch (e) {
                console.error('切换标签页失败:', e, e.stack);
                // 即使出错也尝试显示内容
                try {
                    const contentId = tabName + '-tab';
                    const content = document.getElementById(contentId);
                    if (content) {
                        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                        content.classList.add('active');
                    }
                } catch (err) {
                    console.error('恢复失败:', err);
                }
            }
        }
        
        async function startCamera() {
            try {
                ensureDOMElements();
                const videoEl = getVideo();
                if (!videoEl) {
                    showError('无法找到视频元素');
                    return;
                }
                
                // 检测Safari浏览器
                const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
                const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
                const isSecureContext = window.location.protocol === 'https:' || window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
                
                // Safari特殊检查
                if ((isSafari || isIOS) && !isSecureContext) {
                    showError(`⚠️ Safari浏览器需要HTTPS才能访问摄像头。\n\n解决方案：\n1. 使用"选择图片"功能代替摄像头\n2. 或配置HTTPS访问`);
                    return;
                }
                
                // 检查浏览器支持
                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    showError(`您的浏览器不支持摄像头访问。\n\n建议：使用"选择图片"功能上传照片进行识别。`);
                    return;
                }
                
                stream = await navigator.mediaDevices.getUserMedia({ 
                    video: { 
                        facingMode: 'environment',
                        width: { ideal: 1280 },
                        height: { ideal: 720 }
                    }
                });
                videoEl.srcObject = stream;
                video = videoEl;  // 更新引用
                videoEl.setAttribute('playsinline', 'true');
                videoEl.setAttribute('webkit-playsinline', 'true');
                await videoEl.play();
                document.getElementById('captureBtn').style.display = 'block';
                document.getElementById('stopBtn').style.display = 'block';
                document.querySelector('#vision-tab .btn-primary').style.display = 'none';
                
                // 如果产品模式已激活，自动启动视觉导航和语音监听
                if (productModeActive) {
                    setTimeout(() => {
                        startVisualNavigation();
                        startVoiceListening();
                    }, 1000);
                }
            } catch (err) {
                let errorMsg = '无法访问摄像头: ';
                if (err.name === 'NotAllowedError') {
                    errorMsg += '请允许浏览器访问摄像头权限（在Safari设置中允许）';
                } else if (err.name === 'NotFoundError') {
                    errorMsg += '未找到摄像头设备';
                } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
                    errorMsg += '摄像头被其他应用占用，请关闭其他应用后重试';
                } else if (err.name === 'OverconstrainedError') {
                    errorMsg += '摄像头不支持请求的配置';
                } else {
                    errorMsg += err.message || '未知错误';
                }
                errorMsg += '\\n\\n💡 提示：可以使用"选择图片"功能上传照片';
                showError(errorMsg);
            }
        }
        
        function stopCamera() {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
                stream = null;
            }
            ensureDOMElements();
            const videoEl = getVideo();
            if (videoEl) {
                videoEl.srcObject = null;
            }
            document.getElementById('captureBtn').style.display = 'none';
            document.getElementById('stopBtn').style.display = 'none';
            document.querySelector('#vision-tab .btn-primary').style.display = 'block';
        }
        
        function capturePhoto() {
            ensureDOMElements();
            const videoEl = getVideo();
            const canvasEl = getCanvas();
            if (!videoEl || !canvasEl) {
                showError('无法找到视频或画布元素');
                return;
            }
            canvasEl.width = videoEl.videoWidth;
            canvasEl.height = videoEl.videoHeight;
            const ctx = canvasEl.getContext('2d');
            ctx.drawImage(videoEl, 0, 0);
            canvasEl.toBlob(function(blob) {
                currentImageBlob = blob;
                sendImage(blob, '/api/recognize');
            }, 'image/jpeg', 0.9);
        }
        
        function handleFileSelect(event) {
            const file = event.target.files[0];
            if (file) {
                currentImageBlob = file;
                sendImage(file, '/api/recognize');
            }
        }
        
        async function sendImage(imageBlob, endpoint) {
            showLoading();
            const formData = new FormData();
            formData.append('image', imageBlob);
            
            try {
                const response = await fetch(endpoint, {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    displayResults(data);
                } else {
                    showError(data.error || '处理失败');
                }
            } catch (err) {
                showError('网络错误: ' + err.message);
            } finally {
                hideLoading();
            }
        }
        
        function testStepDetection() {
            if (!currentImageBlob) {
                showError('请先拍照或选择图片');
                return;
            }
            sendImage(currentImageBlob, '/api/detect/step');
        }
        
        function testSignboardDetection() {
            if (!currentImageBlob) {
                showError('请先拍照或选择图片');
                return;
            }
            sendImage(currentImageBlob, '/api/detect/signboard');
        }
        
        function testHazardDetection() {
            if (!currentImageBlob) {
                showError('请先拍照或选择图片');
                return;
            }
            sendImage(currentImageBlob, '/api/detect/hazard');
        }
        
        function testFacilityDetection() {
            if (!currentImageBlob) {
                showError('请先拍照或选择图片');
                return;
            }
            sendImage(currentImageBlob, '/api/detect/facility');
        }
        
        function testTrafficLightDetection() {
            if (!currentImageBlob) {
                showError('请先拍照或选择图片');
                return;
            }
            sendImage(currentImageBlob, '/api/detect/traffic_light');
        }
        
        function testCrowdDensityDetection() {
            if (!currentImageBlob) {
                showError('请先拍照或选择图片');
                return;
            }
            sendImage(currentImageBlob, '/api/detect/crowd_density');
        }
        
        function testQueueDetection() {
            if (!currentImageBlob) {
                showError('请先拍照或选择图片');
                return;
            }
            sendImage(currentImageBlob, '/api/detect/queue');
        }
        
        function testDoorplateDetection() {
            if (!currentImageBlob) {
                showError('请先拍照或选择图片');
                return;
            }
            sendImage(currentImageBlob, '/api/detect/doorplate');
        }
        
        function comprehensiveDetection() {
            if (!currentImageBlob) {
                showError('请先拍照或选择图片');
                return;
            }
            sendImage(currentImageBlob, '/api/detect/comprehensive');
        }
        
        async function startRecording() {
            try {
                // 检测Safari浏览器
                const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
                const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
                const isSecureContext = window.location.protocol === 'https:' || window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
                
                // Safari特殊检查
                if ((isSafari || isIOS) && !isSecureContext) {
                    showError(`⚠️ Safari浏览器需要HTTPS才能访问麦克风。\n\n当前功能受限，建议使用桌面浏览器测试。`);
                    return;
                }
                
                // 检查浏览器支持
                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    showError(`您的浏览器不支持麦克风访问。\n\nSafari在iOS上可能需要HTTPS。`);
                    return;
                }
                
                const audioStream = await navigator.mediaDevices.getUserMedia({ 
                    audio: {
                        echoCancellation: true,
                        noiseSuppression: true,
                        sampleRate: 16000
                    }
                });
                audioChunks = [];
                
                // 检查MediaRecorder支持（Safari支持有限）
                if (!window.MediaRecorder) {
                    showError(`您的浏览器不支持录音功能。\n\nSafari的MediaRecorder支持有限，建议使用Chrome浏览器。`);
                    return;
                }
                
                // Safari需要指定MIME类型
                let options = {};
                if (MediaRecorder.isTypeSupported('audio/webm')) {
                    options = { mimeType: 'audio/webm' };
                } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
                    options = { mimeType: 'audio/mp4' };
                } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
                    options = { mimeType: 'audio/ogg' };
                }
                
                mediaRecorder = new MediaRecorder(audioStream, options);
                
                mediaRecorder.ondataavailable = (event) => {
                    if (event.data && event.data.size > 0) {
                        audioChunks.push(event.data);
                    }
                };
                
                mediaRecorder.onstop = async () => {
                    const mimeType = mediaRecorder.mimeType || 'audio/webm';
                    const audioBlob = new Blob(audioChunks, { type: mimeType });
                    await sendAudio(audioBlob);
                };
                
                mediaRecorder.onerror = (event) => {
                    showError('录音过程中出错: ' + (event.error?.message || '未知错误'));
                };
                
                mediaRecorder.start();
                document.getElementById('stopRecordBtn').style.display = 'block';
                document.getElementById('recordingStatus').style.display = 'block';
            } catch (err) {
                let errorMsg = '无法访问麦克风: ';
                if (err.name === 'NotAllowedError') {
                    errorMsg += '请允许浏览器访问麦克风权限（在Safari设置 > 网站设置中允许）';
                } else if (err.name === 'NotFoundError') {
                    errorMsg += '未找到麦克风设备';
                } else if (err.name === 'NotReadableError') {
                    errorMsg += '麦克风被其他应用占用';
                } else {
                    errorMsg += err.message || '未知错误';
                }
                if (isIOS || isSafari) {
                    errorMsg += '\\n\\n💡 Safari在iOS上需要HTTPS才能使用麦克风';
                }
                showError(errorMsg);
            }
        }
        
        function stopRecording() {
            if (mediaRecorder && mediaRecorder.state !== 'inactive') {
                mediaRecorder.stop();
                mediaRecorder.stream.getTracks().forEach(track => track.stop());
                document.getElementById('stopRecordBtn').style.display = 'none';
                document.getElementById('recordingStatus').style.display = 'none';
            }
        }
        
        async function sendAudio(audioBlob) {
            showLoading();
            const formData = new FormData();
            formData.append('audio', audioBlob);
            
            try {
                const response = await fetch('/api/recognize/voice', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    displayResults({ voice_result: data });
                } else {
                    showError(data.error || '识别失败');
                }
            } catch (err) {
                showError('网络错误: ' + err.message);
            } finally {
                hideLoading();
            }
        }
        
        async function testTTS(style) {
            const text = document.getElementById('ttsText').value;
            if (!text) {
                showError('请输入要合成的文字');
                return;
            }
            
            showLoading();
            try {
                const response = await fetch('/api/tts', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ text, style })
                });
                const data = await response.json();
                
                if (data.success) {
                    // Edge-TTS返回的是MP3格式
                    const audio = new Audio('data:audio/mp3;base64,' + data.audio);
                    audio.play().catch(err => {
                        showError('播放失败: ' + err.message);
                    });
                } else {
                    showError(data.error || '合成失败');
                }
            } catch (err) {
                showError('网络错误: ' + err.message);
            } finally {
                hideLoading();
            }
        }
        
        function displayResults(data) {
            const results = document.getElementById('results');
            results.innerHTML = '';
            
            // 视觉识别结果
            if (data.detections || data.ocr_results) {
                if (data.ocr_results && data.ocr_results.length > 0) {
                    const div = document.createElement('div');
                    div.innerHTML = '<div class="result-title">📝 识别的文字</div>';
                    data.ocr_results.forEach(item => {
                        const itemDiv = document.createElement('div');
                        itemDiv.className = 'result-item';
                        itemDiv.innerHTML = `
                            <div class="result-text">${item.text}</div>
                            <div class="result-confidence">置信度: ${(item.confidence * 100).toFixed(1)}%</div>
                        `;
                        div.appendChild(itemDiv);
                    });
                    results.appendChild(div);
                }
                
                if (data.detections && data.detections.length > 0) {
                    const div = document.createElement('div');
                    div.innerHTML = '<div class="result-title">🎯 检测到的物体</div>';
                    data.detections.forEach(item => {
                        const itemDiv = document.createElement('div');
                        itemDiv.className = 'result-item';
                        itemDiv.innerHTML = `
                            <div class="result-text">${item.class}</div>
                            <div class="result-confidence">置信度: ${(item.confidence * 100).toFixed(1)}%</div>
                        `;
                        div.appendChild(itemDiv);
                    });
                    results.appendChild(div);
                }
            }
            
            // 台阶检测结果
            if (data.step_detection) {
                const div = document.createElement('div');
                div.innerHTML = '<div class="result-title">🪜 台阶检测</div>';
                const itemDiv = document.createElement('div');
                itemDiv.className = 'result-item';
                const step = data.step_detection;
                
                if (step.detected === false || !step.direction) {
                    // 未检测到台阶
                    itemDiv.innerHTML = `
                        <div class="result-text" style="color: #666;">${step.message || '未检测到台阶'}</div>
                        <div style="margin-top: 10px; font-size: 12px; color: #999;">
                            可能原因：<br>
                            • 图片中没有台阶/楼梯<br>
                            • YOLO模型未加载或加载失败<br>
                            • 台阶特征不明显
                        </div>
                    `;
                } else {
                    // 检测到台阶
                    itemDiv.innerHTML = `
                        <div class="result-text">方向: ${step.direction || '未知'}</div>
                        <div class="result-confidence">置信度: ${(step.confidence * 100).toFixed(1)}%</div>
                        ${step.steps_count ? `<div style="margin-top: 5px;">台阶数量: ${step.steps_count}</div>` : ''}
                        ${step.height_cm ? `<div style="margin-top: 5px;">高度: ${step.height_cm}cm</div>` : ''}
                    `;
                }
                div.appendChild(itemDiv);
                results.appendChild(div);
            }
            
            // 标识牌检测结果
            if (data.signboards && data.signboards.length > 0) {
                const div = document.createElement('div');
                div.innerHTML = '<div class="result-title">🚏 标识牌检测</div>';
                data.signboards.forEach(item => {
                    const itemDiv = document.createElement('div');
                    itemDiv.className = 'result-item';
                    itemDiv.innerHTML = `
                        <div class="result-text">${item.text} <span class="badge badge-success">${item.type}</span></div>
                        <div class="result-confidence">置信度: ${(item.confidence * 100).toFixed(1)}%</div>
                    `;
                    div.appendChild(itemDiv);
                });
                results.appendChild(div);
            }
            
            // 危险检测结果
            if (data.hazards && data.hazards.length > 0) {
                const div = document.createElement('div');
                div.innerHTML = '<div class="result-title">⚠️ 危险检测</div>';
                data.hazards.forEach(item => {
                    const itemDiv = document.createElement('div');
                    itemDiv.className = 'result-item';
                    const severityClass = item.severity === 'high' || item.severity === 'critical' ? 'badge-danger' : 'badge-warning';
                    itemDiv.innerHTML = `
                        <div class="result-text">${item.type} <span class="badge ${severityClass}">${item.severity}</span></div>
                        <div class="result-confidence">置信度: ${(item.confidence * 100).toFixed(1)}%</div>
                    `;
                    div.appendChild(itemDiv);
                });
                results.appendChild(div);
            }
            
            // 语音识别结果
            if (data.voice_result) {
                const div = document.createElement('div');
                div.innerHTML = '<div class="result-title">🎤 语音识别</div>';
                const itemDiv = document.createElement('div');
                itemDiv.className = 'result-item';
                
                const voiceData = data.voice_result;
                const confidence = voiceData.details?.confidence || 0;
                const confidencePercent = (confidence * 100).toFixed(1);
                const confidenceColor = confidence > 0.7 ? '#51cf66' : confidence > 0.5 ? '#ffd43b' : '#ff6b6b';
                
                itemDiv.innerHTML = `
                    <div class="result-text">${voiceData.text || '未识别到语音'}</div>
                    <div style="margin-top: 8px;">
                        <span style="font-size: 13px; color: #666;">置信度: </span>
                        <span style="font-size: 14px; font-weight: bold; color: ${confidenceColor};">
                            ${confidencePercent}%
                        </span>
                        ${voiceData.details?.language ? `<span style="font-size: 12px; color: #999; margin-left: 10px;">语言: ${voiceData.details.language}</span>` : ''}
                    </div>
                    ${confidence < 0.5 ? '<div style="margin-top: 5px; font-size: 12px; color: #ff6b6b;">⚠️ 识别置信度较低，建议在安静环境下清晰说话</div>' : ''}
                `;
                div.appendChild(itemDiv);
                results.appendChild(div);
            }
            
            if (results.innerHTML === '') {
                results.innerHTML = '<div class="result-item">未识别到内容</div>';
            }
            
            document.getElementById('resultSection').classList.add('active');
        }
        
        function showLoading() {
            document.getElementById('loading').classList.add('active');
        }
        
        function hideLoading() {
            document.getElementById('loading').classList.remove('active');
        }
        
        function showError(message) {
            console.log('showError被调用:', message);
            try {
                const error = document.getElementById('error');
                if (!error) {
                    console.error('未找到error元素');
                    alert('错误: ' + message);  // 备用方案
                    return;
                }
                error.textContent = message;
                error.classList.add('active');
                setTimeout(() => error.classList.remove('active'), 5000);
            } catch (e) {
                console.error('showError失败:', e);
                alert('错误: ' + message);  // 备用方案
            }
        }
        
        // 字符计数
        document.addEventListener('DOMContentLoaded', function() {
            const ttsText = document.getElementById('ttsText');
            const charCount = document.getElementById('charCount');
            if (ttsText && charCount) {
                ttsText.addEventListener('input', function() {
                    const length = this.value.length;
                    charCount.textContent = length;
                    if (length > 5000) {
                        charCount.style.color = '#ff6b6b';
                    } else if (length > 4500) {
                        charCount.style.color = '#ffd43b';
                    } else {
                        charCount.style.color = '#666';
                    }
                });
            }
        });
        
        // 导航相关函数
        async function planRoute() {
            const start = document.getElementById('navStart').value.trim();
            const destinationsStr = document.getElementById('navDestinations').value.trim();
            
            if (!start || !destinationsStr) {
                showError('请填写起点和目的地');
                return;
            }
            
            const destinations = destinationsStr.split(',').map(d => d.trim()).filter(d => d);
            
            showLoading();
            try {
                const response = await fetch('/api/navigation/plan', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ start, destinations })
                });
                
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    // 保存路径规划结果，供导航使用
                    window.lastRouteResult = data.route;
                    displayNavigationResult('路径规划结果', data.route);
                } else {
                    showError('路径规划失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('路径规划错误: ' + err.message);
            }
        }
        
        async function loadAvailablePaths() {
            showLoading();
            try {
                const response = await fetch('/api/navigation/paths');
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    displayNavigationResult('可用路径列表', data.paths);
                } else {
                    showError('获取路径列表失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('获取路径列表错误: ' + err.message);
            }
        }
        
        async function startNavigation() {
            const destination = document.getElementById('navDestination').value.trim();
            
            if (!destination) {
                showError('请填写目的地');
                return;
            }
            
            // 如果之前有路径规划结果，使用路径段
            let routeSegments = null;
            const lastRouteResult = window.lastRouteResult;
            if (lastRouteResult && lastRouteResult.segments) {
                routeSegments = lastRouteResult.segments;
            }
            
            showLoading();
            try {
                const response = await fetch('/api/navigation/start', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        destination,
                        route_segments: routeSegments
                    })
                });
                
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    displayNavigationResult('导航已启动', data.status);
                    // 如果TTS可用，会自动播报开始导航
                } else {
                    showError('启动导航失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('启动导航错误: ' + err.message);
            }
        }
        
        async function pauseNavigation() {
            showLoading();
            try {
                const response = await fetch('/api/navigation/pause', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ reason: '用户暂停' })
                });
                
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    displayNavigationResult('导航已暂停', data.status);
                } else {
                    showError('暂停导航失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('暂停导航错误: ' + err.message);
            }
        }
        
        async function resumeNavigation() {
            showLoading();
            try {
                const response = await fetch('/api/navigation/resume', {
                    method: 'POST'
                });
                
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    displayNavigationResult('导航已恢复', data.status);
                } else {
                    showError('恢复导航失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('恢复导航错误: ' + err.message);
            }
        }
        
        async function cancelNavigation() {
            showLoading();
            try {
                const response = await fetch('/api/navigation/cancel', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ reason: '用户取消' })
                });
                
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    displayNavigationResult('导航已取消', data.status);
                } else {
                    showError('取消导航失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('取消导航错误: ' + err.message);
            }
        }
        
        async function completeNavigation() {
            showLoading();
            try {
                const response = await fetch('/api/navigation/complete', {
                    method: 'POST'
                });
                
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    displayNavigationResult('导航已完成', data.status);
                } else {
                    showError('完成导航失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('完成导航错误: ' + err.message);
            }
        }
        
        async function getNavigationStatus() {
            showLoading();
            try {
                const response = await fetch('/api/navigation/status');
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    displayNavigationResult('导航状态', data.status || '当前没有进行中的导航');
                } else {
                    showError('获取导航状态失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('获取导航状态错误: ' + err.message);
            }
        }
        
        async function updatePosition() {
            const lat = parseFloat(document.getElementById('navLat').value);
            const lng = parseFloat(document.getElementById('navLng').value);
            
            if (isNaN(lat) || isNaN(lng)) {
                showError('请填写有效的经纬度');
                return;
            }
            
            // 尝试获取当前摄像头画面进行障碍检测
            let imageData = null;
            ensureDOMElements();
            const videoEl = getVideo();
            const canvasEl = getCanvas();
            if (videoEl && videoEl.srcObject) {
                try {
                    canvasEl.width = videoEl.videoWidth;
                    canvasEl.height = videoEl.videoHeight;
                    const ctx = canvasEl.getContext('2d');
                    ctx.drawImage(videoEl, 0, 0);
                    imageData = canvasEl.toDataURL('image/jpeg', 0.8);
                } catch (e) {
                    console.log('无法获取摄像头画面:', e);
                }
            }
            
            showLoading();
            try {
                const requestBody = { lat, lng };
                if (imageData) {
                    requestBody.image = imageData;
                }
                
                const response = await fetch('/api/navigation/update_position', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(requestBody)
                });
                
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    const result = {
                        status: data.status,
                        is_idle: data.is_idle ? '是（静止）' : '否（移动中）'
                    };
                    if (data.detected_hazards && data.detected_hazards.length > 0) {
                        result.detected_hazards = data.detected_hazards;
                        result.message = '检测到障碍，已自动播报提示';
                    }
                    displayNavigationResult('位置已更新', result);
                } else {
                    showError('更新位置失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('更新位置错误: ' + err.message);
            }
        }
        
        function getCurrentLocation() {
            if (!navigator.geolocation) {
                showError('您的浏览器不支持GPS定位');
                return;
            }
            
            showLoading();
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    document.getElementById('navLat').value = lat.toFixed(6);
                    document.getElementById('navLng').value = lng.toFixed(6);
                    hideLoading();
                    showSuccess('已获取当前位置: ' + lat.toFixed(6) + ', ' + lng.toFixed(6));
                },
                (error) => {
                    hideLoading();
                    let errorMsg = '获取位置失败: ';
                    switch(error.code) {
                        case error.PERMISSION_DENIED:
                            errorMsg += '用户拒绝了位置权限';
                            break;
                        case error.POSITION_UNAVAILABLE:
                            errorMsg += '位置信息不可用';
                            break;
                        case error.TIMEOUT:
                            errorMsg += '获取位置超时';
                            break;
                        default:
                            errorMsg += '未知错误';
                    }
                    showError(errorMsg);
                }
            );
        }
        
        function displayNavigationResult(title, data) {
            const results = document.getElementById('results');
            results.innerHTML = '';
            
            const titleDiv = document.createElement('div');
            titleDiv.className = 'result-title';
            titleDiv.textContent = title;
            results.appendChild(titleDiv);
            
            const dataDiv = document.createElement('div');
            dataDiv.className = 'result-item';
            dataDiv.innerHTML = '<pre style="white-space: pre-wrap; word-wrap: break-word; font-size: 13px;">' + JSON.stringify(data, null, 2) + '</pre>';
            results.appendChild(dataDiv);
            
            document.getElementById('resultSection').classList.add('active');
        }
        
        function showSuccess(message) {
            const error = document.getElementById('error');
            error.style.background = '#d4edda';
            error.style.color = '#155724';
            error.textContent = '✅ ' + message;
            error.classList.add('active');
            setTimeout(() => {
                error.classList.remove('active');
                error.style.background = '#fee';
                error.style.color = '#c33';
            }, 3000);
        }
        
        // 实时日志功能
        async function startRealtimeLogs() {
            if (realtimeLogsInterval) {
                return; // 已在运行
            }
            
            document.getElementById('startRealtimeLogsBtn').style.display = 'none';
            document.getElementById('stopRealtimeLogsBtn').style.display = 'block';
            document.getElementById('realtimeLogsContainer').style.display = 'block';
            
            const logsContent = document.getElementById('realtimeLogsContent');
            logsContent.innerHTML = '<div style="color:#666;">正在加载实时日志...</div>';
            
            // 先获取一次日志，获取最后的时间戳
            try {
                const response = await fetch('/api/logs/view?limit=10');
                const data = await response.json();
                if (data.success && data.logs && data.logs.length > 0) {
                    lastLogTimestamp = data.logs[data.logs.length - 1].timestamp;
                    displayRealtimeLogs(data.logs);
                }
            } catch (err) {
                logsContent.innerHTML = `<div style="color:#F44336;">加载失败: ${err.message}</div>`;
            }
            
            // 每2秒轮询一次新日志（使用全局引用）
            if (window.__intervals.realtimeLogs) {
                clearInterval(window.__intervals.realtimeLogs);
            }
            window.__intervals.realtimeLogs = setInterval(async () => {
                try {
                    let url = '/api/logs/realtime';
                    if (lastLogTimestamp) {
                        url += `?since=${lastLogTimestamp}`;
                    }
                    
                    const response = await fetch(url);
                    const data = await response.json();
                    
                    if (data.success && data.logs && data.logs.length > 0) {
                        // 更新最后的时间戳
                        lastLogTimestamp = data.logs[data.logs.length - 1].timestamp;
                        // 追加新日志
                        appendRealtimeLogs(data.logs);
                    }
                } catch (err) {
                    console.error('实时日志获取失败:', err);
                }
            }, 2000); // 每2秒更新一次
        }
        
        function stopRealtimeLogs() {
            if (window.__intervals.realtimeLogs) {
                clearInterval(window.__intervals.realtimeLogs);
                delete window.__intervals.realtimeLogs;
            }
            document.getElementById('startRealtimeLogsBtn').style.display = 'block';
            document.getElementById('stopRealtimeLogsBtn').style.display = 'none';
        }
        
        function displayRealtimeLogs(logs) {
            const logsContent = document.getElementById('realtimeLogsContent');
            logsContent.innerHTML = '';
            logs.forEach(log => {
                appendLogEntry(log);
            });
            // 滚动到底部
            const container = document.getElementById('realtimeLogsContainer');
            container.scrollTop = container.scrollHeight;
        }
        
        function appendRealtimeLogs(logs) {
            logs.forEach(log => {
                appendLogEntry(log);
            });
            // 滚动到底部
            const container = document.getElementById('realtimeLogsContainer');
            container.scrollTop = container.scrollHeight;
        }
        
        function appendLogEntry(log) {
            const logsContent = document.getElementById('realtimeLogsContent');
            const time = new Date(log.timestamp).toLocaleTimeString();
            const levelColor = log.level === 'error' ? '#F44336' : log.level === 'warning' ? '#FF9800' : '#2196F3';
            const levelIcon = log.level === 'error' ? '❌' : log.level === 'warning' ? '⚠️' : 'ℹ️';
            
            const entry = document.createElement('div');
            entry.style.cssText = `margin-bottom:5px; padding:5px; border-left:3px solid ${levelColor}; padding-left:10px;`;
            entry.innerHTML = `
                <span style="color:#666; font-size:11px;">[${time}]</span>
                <span style="color:${levelColor}; font-weight:bold;">${levelIcon} ${log.level.toUpperCase()}</span>
                <span style="color:#333;">${log.content || log.source || ''}</span>
                ${log.metadata ? `<span style="color:#999; font-size:11px;">(${JSON.stringify(log.metadata).substring(0, 50)}...)</span>` : ''}
            `;
            logsContent.appendChild(entry);
        }
        
        // 日志管理相关函数
        async function viewLogs() {
            const date = document.getElementById('logDate').value;
            
            showLoading();
            try {
                let url = '/api/logs/view';
                if (date) {
                    url += `?date=${date}`;
                }
                
                const response = await fetch(url);
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    displayNavigationResult(`日志列表（${data.count} 条）`, {
                        date: data.date,
                        count: data.count,
                        logs: data.logs
                    });
                } else {
                    showError('查看日志失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('查看日志错误: ' + err.message);
            }
        }
        
        async function getLogStatistics() {
            const date = document.getElementById('logDate').value;
            
            showLoading();
            try {
                let url = '/api/logs/statistics';
                if (date) {
                    url += `?date=${date}`;
                }
                
                const response = await fetch(url);
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    displayNavigationResult('日志统计信息', {
                        date: data.date,
                        statistics: data.statistics
                    });
                } else {
                    showError('获取统计信息失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('获取统计信息错误: ' + err.message);
            }
        }
        
        async function uploadLogs() {
            const date = document.getElementById('logDate').value;
            
            showLoading();
            try {
                const response = await fetch('/api/logs/upload', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ date: date || null })
                });
                
                const data = await response.json();
                hideLoading();
                
                if (data.success) {
                    showSuccess(data.message + (data.upload_file ? `\\n文件: ${data.upload_file}` : ''));
                } else {
                    showError('上传日志失败: ' + (data.error || '未知错误'));
                }
            } catch (err) {
                hideLoading();
                showError('上传日志错误: ' + err.message);
            }
        }
        
        function downloadLogs() {
            const date = document.getElementById('logDate').value;
            
            let url = '/api/logs/download';
            if (date) {
                url += `?date=${date}`;
            }
            
            // 直接下载文件
            window.location.href = url;
        }
        
        // 实时视觉导航功能
        function startVisualNavigation() {
            // 确保函数暴露到全局作用域
            window.startVisualNavigation = startVisualNavigation;
            // 优先使用产品模式的摄像头流（如果已开启）
            const productVideo = document.getElementById('productVideo');
            let videoToUse = video;
            
            // 如果产品模式已开启摄像头，共享使用
            if (productVideo && productVideo.srcObject && productVideo.readyState >= 2) {
                console.log('使用产品模式的摄像头流');
                // 将产品模式的流也赋值给普通模式的video
                ensureDOMElements();
                const videoEl = getVideo();
                if (videoEl && !videoEl.srcObject) {
                    videoEl.srcObject = productVideo.srcObject;
                    videoEl.play().then(() => {
                        video = videoEl;  // 更新引用
                        continueStartVisualNavigation();
                    }).catch((err) => {
                        console.error('视频播放失败:', err);
                        continueStartVisualNavigation();
                    });
                    return;
                }
            }
            
            continueStartVisualNavigation();
            
            function continueStartVisualNavigation() {
                // 检查摄像头是否开启
                ensureDOMElements();
                const videoEl = getVideo();
                if (!videoEl || !videoEl.srcObject) {
                    showError('请先开启摄像头');
                    return;
                }
                
                // 检查视频是否已播放
                if (videoEl.readyState < 2) {
                    showError('摄像头未就绪，请稍候再试');
                    return;
                }
                
                // 显示结果区域
                document.getElementById('visualGuidanceResult').style.display = 'block';
                document.getElementById('guidanceMessages').innerHTML = '<div style="color:#4CAF50;">🎥 视觉导航已启动，正在分析画面...</div>';
                
                // 开始定时分析画面（每1.5秒一次，提高响应速度）（使用全局引用）
                if (window.__intervals.visualNavigation) {
                    clearInterval(window.__intervals.visualNavigation);
                }
                window.__intervals.visualNavigation = setInterval(() => {
                    analyzeVisualGuidanceFrame().catch((err) => {
                        console.error('视觉导航分析失败:', err);
                    });
                }, 1500);
                
                // 立即执行一次
                analyzeVisualGuidanceFrame().then(() => {
                    showSuccess('实时视觉导航已启动');
                }).catch((err) => {
                    console.error('视觉导航分析失败:', err);
                    showSuccess('实时视觉导航已启动');
                });
            }
        }
        
        function stopVisualNavigation() {
            if (window.__intervals.visualNavigation) {
                clearInterval(window.__intervals.visualNavigation);
                delete window.__intervals.visualNavigation;
            }
            document.getElementById('visualGuidanceResult').style.display = 'none';
            document.getElementById('guidanceMessages').innerHTML = '';
            showSuccess('视觉导航已停止');
        }
        
        // ========== 统一视觉模块入口（规范要求）==========
        /**
         * 统一的视觉分析入口函数
         * @param {Blob} frameBlob - 视频帧的Blob对象（可选，如果不提供则自动获取）
         * @returns {Promise<void>}
         */
        async function analyzeVisualGuidanceFrame(frameBlob = null) {
            try {
                // 如果没有提供Blob，则根据模式获取
                if (!frameBlob) {
                    if (productModeActive) {
                        frameBlob = await _getFrameBlobForProductMode();
                    } else {
                        frameBlob = await _getFrameBlobForNormalMode();
                    }
                }
                
                if (!frameBlob) {
                    console.warn('⚠️ 无法获取视频帧');
                    return;
                }
                
                // 发送到API进行分析
                const formData = new FormData();
                formData.append('image', frameBlob, 'frame.jpg');
                
                const response = await fetch('/api/navigation/visual_guidance', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // 根据模式使用对应的显示函数
                    if (productModeActive) {
                        displayVisualGuidanceForProduct(data.guidance, data.vision_summary);
                    } else {
                        displayVisualGuidance(data.guidance, data.vision_summary);
                    }
                } else {
                    console.error('视觉导航分析失败:', data.error);
                }
            } catch (err) {
                console.error('视觉导航分析错误:', err);
            }
        }
        
        /**
         * 普通模式：从视频获取帧Blob
         * @returns {Promise<Blob|null>}
         */
        function _getFrameBlobForNormalMode() {
            return new Promise((resolve) => {
                try {
                    ensureDOMElements();
                    const videoEl = getVideo();
                    const canvasEl = getCanvas();
                    if (!videoEl || !canvasEl) {
                        console.error('无法找到视频或画布元素');
                        resolve(null);
                        return;
                    }
                    canvasEl.width = videoEl.videoWidth;
                    canvasEl.height = videoEl.videoHeight;
                    const ctx = canvasEl.getContext('2d');
                    ctx.drawImage(videoEl, 0, 0);
                    
                    canvasEl.toBlob((blob) => {
                        resolve(blob);
                    }, 'image/jpeg', 0.8);
                } catch (err) {
                    console.error('获取普通模式视频帧失败:', err);
                    resolve(null);
                }
            });
        }
        
        /**
         * 产品模式：从视频获取帧Blob
         * @returns {Promise<Blob|null>}
         */
        function _getFrameBlobForProductMode() {
            return new Promise((resolve) => {
                try {
                    const productVideo = document.getElementById('productVideo');
                    const productCanvas = document.getElementById('productCanvas');
                    
                    if (!productVideo || !productVideo.srcObject) {
                        console.warn('⚠️ 摄像头未就绪');
                        resolve(null);
                        return;
                    }
                    
                    if (productVideo.readyState < 2) {
                        console.warn('⚠️ 视频未就绪（readyState=' + productVideo.readyState + '）');
                        resolve(null);
                        return;
                    }
                    
                    // 设置分析标志
                    if (window.isAnalyzingVision) {
                        resolve(null); // 如果正在分析，跳过
                        return;
                    }
                    window.isAnalyzingVision = true;
                    
                    // 更新状态：显示正在扫描
                    const guidanceMessages = document.getElementById('guidanceMessages');
                    if (guidanceMessages) {
                        guidanceMessages.innerHTML = '<div style="color:#FF9800;">🔍 正在扫描环境...</div>';
                    }
                    
                    // 从视频获取当前帧（确保尺寸有效）
                    if (productVideo.videoWidth === 0 || productVideo.videoHeight === 0) {
                        console.warn('⚠️ 视频尺寸无效，等待中...');
                        window.isAnalyzingVision = false;
                        resolve(null);
                        return;
                    }
                    
                    productCanvas.width = productVideo.videoWidth;
                    productCanvas.height = productVideo.videoHeight;
                    const ctx = productCanvas.getContext('2d');
                    
                    // 确保canvas尺寸有效
                    if (productCanvas.width === 0 || productCanvas.height === 0) {
                        console.warn('⚠️ Canvas尺寸无效');
                        window.isAnalyzingVision = false;
                        resolve(null);
                        return;
                    }
                    
                    ctx.drawImage(productVideo, 0, 0);
                    
                    // 镜头运动检测
                    const frameData = productCanvas.toDataURL('image/jpeg', 0.1);
                    detectCameraMotion(frameData);
                    
                    // 转换为Blob
                    productCanvas.toBlob((blob) => {
                        window.isAnalyzingVision = false; // 重置标志
                        if (!blob || blob.size === 0) {
                            console.warn('⚠️ Blob为空或无效');
                            resolve(null);
                            return;
                        }
                        console.log('📸 准备发送图片: 大小=' + blob.size + '字节, 类型=' + blob.type);
                        resolve(blob);
                    }, 'image/jpeg', 0.7);
                } catch (err) {
                    window.isAnalyzingVision = false;
                    console.error('获取产品模式视频帧失败:', err);
                    resolve(null);
                }
            });
        }
        
        // ========== 向后兼容：保留旧函数名（内部调用统一入口）==========
        /**
         * @deprecated 使用 analyzeVisualGuidanceFrame() 代替
         */
        async function analyzeVisualGuidance() {
            return analyzeVisualGuidanceFrame();
        }
        
        /**
         * @deprecated 使用 analyzeVisualGuidanceFrame() 代替
         */
        async function analyzeVisualGuidanceForProduct() {
            return analyzeVisualGuidanceFrame();
        }
        
        function displayVisualGuidance(guidance, visionSummary) {
            const messagesDiv = document.getElementById('guidanceMessages');
            let html = '';
            
            // 方向指示
            const directionIcons = {
                'forward': '⬆️',
                'left': '⬅️',
                'right': '➡️',
                'stop': '⛔'
            };
            
            const directionColors = {
                'forward': '#4CAF50',
                'left': '#2196F3',
                'right': '#FF9800',
                'stop': '#F44336'
            };
            
            const direction = guidance.direction || 'forward';
            const icon = directionIcons[direction] || '➡️';
            const color = directionColors[direction] || '#666';
            
            html += `<div style="font-size:24px; text-align:center; margin-bottom:15px; color:${color}; font-weight:bold;">
                ${icon} ${direction.toUpperCase()}
            </div>`;
            
            // 指引消息
            if (guidance.messages && guidance.messages.length > 0) {
                html += '<div style="margin-bottom:10px;">';
                guidance.messages.forEach(msg => {
                    html += `<div style="padding:8px; margin:5px 0; background:#f5f5f5; border-radius:5px; font-size:14px;">${msg}</div>`;
                });
                html += '</div>';
            }
            
            // 房间号
            if (guidance.room_numbers && guidance.room_numbers.length > 0) {
                html += `<div style="margin-top:10px; padding:8px; background:#e3f2fd; border-radius:5px;">
                    <strong>房间号：</strong>${guidance.room_numbers.join(', ')}
                </div>`;
            }
            
            // 检测摘要
            html += '<div style="margin-top:15px; padding:10px; background:#f9f9f9; border-radius:5px; font-size:12px; color:#666;">';
            html += `<div>检测到 ${visionSummary.objects_detected || 0} 个物体，${visionSummary.texts_detected || 0} 段文字</div>`;
            if (guidance.signboards && guidance.signboards.length > 0) {
                html += `<div>标识牌：${guidance.signboards.length} 个</div>`;
            }
            if (guidance.step_detected) {
                html += `<div style="color:#F44336;">⚠️ 检测到台阶</div>`;
            }
            if (guidance.hazards_count > 0) {
                html += `<div style="color:#F44336;">⚠️ 检测到 ${guidance.hazards_count} 个危险区域</div>`;
            }
            html += '</div>';
            
            messagesDiv.innerHTML = html;
        }
        
        // 完整产品模式功能
        function startProductMode() {
            // 确保函数暴露到全局作用域
            window.startProductMode = startProductMode;
            // 检查必要模块
            const productVideo = document.getElementById('productVideo');
            if (!productVideo) {
                showError('视频元素未找到');
                return;
            }
            
            // 显示状态
            document.getElementById('productModeStatus').style.display = 'block';
            document.getElementById('productGuidance').style.display = 'block';
            document.getElementById('productVoiceStatus').style.display = 'block';
            document.getElementById('startProductModeBtn').style.display = 'none';
            document.getElementById('stopProductModeBtn').style.display = 'block';
            
            productModeActive = true;
            
            // 更新状态
            updateProductStatus('正在启动...');
            
            // 1. 自动开启摄像头（如果未开启）
            if (!productVideo.srcObject) {
                updateProductStatus('正在开启摄像头...');
                startCameraForProduct().then((cameraStarted) => {
                    if (!cameraStarted) {
                        showError('摄像头启动失败，请检查权限设置');
                        productModeActive = false;
                        document.getElementById('startProductModeBtn').style.display = 'block';
                        document.getElementById('stopProductModeBtn').style.display = 'none';
                        return;
                    }
                    // 摄像头启动后，继续后续步骤
                    continueAfterCameraReady();
                }).catch((err) => {
                    console.error('摄像头启动失败:', err);
                    showError('摄像头启动失败，请检查权限设置');
                    productModeActive = false;
                    document.getElementById('startProductModeBtn').style.display = 'block';
                    document.getElementById('stopProductModeBtn').style.display = 'none';
                });
            } else {
                // 摄像头已开启，直接继续
                continueAfterCameraReady();
            }
            
            // 继续后续步骤的函数
            function continueAfterCameraReady() {
                // 等待摄像头就绪（增加超时保护）
                new Promise((resolve, reject) => {
                    let checkCount = 0;
                    const maxChecks = 50; // 最多等待5秒
                    const checkReady = () => {
                        checkCount++;
                        if (productVideo.readyState >= 2) {
                            console.log('✅ 摄像头已就绪');
                            resolve();
                        } else if (checkCount >= maxChecks) {
                            console.warn('⚠️ 摄像头就绪超时');
                            reject(new Error('摄像头就绪超时'));
                        } else {
                            setTimeout(checkReady, 100);
                        }
                    };
                    checkReady();
                }).then(() => {
                    // 2. 立即启动视觉导航（自动环境扫描，不阻塞）
                    updateProductStatus('启动环境扫描...');
                    console.log('🎥 启动视觉导航...');
                    // 不等待，立即开始（异步），自动开始扫描
                    startVisualNavigationForProduct();
                    
                    // 3. 启动语音监听
                    updateProductStatus('启动语音监听...');
                    console.log('🎤 启动语音监听...');
                    return startVoiceListening();
                }).then(() => {
                    // 启动完成
                    console.log('✅ 产品模式启动完成');
                }).catch((err) => {
                    console.error('摄像头就绪失败:', err);
                    showError('摄像头就绪失败，请刷新页面重试');
                    productModeActive = false;
                    document.getElementById('startProductModeBtn').style.display = 'block';
                    document.getElementById('stopProductModeBtn').style.display = 'none';
                });
            }
            
            // 更新状态显示
            const voiceStatusDiv = document.getElementById('voiceStatusText');
            if (voiceStatusDiv) {
                voiceStatusDiv.innerHTML = '<span style="color:#4CAF50;">✅ 正在监听语音...</span>';
            }
            
            // 4. 播放欢迎语音（立即播放，不等待用户交互）
            // 注意：Mac上摄像头启动后可以立即播放，不需要等待用户交互
            updateProductStatus('产品模式运行中 - 自动环境扫描已开启');
            showSuccess('完整产品模式已启动，环境扫描和语音提示已自动开启');
            
            // 立即尝试播放欢迎语音（不阻塞）
            // 注意：由于用户已经点击了按钮，这个点击事件可以用于触发音频播放
            setTimeout(async () => {
                try {
                    debugLog('准备播放欢迎语音...', 'info');
                    await speakText('Luna已启动，开始环境扫描，我将主动为您提示周围环境', 'calm', false);
                    debugLog('✅ 欢迎语音已发送到播放队列', 'info');
                } catch (err) {
                    debugLog(`⚠️ 欢迎语音播放失败: ${err.message}`, 'warn');
                    console.error('欢迎语音播放错误:', err);
                    // 如果自动播放失败，等待用户交互
                    const playWelcomeOnce = async () => {
                        try {
                            debugLog('用户交互后尝试播放欢迎语音...', 'info');
                            await speakText('Luna已启动，开始环境扫描，我将主动为您提示周围环境', 'calm', false);
                            debugLog('✅ 用户交互后欢迎语音已播放', 'info');
                        } catch (e) {
                            debugLog(`❌ 用户交互后播放也失败: ${e.message}`, 'error');
                            console.error('用户交互后播放错误:', e);
                        }
                        document.removeEventListener('click', playWelcomeOnce);
                        document.removeEventListener('touchstart', playWelcomeOnce);
                    };
                    document.addEventListener('click', playWelcomeOnce, { once: true });
                    document.addEventListener('touchstart', playWelcomeOnce, { once: true });
                }
            }, 1000); // 延迟1秒确保摄像头已启动
        }
        
        function stopProductMode() {
            productModeActive = false;
            
            // 停止视觉导航
            stopVisualNavigation();
            
            // 停止语音监听
            stopVoiceListening();
            
            // 停止摄像头
            stopCameraForProduct();
            
            // 隐藏状态
            document.getElementById('productModeStatus').style.display = 'none';
            document.getElementById('productGuidance').style.display = 'none';
            document.getElementById('productVoiceStatus').style.display = 'none';
            document.getElementById('startProductModeBtn').style.display = 'block';
            document.getElementById('stopProductModeBtn').style.display = 'none';
            
            showSuccess('产品模式已停止');
        }
        
        async function startCameraForProduct() {
            try {
                const productVideo = document.getElementById('productVideo');
                if (!productVideo) {
                    showError('视频元素未找到');
                    return false;
                }
                
                const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
                const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
                // 修复：更准确的HTTPS检测（包括IP地址访问）
                const isSecureContext = window.location.protocol === 'https:' || 
                                       window.location.hostname === 'localhost' || 
                                       window.location.hostname === '127.0.0.1' ||
                                       window.isSecureContext === true; // 使用浏览器原生API
                
                console.log('🔍 摄像头启动检查:', {
                    isSafari, isIOS, isSecureContext,
                    protocol: window.location.protocol,
                    hostname: window.location.hostname,
                    href: window.location.href,
                    isSecureContext_native: window.isSecureContext,
                    userAgent: navigator.userAgent,
                    hasMediaDevices: !!navigator.mediaDevices,
                    hasGetUserMedia: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)
                });
                
                // 在页面上显示调试信息（iPhone Safari无法使用控制台）
                debugLog(`协议: ${window.location.protocol}`, 'info');
                debugLog(`地址: ${window.location.href}`, 'info');
                debugLog(`安全上下文: ${window.isSecureContext ? '是' : '否'}`, window.isSecureContext ? 'info' : 'warn');
                debugLog(`iOS: ${isIOS}, Safari: ${isSafari}`, 'info');
                
                // iOS Safari 在HTTP模式下无法使用摄像头（修复：使用原生isSecureContext）
                const actuallySecure = window.isSecureContext !== undefined ? window.isSecureContext : isSecureContext;
                
                if (isIOS && !actuallySecure) {
                    const errorMsg = `⚠️ iOS Safari浏览器需要HTTPS才能访问摄像头\n\n当前协议: ${window.location.protocol}\n当前地址: ${window.location.href}\n\n解决方案：\n1. 确保使用 https:// 访问\n2. 信任自签名证书\n3. 或使用Chrome浏览器`;
                    showError(errorMsg);
                    updateProductStatus('❌ iOS Safari需要HTTPS（当前: ' + window.location.protocol + '）');
                    
                    // 显示更详细的提示
                    const statusDiv = document.getElementById('productStatusDetails');
                    if (statusDiv) {
                        statusDiv.innerHTML = `
                            <div style="color:#F44336; font-weight:bold; margin-bottom:10px;">⚠️ iOS Safari限制</div>
                            <div style="font-size:13px; line-height:1.6; color:#666;">
                                当前协议: <strong>${window.location.protocol}</strong><br>
                                当前地址: <strong>${window.location.href}</strong><br>
                                安全上下文: <strong>${window.isSecureContext ? '是' : '否'}</strong><br><br>
                                iOS Safari浏览器出于安全考虑，在HTTP模式下无法使用摄像头和麦克风。<br><br>
                                <strong>解决方案：</strong><br>
                                1. 📱 确保使用 <code>https://</code> 访问（不是 http://）<br>
                                2. 🔒 信任自签名证书（点击"访问此网站"）<br>
                                3. 🌐 或使用Chrome浏览器访问
                            </div>
                        `;
                    }
                    return false;
                }
                
                // Safari桌面版也需要HTTPS
                if (isSafari && !isIOS && !actuallySecure) {
                    const errorMsg = `⚠️ Safari浏览器需要HTTPS才能访问摄像头\n\n当前协议: ${window.location.protocol}\n建议：\n1. 使用 https:// 访问\n2. 或使用Chrome浏览器测试`;
                    showError(errorMsg);
                    updateProductStatus('摄像头启动失败：需要HTTPS（当前: ' + window.location.protocol + '）');
                    return false;
                }
                
                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    const errorMsg = `您的浏览器不支持摄像头访问\n\n建议使用Chrome、Edge或Firefox浏览器`;
                    showError(errorMsg);
                    updateProductStatus('摄像头启动失败：浏览器不支持');
                    return false;
                }
                
                updateProductStatus('正在请求摄像头权限...');
                console.log('📹 正在请求摄像头权限...');
                debugLog('正在请求摄像头权限...', 'info');
                
                // 简化摄像头请求参数，提高兼容性
                let stream = null;
                try {
                    // 先尝试后置摄像头（environment）
                    stream = await navigator.mediaDevices.getUserMedia({ 
                        video: { 
                            facingMode: 'environment',
                            width: { ideal: 640 },
                            height: { ideal: 480 }
                        }
                    });
                    console.log('✅ 后置摄像头获取成功');
                    debugLog('✅ 后置摄像头获取成功', 'info');
                } catch (err1) {
                    console.warn('⚠️ 后置摄像头获取失败，尝试前置摄像头:', err1);
                    debugLog(`⚠️ 后置摄像头失败: ${err1.name} - ${err1.message}`, 'warn');
                    try {
                        // 如果后置摄像头失败，尝试前置摄像头
                        stream = await navigator.mediaDevices.getUserMedia({ 
                            video: { 
                                facingMode: 'user',
                                width: { ideal: 640 },
                                height: { ideal: 480 }
                            }
                        });
                        console.log('✅ 前置摄像头获取成功');
                        debugLog('✅ 前置摄像头获取成功', 'info');
                    } catch (err2) {
                        console.warn('⚠️ 前置摄像头也失败，尝试最简单配置:', err2);
                        debugLog(`⚠️ 前置摄像头也失败: ${err2.name} - ${err2.message}`, 'warn');
                        // 最后尝试最简单的配置
                        stream = await navigator.mediaDevices.getUserMedia({ 
                            video: true
                        });
                        console.log('✅ 默认摄像头配置获取成功');
                        debugLog('✅ 默认摄像头配置获取成功', 'info');
                    }
                }
                
                if (!stream) {
                    throw new Error('无法获取摄像头流');
                }
                
                console.log('✅ 摄像头权限已授予，流已获取');
                debugLog('✅ 摄像头权限已授予', 'info');
                console.log('📹 流信息:', {
                    active: stream.active,
                    id: stream.id,
                    tracks: stream.getTracks().map(t => ({
                        kind: t.kind,
                        enabled: t.enabled,
                        readyState: t.readyState,
                        settings: t.getSettings()
                    }))
                });
                
                updateProductStatus('正在设置视频流...');
                
                // 停止之前的流（如果有）
                if (productVideo.srcObject) {
                    const oldStream = productVideo.srcObject;
                    oldStream.getTracks().forEach(track => track.stop());
                }
                
                productVideo.srcObject = stream;
                productVideo.setAttribute('playsinline', 'true');
                productVideo.setAttribute('webkit-playsinline', 'true');
                productVideo.setAttribute('autoplay', 'true');
                productVideo.muted = false; // 确保不是静音状态
                
                // 等待视频元数据加载（增加超时）
                updateProductStatus('正在加载视频元数据...');
                await new Promise((resolve, reject) => {
                    let resolved = false;
                    const timeout = setTimeout(() => {
                        if (!resolved) {
                            resolved = true;
                            console.error('❌ 视频元数据加载超时');
                            reject(new Error('视频元数据加载超时'));
                        }
                    }, 10000); // 10秒超时
                    
                    productVideo.onloadedmetadata = () => {
                        if (!resolved) {
                            resolved = true;
                            clearTimeout(timeout);
                            console.log('✅ 视频元数据已加载:', {
                                videoWidth: productVideo.videoWidth,
                                videoHeight: productVideo.videoHeight,
                                readyState: productVideo.readyState
                            });
                            resolve();
                        }
                    };
                    
                    productVideo.onerror = (err) => {
                        if (!resolved) {
                            resolved = true;
                            clearTimeout(timeout);
                            console.error('❌ 视频加载错误:', err);
                            reject(err);
                        }
                    };
                    
                    // 如果已经加载完成，立即resolve
                    if (productVideo.readyState >= 1) {
                        if (!resolved) {
                            resolved = true;
                            clearTimeout(timeout);
                            console.log('✅ 视频已就绪（readyState=' + productVideo.readyState + '）');
                            resolve();
                        }
                    }
                });
                
                updateProductStatus('正在播放视频...');
                console.log('📹 准备播放视频...');
                
                // 尝试播放视频
                try {
                    await productVideo.play();
                    console.log('✅ 视频播放已启动');
                } catch (playErr) {
                    console.warn('⚠️ 自动播放失败，尝试用户交互后播放:', playErr);
                    // 如果自动播放失败，等待用户交互
                    updateProductStatus('请点击页面以启用摄像头画面');
                    // 添加点击事件来触发播放
                    const playOnClick = async () => {
                        try {
                            await productVideo.play();
                            console.log('✅ 用户交互后视频播放成功');
                            updateProductStatus('✅ 摄像头已开启并运行中');
                        } catch (e) {
                            console.error('❌ 用户交互后播放也失败:', e);
                        }
                        document.removeEventListener('click', playOnClick);
                        document.removeEventListener('touchstart', playOnClick);
                    };
                    document.addEventListener('click', playOnClick, { once: true });
                    document.addEventListener('touchstart', playOnClick, { once: true });
                }
                
                // 保存stream引用以便后续停止
                window.productVideoStream = stream;
                
                // 添加视频事件监听
                productVideo.onplay = () => {
                    console.log('✅ 视频正在播放');
                    updateProductStatus('✅ 摄像头已开启并运行中');
                };
                
                productVideo.onloadeddata = () => {
                    console.log('✅ 视频数据已加载');
                    updateProductStatus('✅ 摄像头已开启并运行中');
                };
                
                productVideo.oncanplay = () => {
                    console.log('✅ 视频可以播放');
                    updateProductStatus('✅ 摄像头已开启并运行中');
                };
                
                productVideo.onerror = (err) => {
                    console.error('❌ 视频播放错误:', err);
                    updateProductStatus('❌ 摄像头播放失败');
                    showError('摄像头播放失败，请刷新页面重试');
                };
                
                // 检查视频是否真的在播放
                setTimeout(() => {
                    if (productVideo.readyState >= 2 && productVideo.videoWidth > 0) {
                        console.log('✅ 摄像头确认运行中:', {
                            readyState: productVideo.readyState,
                            videoWidth: productVideo.videoWidth,
                            videoHeight: productVideo.videoHeight,
                            paused: productVideo.paused,
                            ended: productVideo.ended
                        });
                        updateProductStatus('✅ 摄像头已开启并运行中');
                    } else {
                        console.warn('⚠️ 摄像头可能未正常启动:', {
                            readyState: productVideo.readyState,
                            videoWidth: productVideo.videoWidth,
                            videoHeight: productVideo.videoHeight,
                            paused: productVideo.paused
                        });
                        updateProductStatus('⚠️ 摄像头启动中，请稍候...');
                    }
                }, 2000);
                
                return true;
            } catch (err) {
                console.error('❌ 摄像头启动失败:', err);
                debugLog(`❌ 摄像头启动失败: ${err.name} - ${err.message}`, 'error');
                let errorMsg = '无法访问摄像头: ';
                if (err.name === 'NotAllowedError') {
                    errorMsg += '请允许浏览器访问摄像头权限\\n\\n请在浏览器设置中允许摄像头访问';
                } else if (err.name === 'NotFoundError') {
                    errorMsg += '未找到摄像头设备\\n\\n请检查摄像头是否已连接';
                } else if (err.name === 'NotReadableError') {
                    errorMsg += '摄像头被其他程序占用\\n\\n请关闭其他使用摄像头的应用';
                } else {
                    errorMsg += (err.message || '未知错误');
                }
                showError(errorMsg);
                updateProductStatus('❌ 摄像头启动失败: ' + err.name);
                return false;
            }
        }
        
        function stopCameraForProduct() {
            const productVideo = document.getElementById('productVideo');
            if (productVideo && productVideo.srcObject) {
                const stream = productVideo.srcObject;
                stream.getTracks().forEach(track => track.stop());
                productVideo.srcObject = null;
            }
            if (window.productVideoStream) {
                window.productVideoStream.getTracks().forEach(track => track.stop());
                window.productVideoStream = null;
            }
        }
        
        async function startVisualNavigationForProduct() {
            const productVideo = document.getElementById('productVideo');
            const productCanvas = document.getElementById('productCanvas');
            
            if (!productVideo || !productVideo.srcObject) {
                console.warn('摄像头未就绪，等待中...');
                // 等待摄像头就绪
                await new Promise(resolve => {
                    const checkReady = () => {
                        if (productVideo && productVideo.srcObject && productVideo.readyState >= 2) {
                            resolve();
                        } else {
                            setTimeout(checkReady, 100);
                        }
                    };
                    checkReady();
                });
            }
            
            // 显示结果区域
            document.getElementById('productGuidance').style.display = 'block';
            document.getElementById('guidanceMessages').innerHTML = '<div style="color:#4CAF50;">🎥 环境扫描已启动，正在分析周围环境...</div>';
            
            // 优化：降低检测频率到1-2秒，提高响应速度
            let lastFrameTime = 0;
            let frameSkipCount = 0;
            // 每3帧检测一次(约0.5-1秒,假设30fps)
            // 优化:提高检测频率
            const FRAME_SKIP = 3;
            // 最小间隔0.8秒(优化:提高响应速度,目标<1秒)
            const MIN_INTERVAL = 800;
            let isAnalyzing = false; // 防止并发分析
            
            function analyzeFrame() {
                if (!productModeActive) return;
                
                const now = Date.now();
                frameSkipCount++;
                
                // 如果正在分析中，跳过本次
                if (isAnalyzing) {
                    requestAnimationFrame(analyzeFrame);
                    return;
                }
                
                // 检查时间间隔和帧数
                if (now - lastFrameTime < MIN_INTERVAL || frameSkipCount < FRAME_SKIP) {
                    requestAnimationFrame(analyzeFrame);
                    return;
                }
                
                frameSkipCount = 0;
                lastFrameTime = now;
                
                // 执行检测（异步，不阻塞）- 使用统一入口
                analyzeVisualGuidanceFrame().finally(() => {
                    isAnalyzing = false;
                });
                
                // 继续下一帧
                requestAnimationFrame(analyzeFrame);
            }
            
            // 开始检测循环
            requestAnimationFrame(analyzeFrame);
            
            // 立即执行一次（不等待）- 使用统一入口
            analyzeVisualGuidanceFrame();
        }
        // 调试日志函数（在页面上显示，方便iPhone Safari调试）
        function debugLog(message, type = 'info') {
            const debugDiv = document.getElementById('debugInfo');
            const debugLogDiv = document.getElementById('debugLog');
            if (debugDiv && debugLogDiv) {
                debugDiv.style.display = 'block';
                const time = new Date().toLocaleTimeString();
                const color = type === 'error' ? '#F44336' : type === 'warn' ? '#FF9800' : '#2196F3';
                const icon = type === 'error' ? '❌' : type === 'warn' ? '⚠️' : 'ℹ️';
                debugLogDiv.innerHTML += `<div style="color:${color}; margin-bottom:3px;">[${time}] ${icon} ${message}</div>`;
                // 自动滚动到底部
                debugDiv.scrollTop = debugDiv.scrollHeight;
            }
            // 同时输出到控制台（如果可用）
            if (console && console.log) {
                console.log(message);
            }
        }
        
        function updateProductStatus(text) {
            const statusDiv = document.getElementById('productStatusDetails');
            if (statusDiv) {
                statusDiv.innerHTML = `<div>${new Date().toLocaleTimeString()}</div><div>${text}</div>`;
            }
        }
        
        // 持续语音监听模式（优化版：实时检测）
        function startVoiceListening() {
            // 确保函数暴露到全局作用域
            window.startVoiceListening = startVoiceListening;
            if (voiceListeningInterval) {
                console.log('⚠️ 语音监听已在运行中');
                return Promise.resolve(); // 已在运行
            }
            
            // 保持音频流持续开启，避免重复请求权限
            let continuousAudioStream = null;
            let isRecording = false;
            
            console.log('🎤 开始启动语音监听...');
            updateProductStatus('正在请求麦克风权限...');
            
            return navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
                continuousAudioStream = stream;
                console.log('✅ 麦克风权限已授予');
                updateProductStatus('✅ 麦克风已开启，正在监听...');
                return stream;
            }).catch((err) => {
                console.error('❌ 无法获取音频流:', err);
                let errorMsg = '无法访问麦克风: ';
                if (err.name === 'NotAllowedError') {
                    errorMsg += '请允许浏览器访问麦克风权限';
                } else if (err.name === 'NotFoundError') {
                    errorMsg += '未找到麦克风设备';
                } else {
                    errorMsg += err.message || '未知错误';
                }
                showError(errorMsg);
                updateProductStatus('❌ 麦克风启动失败: ' + err.name);
                throw err;
            }).then((stream) => {
                if (!stream) return;
                
                // 使用AudioContext进行实时语音检测
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const analyser = audioContext.createAnalyser();
                const microphone = audioContext.createMediaStreamSource(continuousAudioStream);
                microphone.connect(analyser);
                
                analyser.fftSize = 128; // 优化：降低FFT大小减少计算量
                const bufferLength = analyser.frequencyBinCount;
                const dataArray = new Uint8Array(bufferLength);
                
                // 语音活动检测参数
                const SILENCE_THRESHOLD = 30; // 静音阈值
                const SPEECH_THRESHOLD = 50;  // 语音阈值
                let silenceCount = 0;
                let speechCount = 0;
                let recordingStartTime = null;
                const MIN_RECORDING_TIME = 0.5; // 最小录音时间（秒）
                const MAX_RECORDING_TIME = 2.0;  // 最大录音时间（秒）
                
                let audioChunksForVAD = [];
                let mediaRecorderForVAD = null;
                
                // 开始录音
                function startRecording() {
                    if (isRecording) return;
                    
                    isRecording = true;
                    recordingStartTime = Date.now();
                    audioChunksForVAD = [];
                    
                    let options = {};
                    if (MediaRecorder.isTypeSupported('audio/webm')) {
                        options = { mimeType: 'audio/webm' };
                    } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
                        options = { mimeType: 'audio/mp4' };
                    }
                    
                    mediaRecorderForVAD = new MediaRecorder(continuousAudioStream, options);
                    
                    mediaRecorderForVAD.ondataavailable = (event) => {
                        if (event.data && event.data.size > 0) {
                            audioChunksForVAD.push(event.data);
                        }
                    };
                    
                    mediaRecorderForVAD.onstop = () => {
                        if (audioChunksForVAD.length > 0) {
                            const audioBlob = new Blob(audioChunksForVAD, { type: mediaRecorderForVAD.mimeType || 'audio/webm' });
                            recognizeAndRespond(audioBlob).catch((err) => {
                                console.error('语音识别失败:', err);
                            });
                        }
                        isRecording = false;
                    };
                    
                    mediaRecorderForVAD.start();
                    
                    // 更新状态
                    const voiceStatusDiv = document.getElementById('voiceStatusText');
                    if (voiceStatusDiv) {
                        voiceStatusDiv.innerHTML = '<span style="color:#F44336;">🔴 正在录音...</span>';
                    }
                }
                
                // 停止录音
                function stopRecording() {
                    if (!isRecording || !mediaRecorderForVAD) return;
                    
                    const recordingDuration = (Date.now() - recordingStartTime) / 1000;
                    
                    // 如果录音时间太短，忽略
                    if (recordingDuration < MIN_RECORDING_TIME) {
                        isRecording = false;
                        return;
                    }
                    
                    if (mediaRecorderForVAD.state !== 'inactive') {
                        mediaRecorderForVAD.stop();
                    }
                    
                    // 更新状态：显示正在识别
                    const voiceStatusDiv = document.getElementById('voiceStatusText');
                    if (voiceStatusDiv) {
                        voiceStatusDiv.innerHTML = '<span style="color:#FF9800;">🟡 正在识别...</span>';
                    }
                }
                
                // 实时检测循环（优化：降低检测频率到200ms）
                function detectVoiceActivity() {
                    if (!productModeActive) {
                        if (isRecording) {
                            stopRecording();
                        }
                        return;
                    }
                    
                    analyser.getByteFrequencyData(dataArray);
                    
                    // 计算平均音量
                    let sum = 0;
                    for (let i = 0; i < bufferLength; i++) {
                        sum += dataArray[i];
                    }
                    const average = sum / bufferLength;
                    
                    if (average > SPEECH_THRESHOLD) {
                        // 检测到语音
                        speechCount++;
                        silenceCount = 0;
                        
                        if (!isRecording && speechCount > 2) {
                            // 连续2次检测到语音，开始录音
                            startRecording();
                        }
                    } else if (average < SILENCE_THRESHOLD) {
                        // 检测到静音
                        silenceCount++;
                        speechCount = 0;
                        
                        if (isRecording) {
                            const recordingDuration = (Date.now() - recordingStartTime) / 1000;
                            
                            // 如果静音超过0.5秒或录音超过最大时间，停止录音
                            if (silenceCount > 5 || recordingDuration >= MAX_RECORDING_TIME) {
                                stopRecording();
                            }
                        }
                    } else {
                        // 中间状态，重置计数
                        speechCount = Math.max(0, speechCount - 1);
                        silenceCount = Math.max(0, silenceCount - 1);
                    }
                    
                    // 优化：200ms检测一次（而不是每帧）
                    setTimeout(detectVoiceActivity, 200);
                }
                
                // 开始检测
                console.log('✅ 语音活动检测已启动');
                detectVoiceActivity();
                
                // 保存引用以便停止
                voiceListeningInterval = {
                    stop: () => {
                        console.log('🛑 停止语音监听...');
                        if (continuousAudioStream) {
                            continuousAudioStream.getTracks().forEach(track => track.stop());
                        }
                        if (audioContext) {
                            audioContext.close();
                        }
                        if (mediaRecorderForVAD && mediaRecorderForVAD.state !== 'inactive') {
                            mediaRecorderForVAD.stop();
                        }
                        voiceListeningInterval = null;
                        const voiceStatusDiv = document.getElementById('voiceStatusText');
                        if (voiceStatusDiv) {
                            voiceStatusDiv.innerHTML = '<span style="color:#999;">已停止监听</span>';
                        }
                    }
                };
            });
        }
        
        function stopVoiceListening() {
            if (voiceListeningInterval) {
                if (typeof voiceListeningInterval.stop === 'function') {
                    voiceListeningInterval.stop();
                } else {
                    clearInterval(voiceListeningInterval);
                }
                voiceListeningInterval = null;
            }
            const voiceStatusDiv = document.getElementById('voiceStatusText');
            if (voiceStatusDiv) {
                voiceStatusDiv.textContent = '语音监听已停止';
            }
            const voiceResultDiv = document.getElementById('voiceRecognitionResult');
            if (voiceResultDiv) {
                voiceResultDiv.style.display = 'none';
            }
        }
        
        async function captureAndRecognizeVoice() {
            try {
                // 更新状态：显示正在录音
                const voiceStatusDiv = document.getElementById('voiceStatusText');
                if (voiceStatusDiv) {
                    voiceStatusDiv.innerHTML = '<span style="color:#F44336;">🔴 正在录音...</span>';
                }
                
                const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
                audioChunks = [];
                
                let options = {};
                if (MediaRecorder.isTypeSupported('audio/webm')) {
                    options = { mimeType: 'audio/webm' };
                } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
                    options = { mimeType: 'audio/mp4' };
                }
                
                const recorder = new MediaRecorder(audioStream, options);
                
                recorder.ondataavailable = (event) => {
                    if (event.data && event.data.size > 0) {
                        audioChunks.push(event.data);
                    }
                };
                
                recorder.onstop = async () => {
                    // 更新状态：显示正在识别
                    if (voiceStatusDiv) {
                        voiceStatusDiv.innerHTML = '<span style="color:#FF9800;">🟡 正在识别...</span>';
                    }
                    
                    const audioBlob = new Blob(audioChunks, { type: recorder.mimeType || 'audio/webm' });
                    await recognizeAndRespond(audioBlob);
                    
                    // 更新状态：显示监听中
                    if (voiceStatusDiv) {
                        voiceStatusDiv.innerHTML = '<span style="color:#1976D2;">🎤 正在监听...</span>';
                    }
                    
                    audioStream.getTracks().forEach(track => track.stop());
                };
                
                recorder.start();
                
                // 录音1.5秒
                setTimeout(() => {
                    if (recorder.state !== 'inactive') {
                        recorder.stop();
                    }
                }, 1500);
            } catch (err) {
                console.error('启动录音失败:', err);
                const voiceStatusDiv = document.getElementById('voiceStatusText');
                if (voiceStatusDiv) {
                    voiceStatusDiv.innerHTML = '<span style="color:#F44336;">❌ 录音失败: ' + (err.message || '未知错误') + '</span>';
                }
            }
        }
        
        async function recognizeAndRespond(audioBlob) {
            try {
                const formData = new FormData();
                formData.append('audio', audioBlob);
                
                const response = await fetch('/api/recognize/voice', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                // 显示识别结果（无论成功与否）
                const voiceResultDiv = document.getElementById('voiceRecognitionResult');
                if (voiceResultDiv) {
                    voiceResultDiv.style.display = 'block';
                }
                
                if (data.success && data.text && data.text.trim()) {
                    const recognizedText = data.text.trim();
                    const now = Date.now();
                    
                    // 避免重复识别（3秒内相同文本）
                    if (now - lastVoiceRecognitionTime < 3000) {
                        if (voiceResultDiv) {
                            voiceResultDiv.innerHTML = '<div style="color:#999;">识别中（避免重复）...</div>';
                        }
                        return;
                    }
                    lastVoiceRecognitionTime = now;
                    
                    // 显示识别结果
                    if (voiceResultDiv) {
                        voiceResultDiv.innerHTML = 
                            `<div style="color:#1976D2;"><strong>识别：</strong>${recognizedText}</div>`;
                    }
                    
                    // 处理语音指令
                    await processVoiceCommand(recognizedText);
                } else {
                    // 识别失败或没有识别到内容
                    if (voiceResultDiv) {
                        const errorMsg = data.error || '未识别到语音内容';
                        voiceResultDiv.innerHTML = `<div style="color:#999;">${errorMsg}</div>`;
                    }
                    console.log('语音识别结果:', data);
                }
            } catch (err) {
                console.error('语音识别错误:', err);
                const voiceResultDiv = document.getElementById('voiceRecognitionResult');
                if (voiceResultDiv) {
                    voiceResultDiv.style.display = 'block';
                    voiceResultDiv.innerHTML = `<div style="color:#F44336;">识别错误: ${err.message}</div>`;
                }
            }
        }
        
        async function processVoiceCommand(text) {
            const lowerText = text.toLowerCase();
            
            // 导航相关指令
            if (lowerText.includes('导航') || lowerText.includes('去') || lowerText.includes('到')) {
                // 提取目的地
                const destinationMatch = text.match(/(?:去|到|导航)(.+)/);
                if (destinationMatch) {
                    const destination = destinationMatch[1].trim();
                    await speakText(`好的，我将为您导航到${destination}`, 'cheerful');
                    // 这里可以调用导航API
                }
            }
            // 停止指令
            else if (lowerText.includes('停止') || lowerText.includes('暂停')) {
                await speakText('好的，已暂停', 'calm');
            }
            // 继续指令
            else if (lowerText.includes('继续') || lowerText.includes('恢复')) {
                await speakText('好的，继续导航', 'cheerful');
            }
            // 帮助指令
            else if (lowerText.includes('帮助') || lowerText.includes('怎么用')) {
                await speakText('我可以帮您导航、识别物体、检测障碍。请告诉我您要去哪里', 'calm');
            }
            // 默认响应
            else {
                await speakText('我听到了，请告诉我您需要什么帮助', 'calm');
            }
        }
        
        // ========== 优先级TTS播放队列管理器（ChatGPT建议优化）==========
        class PriorityTTSQueue {
            constructor() {
                this.currentAudio = null;
                this.currentPriority = 999; // 当前播放的优先级（数字越小优先级越高）
                this.queue = [];
                this.priorityLevels = {
                    'critical': 0,  // 台阶、危险（最高优先级）
                    'high': 1,      // 转向提示
                    'medium': 2,    // 标识牌
                    'low': 3        // 普通提示
                };
                this.stats = {
                    totalPlayed: 0,
                    totalInterrupted: 0,
                    latencyHistory: []
                };
            }
            
            getPriorityLevel(style, message) {
                // 根据消息内容和风格确定优先级
                if (message.includes('台阶') || message.includes('危险')) {
                    return this.priorityLevels.critical;
                } else if (message.includes('左转') || message.includes('右转')) {
                    return this.priorityLevels.high;
                } else if (message.includes('洗手间') || message.includes('电梯')) {
                    return this.priorityLevels.medium;
                } else {
                    return this.priorityLevels.low;
                }
            }
            
            async play(text, style = 'calm', priorityLevel = null) {
                const priority = priorityLevel !== null ? priorityLevel : this.getPriorityLevel(style, text);
                const triggerTime = Date.now();
                
                // 如果当前播放的优先级更低，中断它
                if (this.currentAudio && this.currentPriority > priority) {
                    console.log(`🔊 中断低优先级播放（优先级: ${this.currentPriority} -> ${priority}）`);
                    this.currentAudio.pause();
                    this.currentAudio.currentTime = 0;
                    this.currentAudio = null;
                    this.currentPriority = 999;
                    this.stats.totalInterrupted++;
                }
                
                // 如果正在播放且优先级相同或更高，加入队列
                if (this.currentAudio && this.currentPriority <= priority) {
                    this.queue.push({ text, style, priority, triggerTime });
                    console.log(`📋 加入队列（优先级: ${priority}）: ${text.substring(0, 20)}...`);
                    return;
                }
                
                // 立即播放
                this.currentAudio = await this._playAudio(text, style, priority, triggerTime);
                this.currentPriority = priority;
            }
            
            async _playAudio(text, style, priority, triggerTime) {
                const audio = await _playTTS(text, style);
                
                if (audio) {
                    // 记录播放开始时间
                    audio.onplay = () => {
                        const playTime = Date.now();
                        const latency = playTime - triggerTime;
                        this.stats.latencyHistory.push({
                            text: text.substring(0, 30),
                            latency: latency,
                            priority: priority,
                            timestamp: Date.now()
                        });
                        
                        // 只保留最近100条记录
                        if (this.stats.latencyHistory.length > 100) {
                            this.stats.latencyHistory.shift();
                        }
                        
                        // 如果延迟过大，记录警告
                        if (latency > 500) {
                            console.warn(`⚠️ 滞后提示: ${text.substring(0, 20)}..., 延迟: ${latency}ms`);
                        }
                    };
                    
                    // 播放结束
                    audio.onended = () => {
                        this.currentAudio = null;
                        this.currentPriority = 999;
                        this.stats.totalPlayed++;
                        
                        // 播放队列中的下一个（按优先级排序）
                        if (this.queue.length > 0) {
                            this.queue.sort((a, b) => a.priority - b.priority);
                            const next = this.queue.shift();
                            this.play(next.text, next.style, next.priority);
                        }
                    };
                }
                
                return audio;
            }
            
            getStats() {
                const latencies = this.stats.latencyHistory.map(h => h.latency);
                const avgLatency = latencies.length > 0 
                    ? latencies.reduce((a, b) => a + b, 0) / latencies.length 
                    : 0;
                const maxLatency = latencies.length > 0 ? Math.max(...latencies) : 0;
                
                return {
                    totalPlayed: this.stats.totalPlayed,
                    totalInterrupted: this.stats.totalInterrupted,
                    avgLatency: Math.round(avgLatency),
                    maxLatency: maxLatency,
                    queueLength: this.queue.length
                };
            }
        }
        
        // 创建全局优先级队列管理器
        const priorityTTSQueue = new PriorityTTSQueue();
        
        // TTS播放队列（保留兼容性）
        let ttsQueue = [];
        let isPlayingTTS = false;
        
        async function speakText(text, style = 'calm', priority = false) {
            // 使用新的优先级队列管理器
            const priorityLevel = priority ? priorityTTSQueue.priorityLevels.critical : priorityTTSQueue.priorityLevels.low;
            await priorityTTSQueue.play(text, style, priorityLevel);
        }
        
        async function _playTTS(text, style = 'calm') {
            isPlayingTTS = true;
            let audioElement = null;
            try {
                // 显示播放状态
                const playbackDiv = document.getElementById('voicePlaybackStatus');
                const playbackTextDiv = document.getElementById('playbackText');
                if (playbackDiv) {
                    playbackDiv.style.display = 'block';
                    playbackDiv.style.background = '#fff3cd';
                    if (playbackTextDiv) {
                        playbackTextDiv.textContent = text;
                    }
                }
                
                const startTime = Date.now();
                const response = await fetch('/api/tts', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ text, style })
                });
                
                const data = await response.json();
                
                const ttsTime = Date.now() - startTime;
                console.log(`TTS生成时间: ${ttsTime}ms${data.cached ? ' ⚡(缓存)' : ''}`);
                
                if (data.success && data.audio) {
                    // 直接使用base64数据创建Blob，避免额外请求
                    const base64Data = data.audio;
                    const byteCharacters = atob(base64Data);
                    const byteNumbers = new Array(byteCharacters.length);
                    for (let i = 0; i < byteCharacters.length; i++) {
                        byteNumbers[i] = byteCharacters.charCodeAt(i);
                    }
                    const byteArray = new Uint8Array(byteNumbers);
                    const audioBlob = new Blob([byteArray], { type: 'audio/mp3' });
                    const audioUrl = URL.createObjectURL(audioBlob);
                    const audio = new Audio(audioUrl);
                    audioElement = audio; // 保存引用，用于优先级队列管理
                    
                    // 设置初始音量
                    audio.volume = currentAudioVolume;
                    
                    // 添加到全局音频列表
                    if (!window.currentPlayingAudios) {
                        window.currentPlayingAudios = [];
                    }
                    window.currentPlayingAudios.push(audio);
                    
                    // 播放结束后从列表中移除
                    audio.onended = () => {
                        const index = window.currentPlayingAudios.indexOf(audio);
                        if (index > -1) {
                            window.currentPlayingAudios.splice(index, 1);
                        }
                    };
                    
                    // 播放开始
                    audio.onplay = () => {
                        const playTime = Date.now() - startTime;
                        console.log(`TTS总延迟: ${playTime}ms${data.cached ? ' ⚡(缓存)' : ''}`);
                        if (playbackDiv) {
                            playbackDiv.style.display = 'block';
                            playbackDiv.style.background = '#d4edda';
                            playbackDiv.innerHTML = '<div style="color:#155724;">🔊 正在播放语音...</div><div style="margin-top:5px; color:#666;">' + text + '</div>';
                        }
                    };
                    
                    // 播放结束
                    audio.onended = () => {
                        isPlayingTTS = false;
                        if (playbackDiv) {
                            playbackDiv.style.display = 'none';
                        }
                        URL.revokeObjectURL(audioUrl);
                        
                        // 播放队列中的下一个
                        if (ttsQueue.length > 0) {
                            const next = ttsQueue.shift();
                            _playTTS(next.text, next.style);
                        }
                    };
                    
                    // 播放错误
                    audio.onerror = (err) => {
                        isPlayingTTS = false;
                        console.error('音频播放错误:', err);
                        if (playbackDiv) {
                            playbackDiv.style.display = 'none';
                        }
                        URL.revokeObjectURL(audioUrl);
                        showError('语音播报失败，请检查音频权限');
                        
                        // 继续播放队列
                        if (ttsQueue.length > 0) {
                            const next = ttsQueue.shift();
                            _playTTS(next.text, next.style);
                        }
                    };
                    
                    // 尝试播放（添加用户交互检查和音量设置）
                    try {
                        // 确保音频已解锁
                        await unlockAudio();
                        
                        // 设置音量（使用当前音量设置）
                        audio.volume = currentAudioVolume;
                        
                        // 检查是否需要用户交互
                        const playPromise = audio.play();
                        
                        if (playPromise !== undefined) {
                            playPromise
                                .then(() => {
                                    console.log('✅ 音频播放成功');
                                })
                                .catch((playError) => {
                                    isPlayingTTS = false;
                                    console.error('播放失败:', playError);
                                    
                                    if (playError.name === 'NotAllowedError' || playError.name === 'NotSupportedError') {
                                        // 浏览器阻止自动播放，需要用户交互
                                        const errorMsg = '需要用户交互才能播放音频。请点击页面任意位置后，音频将自动播放。如果问题持续，请检查浏览器音频权限设置。';
                                        showError(errorMsg);
                                        
                                        // 尝试解锁音频（使用Promise链式调用，不使用await）
                                        unlockAudio().then(() => {
                                            // 添加点击事件监听，用户点击后重试播放
                                            const retryPlay = async () => {
                                                try {
                                                    await unlockAudio();
                                                    audio.volume = currentAudioVolume;
                                                    await audio.play();
                                                    console.log('✅ 用户交互后播放成功');
                                                    document.removeEventListener('click', retryPlay);
                                                    document.removeEventListener('touchstart', retryPlay);
                                                } catch (e) {
                                                    console.error('重试播放失败:', e);
                                                    showError('播放失败: ' + (e.message || '请检查浏览器音频权限设置'));
                                                }
                                            };
                                            
                                            document.addEventListener('click', retryPlay, { once: true });
                                            document.addEventListener('touchstart', retryPlay, { once: true });
                                        }).catch((err) => {
                                            console.error('解锁音频失败:', err);
                                        });
                                    } else {
                                        showError(`语音播报失败: ${playError.message || '未知错误'}\n\n错误类型: ${playError.name}`);
                                    }
                                    
                                    if (playbackDiv) {
                                        playbackDiv.style.display = 'none';
                                    }
                                    URL.revokeObjectURL(audioUrl);
                                    
                                    // 继续播放队列
                                    if (ttsQueue.length > 0) {
                                        const next = ttsQueue.shift();
                                        _playTTS(next.text, next.style);
                                    }
                                });
                        }
                    } catch (playError) {
                        isPlayingTTS = false;
                        console.error('播放异常:', playError);
                        showError('语音播报失败: ' + (playError.message || '未知错误'));
                        if (playbackDiv) {
                            playbackDiv.style.display = 'none';
                        }
                        URL.revokeObjectURL(audioUrl);
                        
                        // 继续播放队列
                        if (ttsQueue.length > 0) {
                            const next = ttsQueue.shift();
                            _playTTS(next.text, next.style);
                        }
                    }
                } else {
                    isPlayingTTS = false;
                    console.error('TTS API返回失败:', data);
                    if (playbackDiv) {
                        playbackDiv.style.display = 'none';
                    }
                }
            } catch (err) {
                isPlayingTTS = false;
                console.error('语音播报错误:', err);
                const playbackDiv = document.getElementById('voicePlaybackStatus');
                if (playbackDiv) {
                    playbackDiv.style.display = 'none';
                }
            }
            
            return audioElement; // 返回audio元素，用于优先级队列管理
        }
        
        // ========== 镜头运动检测（ChatGPT建议优化）==========
        const cameraMotionState = {
            lastFrame: null,
            motionDetected: false,
            lastMotionTime: 0,
            motionThreshold: 0.15,  // 运动阈值（帧差百分比）
            stabilityThreshold: 300  // 稳定阈值（ms）
        };
        
        function detectCameraMotion(currentFrameData) {
            if (!cameraMotionState.lastFrame) {
                cameraMotionState.lastFrame = currentFrameData;
                return false;
            }
            
            // 计算帧差（简化版：比较图像数据哈希）
            const currentHash = simpleHash(currentFrameData);
            const lastHash = cameraMotionState.lastFrame;
            
            // 如果哈希差异超过阈值，认为有运动
            const diff = Math.abs(currentHash - lastHash) / Math.max(currentHash, lastHash);
            
            if (diff > cameraMotionState.motionThreshold) {
                cameraMotionState.motionDetected = true;
                cameraMotionState.lastMotionTime = Date.now();
            } else {
                // 如果超过稳定阈值，认为镜头已稳定
                if (Date.now() - cameraMotionState.lastMotionTime > cameraMotionState.stabilityThreshold) {
                    cameraMotionState.motionDetected = false;
                }
            }
            
            cameraMotionState.lastFrame = currentHash;
            return cameraMotionState.motionDetected;
        }
        
        function simpleHash(data) {
            // 简单的哈希函数（用于快速比较）
            if (typeof data === 'string') {
                let hash = 0;
                for (let i = 0; i < data.length; i++) {
                    hash = ((hash << 5) - hash) + data.charCodeAt(i);
                    hash = hash & hash;
                }
                return hash;
            }
            return data;
        }
        
        // ========== 冷却时间配置（ChatGPT建议优化）==========
        const COOL_DOWN_MS = {
            'step': 2000,        // 台阶：2秒（降低，提高响应速度）
            'hazard': 1500,      // 危险：1.5秒（降低，确保及时播报）
            'direction': 2000,   // 转向：2秒
            'signboard': 5000,   // 标识牌：5秒
            'room': 3000,        // 房间号：3秒
            'default': 2000      // 默认：2秒（降低）
        };
        
        function getCooldownTime(message) {
            if (message.includes('台阶')) return COOL_DOWN_MS.step;
            if (message.includes('危险')) return COOL_DOWN_MS.hazard;
            if (message.includes('左转') || message.includes('右转')) return COOL_DOWN_MS.direction;
            if (message.includes('洗手间') || message.includes('电梯') || message.includes('出口')) return COOL_DOWN_MS.signboard;
            if (message.includes('房间号')) return COOL_DOWN_MS.room;
            return COOL_DOWN_MS.default;
        }
        
        // 判断是否为紧急消息（需要立即播报，不受镜头运动限制）
        function isUrgentMessage(message) {
            return message.includes('危险') || message.includes('台阶');
        }
        
        // 增强的视觉导航显示（产品模式专用）- 主动提示版（ChatGPT优化）
        let lastSpokenGuidance = {};
        const CAMERA_MOTION_THRESHOLD = 300; // 300ms（ChatGPT建议）
        
        function displayVisualGuidanceForProduct(guidance, visionSummary) {
            // 更新方向指示
            const directionIcons = {
                'forward': '⬆️',
                'left': '⬅️',
                'right': '➡️',
                'stop': '⛔'
            };
            
            const directionColors = {
                'forward': '#4CAF50',
                'left': '#2196F3',
                'right': '#FF9800',
                'stop': '#F44336'
            };
            
            const direction = guidance.direction || 'forward';
            const icon = directionIcons[direction] || '➡️';
            const color = directionColors[direction] || '#666';
            
            const directionDiv = document.getElementById('guidanceDirection');
            if (directionDiv) {
                directionDiv.innerHTML = `<span style="color:${color}; font-size:24px;">${icon}</span> <span style="color:${color};">${direction.toUpperCase()}</span>`;
            }
            
            // 更新指引消息
            let html = '';
            if (guidance.messages && guidance.messages.length > 0) {
                guidance.messages.forEach(msg => {
                    html += `<div style="padding:8px; margin:5px 0; background:#f5f5f5; border-radius:5px;">${msg}</div>`;
                });
            } else {
                html = '<div style="color:#999;">环境扫描中，未检测到特殊提示</div>';
            }
            const messagesDiv = document.getElementById('guidanceMessages');
            if (messagesDiv) {
                // 保留处理时间信息
                const existingTimeInfo = messagesDiv.innerHTML.match(/处理时间:.*?ms/);
                messagesDiv.innerHTML = html;
                if (existingTimeInfo && visionSummary && visionSummary.processing_time_ms) {
                    messagesDiv.innerHTML += `<div style="margin-top:10px; padding:5px; background:#e8f5e9; border-radius:5px; font-size:11px; color:#2E7D32;">
                        处理时间: ${visionSummary.processing_time_ms}ms | 物体: ${visionSummary.objects_detected || 0} | 文字: ${visionSummary.texts_detected || 0}
                    </div>`;
                }
            }
            
            // ========== 主动语音播报（优化版：确保危险提醒及时播报）==========
            if (guidance.messages && guidance.messages.length > 0) {
                const now = Date.now();
                
                // 筛选重要消息（台阶、危险、方向、标识牌）
                const importantMessages = guidance.messages.filter(msg => 
                    msg.includes('台阶') || 
                    msg.includes('危险') || 
                    msg.includes('左转') || 
                    msg.includes('右转') || 
                    msg.includes('直行') ||
                    msg.includes('洗手间') ||
                    msg.includes('电梯') ||
                    msg.includes('出口') ||
                    msg.includes('房间号')
                );
                
                // 添加调试日志：记录所有消息
                console.log(`📋 [视觉识别] 收到 ${guidance.messages.length} 条消息，筛选出 ${importantMessages.length} 条重要消息`);
                debugLog(`收到 ${guidance.messages.length} 条消息，筛选出 ${importantMessages.length} 条重要消息`, 'info');
                
                if (importantMessages.length > 0) {
                    // 优先处理危险和台阶消息
                    const urgentMessages = importantMessages.filter(msg => isUrgentMessage(msg));
                    const currentMessage = urgentMessages.length > 0 ? urgentMessages[0] : importantMessages[0];
                    const messageKey = currentMessage.substring(0, 30); // 使用前30个字符作为唯一标识（增加长度避免重复）
                    const isUrgent = isUrgentMessage(currentMessage);
                    
                    console.log(`🎯 [TTS决策] 当前消息: "${currentMessage.substring(0, 40)}..." | 是否紧急: ${isUrgent}`);
                    debugLog(`准备处理消息: "${currentMessage.substring(0, 30)}..."`, 'info');
                    
                    // 1. 镜头状态检查（紧急消息不受限制）
                    if (!isUrgent && cameraMotionState.motionDetected && 
                        (now - cameraMotionState.lastMotionTime) < CAMERA_MOTION_THRESHOLD) {
                        // 镜头未稳定，延迟提示或跳过（但紧急消息不受此限制）
                        console.log(`📹 [TTS决策] 镜头运动中，延迟提示: ${currentMessage.substring(0, 20)}...`);
                        debugLog(`镜头运动中，延迟提示`, 'warn');
                        return;
                    }
                    
                    // 2. 冷却时间检查（紧急消息使用更短的冷却时间）
                    const cooldownTime = getCooldownTime(currentMessage);
                    const lastSpokenTime = lastSpokenGuidance[messageKey] || 0;
                    const timeSinceLastSpoken = now - lastSpokenTime;
                    
                    if (timeSinceLastSpoken < cooldownTime) {
                        console.log(`⏱️ [TTS决策] 冷却中，跳过提示: ${currentMessage.substring(0, 20)}... (剩余: ${cooldownTime - timeSinceLastSpoken}ms)`);
                        debugLog(`冷却中，剩余 ${cooldownTime - timeSinceLastSpoken}ms`, 'warn');
                        return;
                    }
                    
                    // 3. 更新冷却时间记录
                    lastSpokenGuidance[messageKey] = now;
                    
                    // 4. 根据消息类型选择语音风格和优先级
                    let style = 'calm';
                    let priority = false;
                    
                    if (currentMessage.includes('台阶') || currentMessage.includes('危险')) {
                        style = 'urgent'; // 紧急提示
                        priority = true;   // 高优先级（critical）
                    } else if (currentMessage.includes('左转') || currentMessage.includes('右转')) {
                        style = 'cheerful'; // 导航提示
                        priority = true;    // 高优先级（high）
                    } else {
                        priority = false;   // 普通优先级（medium/low）
                    }
                    
                    // 5. 通过EventBridge派发事件（平滑切换方案）
                    // 检测消息类型，通过统一事件流处理
                    if (currentMessage.includes('危险')) {
                        // 危险事件：通过EventBridge派发
                        const hazardType = currentMessage.match(/危险[：:](.+?)[，,。]/)?.[1] || 
                                         currentMessage.match(/(积水|障碍物|湿滑|施工)/)?.[1] || 'unknown';
                        if (window.EventBridge) {
                            window.EventBridge.dispatch("hazard", {
                                type: hazardType,
                                level: isUrgent ? 'critical' : 'high',
                                meta: { message: currentMessage, raw: guidance }
                            });
                        } else {
                            // 降级：直接调用TTS
                            speakText(currentMessage, style, priority)
                                .then(() => {
                                    debugLog(`✅ 语音已发送到播放队列: "${currentMessage.substring(0, 30)}..."`, 'info');
                                    console.log(`✅ [TTS播报] 已发送到播放队列: "${currentMessage.substring(0, 40)}..."`);
                                })
                                .catch((err) => {
                                    debugLog(`❌ 语音播放失败: ${err.message}`, 'error');
                                    console.error(`❌ [TTS播报] 失败:`, err);
                                });
                        }
                    } else if (currentMessage.includes('台阶')) {
                        // 台阶事件：通过EventBridge派发
                        const direction = currentMessage.includes('上') ? 'up' : currentMessage.includes('下') ? 'down' : 'up';
                        const distanceMatch = currentMessage.match(/(\d+)/);
                        const distance = distanceMatch ? parseInt(distanceMatch[1]) : null;
                        if (window.EventBridge) {
                            window.EventBridge.dispatch("step", {
                                direction: direction,
                                distance: distance,
                                meta: { message: currentMessage, raw: guidance }
                            });
                        } else {
                            // 降级：直接调用TTS
                            speakText(currentMessage, style, priority)
                                .then(() => {
                                    debugLog(`✅ 语音已发送到播放队列: "${currentMessage.substring(0, 30)}..."`, 'info');
                                    console.log(`✅ [TTS播报] 已发送到播放队列: "${currentMessage.substring(0, 40)}..."`);
                                })
                                .catch((err) => {
                                    debugLog(`❌ 语音播放失败: ${err.message}`, 'error');
                                    console.error(`❌ [TTS播报] 失败:`, err);
                                });
                        }
                    } else if (currentMessage.includes('左转') || currentMessage.includes('右转') || currentMessage.includes('直行')) {
                        // 导航事件：通过EventBridge派发
                        const action = currentMessage.includes('左转') ? 'turn' : 
                                    currentMessage.includes('右转') ? 'turn' : 
                                    currentMessage.includes('直行') ? 'straight' : 'continue';
                        const navDirection = currentMessage.includes('左转') ? 'left' : 
                                           currentMessage.includes('右转') ? 'right' : 'forward';
                        const distanceMatch = currentMessage.match(/(\d+)/);
                        const distance = distanceMatch ? parseInt(distanceMatch[1]) : null;
                        if (window.EventBridge) {
                            window.EventBridge.dispatch("navigation", {
                                action: action,
                                direction: navDirection,
                                distance: distance,
                                meta: { message: currentMessage, raw: guidance, direction: direction }
                            });
                        } else {
                            // 降级：直接调用TTS
                            speakText(currentMessage, style, priority)
                                .then(() => {
                                    debugLog(`✅ 语音已发送到播放队列: "${currentMessage.substring(0, 30)}..."`, 'info');
                                    console.log(`✅ [TTS播报] 已发送到播放队列: "${currentMessage.substring(0, 40)}..."`);
                                })
                                .catch((err) => {
                                    debugLog(`❌ 语音播放失败: ${err.message}`, 'error');
                                    console.error(`❌ [TTS播报] 失败:`, err);
                                });
                        }
                    } else {
                        // 其他消息：直接调用TTS（保持原有逻辑）
                        console.log(`🔊 [TTS播报] 开始播放: "${currentMessage.substring(0, 40)}..." | 风格: ${style} | 优先级: ${priority}`);
                        debugLog(`开始播放语音: "${currentMessage.substring(0, 30)}..."`, 'info');
                        
                        speakText(currentMessage, style, priority)
                            .then(() => {
                                debugLog(`✅ 语音已发送到播放队列: "${currentMessage.substring(0, 30)}..."`, 'info');
                                console.log(`✅ [TTS播报] 已发送到播放队列: "${currentMessage.substring(0, 40)}..."`);
                            })
                            .catch((err) => {
                                debugLog(`❌ 语音播放失败: ${err.message}`, 'error');
                                console.error(`❌ [TTS播报] 失败:`, err);
                                console.error(`❌ [TTS播报] 失败消息: "${currentMessage}"`);
                                // 如果失败，尝试用户交互后播放
                                const playWhenReady = () => {
                                    speakText(currentMessage, style, priority)
                                        .then(() => {
                                            debugLog('✅ 用户交互后语音已播放', 'info');
                                            console.log(`✅ [TTS播报] 用户交互后已播放`);
                                        })
                                        .catch((e) => {
                                            debugLog(`❌ 用户交互后播放也失败: ${e.message}`, 'error');
                                            console.error(`❌ [TTS播报] 用户交互后也失败:`, e);
                                        });
                                    document.removeEventListener('click', playWhenReady);
                                    document.removeEventListener('touchstart', playWhenReady);
                                };
                                document.addEventListener('click', playWhenReady, { once: true });
                                document.addEventListener('touchstart', playWhenReady, { once: true });
                            });
                    }
                } else {
                    console.log(`ℹ️ [TTS决策] 没有重要消息需要播报`);
                }
            }
        }
    </script>

    <!-- ===================== -->
    <!-- Luna Task Chain System -->
    <!-- ===================== -->
    <script>
        /* ===== BEGIN: task_chain.js ===== */
        /**
         * 轻量级任务链系统（规范要求）
         * 提供可插拔、可恢复、可中断的任务执行流程
         */
        (function() {
            'use strict';
            const TaskPriority = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
            const TaskType = {
                HAZARD_WARNING: 'hazard_warning',
                STEP_WARNING: 'step_warning',
                NAVIGATION: 'navigation',
                TTS_BROADCAST: 'tts_broadcast',
                UI_UPDATE: 'ui_update',
                LOG_RECORD: 'log_record',
                EMOTION_EVENT: 'emotion_event'
            };
            class TaskChain {
                constructor() {
                    this.queue = [];
                    this.running = false;
                    this.currentTask = null;
                    this.handlers = new Map();
                    this.stats = { totalEnqueued: 0, totalCompleted: 0, totalFailed: 0, totalInterrupted: 0 };
                    this._registerDefaultHandlers();
                    console.log('✅ TaskChain初始化完成', { module: 'task_chain' });
                }
                _registerDefaultHandlers() {
                    this.registerHandler(TaskType.HAZARD_WARNING, async (payload) => {
                        const { type, level, meta } = payload;
                        console.log(`🚨 [TaskChain] 处理危险警告: ${type}`, { module: 'task_chain' });
                        if (window.emitHazardEvent) {
                            window.emitHazardEvent({ type, level, meta });
                        } else if (window.speakText) {
                            const message = `检测到${type}危险，请小心`;
                            await window.speakText(message, 'urgent', true);
                        }
                    });
                    this.registerHandler(TaskType.STEP_WARNING, async (payload) => {
                        const { direction, distance, meta } = payload;
                        console.log(`📐 [TaskChain] 处理台阶警告: ${direction}`, { module: 'task_chain' });
                        if (window.emitHazardEvent) {
                            window.emitHazardEvent({ type: 'step', level: 'high', meta: { direction, distance, ...meta } });
                        } else if (window.speakText) {
                            const message = `前方${distance || ''}米有台阶，请${direction === 'up' ? '减速' : '小心'}`;
                            await window.speakText(message, 'urgent', true);
                        }
                    });
                    this.registerHandler(TaskType.NAVIGATION, async (payload) => {
                        const { action, direction, distance, meta } = payload;
                        console.log(`🧭 [TaskChain] 处理导航: ${action}`, { module: 'task_chain' });
                        if (window.emitNavigationEvent) {
                            window.emitNavigationEvent({ action, direction, distance, ...meta });
                        } else if (window.speakText) {
                            const message = action === 'turn' ? `前方${distance || ''}米${direction === 'left' ? '左' : '右'}转` : '请跟随导航指引';
                            await window.speakText(message, 'cheerful', true);
                        }
                    });
                    this.registerHandler(TaskType.TTS_BROADCAST, async (payload) => {
                        const { text, style, priority } = payload;
                        if (window.speakText) {
                            await window.speakText(text, style || 'calm', priority || false);
                        }
                    });
                    this.registerHandler(TaskType.UI_UPDATE, async (payload) => {
                        const { elementId, content, className } = payload;
                        const element = document.getElementById(elementId);
                        if (element) {
                            if (content !== undefined) element.textContent = content;
                            if (className !== undefined) element.className = className;
                        }
                    });
                    this.registerHandler(TaskType.LOG_RECORD, async (payload) => {
                        const { level, message, meta } = payload;
                        if (window.lunaLog) {
                            window.lunaLog(level, message, meta || {});
                        }
                    });
                    this.registerHandler(TaskType.EMOTION_EVENT, async (payload) => {
                        const { event, level, meta } = payload;
                        if (window.emotion_event) {
                            window.emotion_event(event, level, meta);
                        }
                    });
                }
                registerHandler(taskType, handler) {
                    this.handlers.set(taskType, handler);
                }
                enqueue(taskType, payload, priority = TaskPriority.MEDIUM) {
                    const task = {
                        id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                        type: taskType,
                        payload: payload || {},
                        priority: priority,
                        timestamp: Date.now(),
                        status: 'pending'
                    };
                    let inserted = false;
                    for (let i = 0; i < this.queue.length; i++) {
                        if (this.queue[i].priority > priority) {
                            this.queue.splice(i, 0, task);
                            inserted = true;
                            break;
                        }
                    }
                    if (!inserted) this.queue.push(task);
                    this.stats.totalEnqueued++;
                    if (!this.running) this._processQueue();
                    return task.id;
                }
                async _processQueue() {
                    if (this.running) return;
                    this.running = true;
                    while (this.queue.length > 0) {
                        const task = this.queue.shift();
                        this.currentTask = task;
                        try {
                            task.status = 'running';
                            const handler = this.handlers.get(task.type);
                            if (handler) {
                                await handler(task.payload);
                                task.status = 'completed';
                                this.stats.totalCompleted++;
                            } else {
                                task.status = 'skipped';
                            }
                        } catch (error) {
                            task.status = 'failed';
                            task.error = error.message;
                            this.stats.totalFailed++;
                            console.error(`❌ [TaskChain] 任务失败: ${task.type}`, error);
                        }
                        this.currentTask = null;
                    }
                    this.running = false;
                }
                interrupt() {
                    if (this.currentTask) {
                        this.currentTask.status = 'interrupted';
                        this.stats.totalInterrupted++;
                        this.currentTask = null;
                    }
                }
                clear() {
                    this.queue = [];
                    this.interrupt();
                }
                getStats() {
                    return {
                        ...this.stats,
                        queueLength: this.queue.length,
                        currentTask: this.currentTask ? { id: this.currentTask.id, type: this.currentTask.type, status: this.currentTask.status } : null
                    };
                }
            }
            window.taskChain = new TaskChain();
            window.taskChainEnqueue = function(taskType, payload, priority) {
                return window.taskChain.enqueue(taskType, payload, priority);
            };
        })();
        /* ===== END: task_chain.js ===== */
    </script>

    <!-- ============================ -->
    <!-- Luna Unified Event Dispatcher -->
    <!-- ============================ -->
    <script>
        /* ===== BEGIN: unified_events.js ===== */
        /**
         * 统一事件派发系统（规范要求）
         * 提供统一的危险/台阶/导航事件处理流程
         */
        (function() {
            'use strict';
            
            // ========== 事件桥接层（平滑切换方案）==========
            window.EventBridge = {
                // 原事件：旧逻辑（兼容保留）
                legacy: {
                    hazard: null,  // window.handleHazardDetection
                    step: null,    // window.handleStepDetection
                    navigation: null // window.handleNavigationDecision
                },
                
                // 新事件：统一事件流
                unified: {
                    hazard: null,  // 将在下面定义
                    step: null,    // 将在下面定义
                    navigation: null // 将在下面定义
                },
                
                // 开关（默认双跑，确保平滑过渡）
                mode: {
                    hazard: "both",     // "legacy" | "unified" | "both"
                    step: "both",
                    navigation: "both"
                },
                
                /**
                 * 统一派发方法
                 */
                dispatch(type, data) {
                    const mode = this.mode[type];
                    
                    // 旧逻辑继续执行（兼容阶段）
                    if (mode === "legacy" || mode === "both") {
                        const legacyHandler = this.legacy[type];
                        if (legacyHandler && typeof legacyHandler === 'function') {
                            try {
                                legacyHandler(data);
                            } catch (error) {
                                console.error(`❌ [EventBridge] 旧逻辑执行失败 (${type}):`, error);
                            }
                        }
                    }
                    
                    // 新逻辑开始接管
                    if (mode === "unified" || mode === "both") {
                        const unifiedHandler = this.unified[type];
                        if (unifiedHandler && typeof unifiedHandler === 'function') {
                            try {
                                unifiedHandler(data);
                            } catch (error) {
                                console.error(`❌ [EventBridge] 新逻辑执行失败 (${type}):`, error);
                            }
                        }
                    }
                },
                
                /**
                 * 注册旧逻辑处理器（向后兼容）
                 */
                registerLegacy(type, handler) {
                    if (this.legacy.hasOwnProperty(type)) {
                        this.legacy[type] = handler;
                        console.log(`✅ [EventBridge] 注册旧逻辑处理器: ${type}`, { module: 'event_bridge' });
                    }
                },
                
                /**
                 * 切换模式（用于逐步迁移）
                 */
                switchMode(type, newMode) {
                    if (this.mode.hasOwnProperty(type) && ['legacy', 'unified', 'both'].includes(newMode)) {
                        const oldMode = this.mode[type];
                        this.mode[type] = newMode;
                        console.log(`🔄 [EventBridge] 切换模式: ${type} (${oldMode} → ${newMode})`, { module: 'event_bridge' });
                    }
                }
            };
            
            const messageTemplates = {
                hazard: { water: '前方有积水，请小心', obstacle: '前方有障碍物，请绕行', slippery: '地面湿滑，请减速', construction: '前方施工，请注意安全', default: '检测到危险区域，请小心' },
                step: { up: (d) => `前方${d || ''}米有台阶，请减速`, down: (d) => `前方${d || ''}米有下台阶，请小心`, default: (d) => `前方${d || ''}米有台阶，请注意` },
                navigation: { turn_left: (d) => `前方${d || ''}米左转`, turn_right: (d) => `前方${d || ''}米右转`, straight: (d) => `请直行${d ? d + '米' : ''}`, stop: () => '已到达目的地', default: () => '请跟随导航指引' }
            };
            
            // 统一事件处理函数（内部实现）
            function _emitHazardEventInternal({ type, level = 'medium', meta = {} }) {
                const templates = messageTemplates.hazard;
                const message = templates[type] || templates.default;
                console.log(`🚨 [统一事件] 危险事件: ${type}`, { module: 'unified_events' });
                const finalMessage = meta.message || message;
                if (window.taskChain) {
                    window.taskChain.enqueue('hazard_warning', { type, level, meta: { ...meta, message: finalMessage } }, level === 'critical' || level === 'high' ? 0 : 2);
                } else if (window.speakText) {
                    window.speakText(finalMessage, 'urgent', level === 'critical' || level === 'high');
                }
                const uiElement = document.getElementById('hazardAlert');
                if (uiElement) {
                    uiElement.textContent = finalMessage;
                    uiElement.className = `hazard-alert level-${level}`;
                    uiElement.style.display = 'block';
                    setTimeout(() => { uiElement.style.display = 'none'; }, 3000);
                }
                if (window.emotion_event) {
                    window.emotion_event('hazard_detected', level, { type, ...meta });
                }
                return { success: true, message: finalMessage, type, level };
            }
            
            function _emitStepEventInternal({ direction = 'up', distance, meta = {} }) {
                const templates = messageTemplates.step;
                const template = templates[direction] || templates.default;
                const message = template(distance);
                console.log(`📐 [统一事件] 台阶事件: ${direction}`, { module: 'unified_events' });
                const finalMessage = meta.message || message;
                if (window.taskChain) {
                    window.taskChain.enqueue('step_warning', { direction, distance, meta: { ...meta, message: finalMessage } }, 0);
                } else if (window.speakText) {
                    window.speakText(finalMessage, 'urgent', true);
                }
                const uiElement = document.getElementById('stepAlert');
                if (uiElement) {
                    uiElement.textContent = finalMessage;
                    uiElement.className = 'step-alert critical';
                    uiElement.style.display = 'block';
                    setTimeout(() => { uiElement.style.display = 'none'; }, 3000);
                }
                if (window.emotion_event) {
                    window.emotion_event('step_detected', 'high', { direction, distance, ...meta });
                }
                return { success: true, message: finalMessage, direction, distance };
            }
            
            function _emitNavigationEventInternal({ action, direction, distance, meta = {} }) {
                const templates = messageTemplates.navigation;
                const subtype = action === 'turn' ? `turn_${direction}` : action;
                const template = templates[subtype] || templates.default;
                const message = template(distance);
                console.log(`🧭 [统一事件] 导航事件: ${action}`, { module: 'unified_events' });
                const finalMessage = meta.message || message;
                if (window.taskChain) {
                    window.taskChain.enqueue('navigation', { action, direction, distance, meta: { ...meta, message: finalMessage } }, 1);
                } else if (window.speakText) {
                    window.speakText(finalMessage, 'cheerful', true);
                }
                const uiElement = document.getElementById('navigationGuidance');
                if (uiElement) {
                    uiElement.textContent = finalMessage;
                    uiElement.className = `navigation-guidance action-${action}`;
                    uiElement.style.display = 'block';
                }
                return { success: true, message: finalMessage, action, direction, distance };
            }
            
            // 注册到EventBridge的统一处理器
            window.EventBridge.unified.hazard = _emitHazardEventInternal;
            window.EventBridge.unified.step = _emitStepEventInternal;
            window.EventBridge.unified.navigation = _emitNavigationEventInternal;
            
            // 对外暴露的统一事件接口（通过EventBridge派发）
            window.emitHazardEvent = function(data) {
                window.EventBridge.dispatch("hazard", data);
            };
            
            window.emitStepEvent = function(data) {
                window.EventBridge.dispatch("step", data);
            };
            
            window.emitNavigationEvent = function(data) {
                // 先通过导航策略层处理
                if (window.NavigationStrategy && window.NavigationStrategy.run) {
                    const decision = window.NavigationStrategy.run(data);
                    if (decision && decision.msg) {
                        // 如果有决策消息，先通过TTS播报
                        if (window.taskChain) {
                            window.taskChain.enqueue('tts_broadcast', {
                                text: decision.msg,
                                style: 'cheerful',
                                priority: true
                            }, 1);
                        } else if (window.speakText) {
                            window.speakText(decision.msg, 'cheerful', true);
                        }
                    }
                }
                // 再通过EventBridge派发
                window.EventBridge.dispatch("navigation", data);
            };
            
            console.log('✅ UnifiedEventManager模块加载完成', { module: 'unified_events' });
        })();
        /* ===== END: unified_events.js ===== */
    </script>

    <!-- ========================= -->
    <!-- Navigation Strategy Layer -->
    <!-- ========================= -->
    <script>
        /* ===== BEGIN: navigation_strategy.js ===== */
        /**
         * 导航策略层（规范要求：可插拔导航策略）
         * 支持不同场景：走廊/街道/地铁等
         */
        (function() {
            'use strict';
            
            window.NavigationStrategy = {
                current: "default",  // default | corridor | street | subway | indoor
                
                strategies: {
                    /**
                     * 默认策略（保持现有MVP逻辑）
                     */
                    default: {
                        decide(navData) {
                            // 保持原有逻辑，不做改变
                            return { action: "continue", msg: null };
                        }
                    },
                    
                    /**
                     * 走廊策略（室内导航）
                     */
                    corridor: {
                        decide(navData) {
                            const { direction, distance, detectedObjects } = navData || {};
                            
                            if (direction === "left") {
                                return { 
                                    action: "turn-left", 
                                    msg: `前方${distance || ''}米，建议在走廊左转。`,
                                    priority: "high"
                                };
                            }
                            
                            if (direction === "right") {
                                return { 
                                    action: "turn-right", 
                                    msg: `前方${distance || ''}米，建议在走廊右转。`,
                                    priority: "high"
                                };
                            }
                            
                            if (direction === "forward") {
                                return { 
                                    action: "go-forward", 
                                    msg: `请沿走廊直行${distance ? distance + '米' : ''}。`,
                                    priority: "medium"
                                };
                            }
                            
                            return { action: "continue", msg: null };
                        }
                    },
                    
                    /**
                     * 街道策略（室外导航）
                     */
                    street: {
                        decide(navData) {
                            const { direction, distance, hasVehicle, hasTrafficLight, trafficLightState, crowdDensity } = navData || {};
                            
                            // 车辆检测优先
                            if (hasVehicle) {
                                return { 
                                    action: "stop", 
                                    msg: "前方有车辆，请暂时停下，等待安全后再前行。",
                                    priority: "critical"
                                };
                            }
                            
                            // 红绿灯检测
                            if (hasTrafficLight) {
                                if (trafficLightState === "red") {
                                    return { 
                                        action: "stop", 
                                        msg: "前方红灯，请停下等待。",
                                        priority: "critical"
                                    };
                                } else if (trafficLightState === "green") {
                                    return { 
                                        action: "go-forward", 
                                        msg: "前方绿灯，可以安全前行。",
                                        priority: "high"
                                    };
                                }
                            }
                            
                            // 人群密集度检测
                            if (crowdDensity === "high") {
                                return { 
                                    action: "slow-down", 
                                    msg: "前方人群密集，请减速慢行。",
                                    priority: "high"
                                };
                            }
                            
                            // 方向判断
                            if (direction === "left") {
                                return { 
                                    action: "turn-left", 
                                    msg: `前方${distance || ''}米左转，请注意车辆。`,
                                    priority: "high"
                                };
                            }
                            
                            if (direction === "right") {
                                return { 
                                    action: "turn-right", 
                                    msg: `前方${distance || ''}米右转，请注意车辆。`,
                                    priority: "high"
                                };
                            }
                            
                            if (direction === "forward") {
                                return { 
                                    action: "go-forward", 
                                    msg: `可以前行${distance ? distance + '米' : ''}。`,
                                    priority: "medium"
                                };
                            }
                            
                            return { action: "continue", msg: null };
                        }
                    },
                    
                    /**
                     * 地铁策略（站台导航）
                     */
                    subway: {
                        decide(navData) {
                            const { sign, platform, direction, line } = navData || {};
                            
                            // 站台指示牌识别
                            if (sign) {
                                if (sign.includes("往") || sign.includes("方向")) {
                                    const destination = sign.match(/往(.+?)[站方向]/)?.[1] || sign.match(/往(.+)/)?.[1];
                                    if (destination) {
                                        return { 
                                            action: "go-platform", 
                                            msg: `请前往${destination}方向站台。`,
                                            priority: "high",
                                            meta: { destination, platform }
                                        };
                                    }
                                }
                                
                                if (sign.includes("站台") || sign.includes("Platform")) {
                                    const platformNum = sign.match(/[A-Z]|[\u4e00-\u9fa5]/)?.[0];
                                    return { 
                                        action: "go-platform", 
                                        msg: `请前往${platformNum || ''}站台。`,
                                        priority: "high",
                                        meta: { platform: platformNum }
                                    };
                                }
                            }
                            
                            // 线路识别
                            if (line) {
                                return { 
                                    action: "follow-line", 
                                    msg: `请跟随${line}号线指引。`,
                                    priority: "high",
                                    meta: { line }
                                };
                            }
                            
                            // 方向判断
                            if (direction === "left") {
                                return { 
                                    action: "turn-left", 
                                    msg: "请向左前往站台。",
                                    priority: "high"
                                };
                            }
                            
                            if (direction === "right") {
                                return { 
                                    action: "turn-right", 
                                    msg: "请向右前往站台。",
                                    priority: "high"
                                };
                            }
                            
                            return { action: "continue", msg: null };
                        }
                    },
                    
                    /**
                     * 室内策略（医院/商场等）
                     */
                    indoor: {
                        decide(navData) {
                            const { direction, distance, facility, floor, doorplate } = navData || {};
                            
                            // 设施导航
                            if (facility) {
                                return { 
                                    action: "go-facility", 
                                    msg: `前往${facility}，${direction === 'left' ? '左转' : direction === 'right' ? '右转' : '直行'}${distance ? distance + '米' : ''}。`,
                                    priority: "high",
                                    meta: { facility }
                                };
                            }
                            
                            // 楼层导航
                            if (floor) {
                                return { 
                                    action: "go-floor", 
                                    msg: `请前往${floor}层。`,
                                    priority: "high",
                                    meta: { floor }
                                };
                            }
                            
                            // 门牌号导航
                            if (doorplate) {
                                return { 
                                    action: "go-doorplate", 
                                    msg: `目标位置：${doorplate}。`,
                                    priority: "high",
                                    meta: { doorplate }
                                };
                            }
                            
                            // 方向判断
                            if (direction === "left") {
                                return { 
                                    action: "turn-left", 
                                    msg: `前方${distance || ''}米左转。`,
                                    priority: "medium"
                                };
                            }
                            
                            if (direction === "right") {
                                return { 
                                    action: "turn-right", 
                                    msg: `前方${distance || ''}米右转。`,
                                    priority: "medium"
                                };
                            }
                            
                            return { action: "continue", msg: null };
                        }
                    }
                },
                
                /**
                 * 执行策略决策
                 */
                run(navData) {
                    const strategy = this.strategies[this.current];
                    if (!strategy) {
                        console.warn(`⚠️ [NavigationStrategy] 未找到策略: ${this.current}`, { module: 'navigation_strategy' });
                        return this.strategies.default.decide(navData);
                    }
                    
                    try {
                        const decision = strategy.decide(navData);
                        console.log(`🧭 [NavigationStrategy] 策略决策: ${this.current} → ${decision.action}`, { module: 'navigation_strategy' });
                        return decision;
                    } catch (error) {
                        console.error(`❌ [NavigationStrategy] 策略执行失败: ${this.current}`, { module: 'navigation_strategy', error: error.message });
                        return this.strategies.default.decide(navData);
                    }
                },
                
                /**
                 * 切换策略
                 */
                switchStrategy(strategyName) {
                    if (this.strategies.hasOwnProperty(strategyName)) {
                        const oldStrategy = this.current;
                        this.current = strategyName;
                        console.log(`🔄 [NavigationStrategy] 切换策略: ${oldStrategy} → ${strategyName}`, { module: 'navigation_strategy' });
                        
                        // 触发策略切换事件
                        if (window.emotion_event) {
                            window.emotion_event('navigation_strategy_changed', 'medium', {
                                old: oldStrategy,
                                new: strategyName
                            });
                        }
                        
                        return true;
                    } else {
                        console.warn(`⚠️ [NavigationStrategy] 未知策略: ${strategyName}`, { module: 'navigation_strategy' });
                        return false;
                    }
                },
                
                /**
                 * 获取当前策略信息
                 */
                getCurrentStrategy() {
                    return {
                        name: this.current,
                        available: Object.keys(this.strategies),
                        description: this.strategies[this.current]?.description || '无描述'
                    };
                }
            };
            
            console.log('✅ NavigationStrategy模块加载完成', { module: 'navigation_strategy' });
        })();
        /* ===== END: navigation_strategy.js ===== */
    </script>

    <!-- ========================= -->
    <!-- Luna Emotion Hook System -->
    <!-- ========================= -->
    <script>
        /* ===== BEGIN: emotion_hook.js ===== */
        /**
         * 情绪事件Hook系统（规范要求）
         * 为Luna情绪系统预留接口
         */
        (function() {
            'use strict';
            class EmotionEventManager {
                constructor() {
                    this.hooks = new Map();
                    this.eventHistory = [];
                    this.maxHistory = 50;
                    this.enabled = true;
                    this._registerDefaultHooks();
                    console.log('✅ EmotionEventManager初始化完成', { module: 'emotion_hook' });
                }
                _registerDefaultHooks() {
                    this.registerHook('hazard_detected', (level, meta) => {
                        console.log(`💭 [情绪事件] 危险检测: 级别=${level}`, { module: 'emotion_hook' });
                    });
                    this.registerHook('step_detected', (level, meta) => {
                        console.log(`💭 [情绪事件] 台阶检测: 级别=${level}`, { module: 'emotion_hook' });
                    });
                    this.registerHook('navigation_started', (level, meta) => {
                        console.log(`💭 [情绪事件] 导航开始`, { module: 'emotion_hook' });
                    });
                    this.registerHook('navigation_completed', (level, meta) => {
                        console.log(`💭 [情绪事件] 导航完成`, { module: 'emotion_hook' });
                    });
                    this.registerHook('system_error', (level, meta) => {
                        console.log(`💭 [情绪事件] 系统错误: 级别=${level}`, { module: 'emotion_hook' });
                    });
                }
                registerHook(eventName, handler) {
                    if (!this.hooks.has(eventName)) {
                        this.hooks.set(eventName, []);
                    }
                    this.hooks.get(eventName).push(handler);
                }
                trigger(eventName, level = 'medium', meta = {}) {
                    if (!this.enabled) return;
                    this.eventHistory.push({ event: eventName, level, meta, timestamp: Date.now() });
                    if (this.eventHistory.length > this.maxHistory) {
                        this.eventHistory.shift();
                    }
                    const handlers = this.hooks.get(eventName) || [];
                    handlers.forEach(handler => {
                        try {
                            handler(level, meta);
                        } catch (error) {
                            console.error(`❌ [情绪事件] Hook执行失败: ${eventName}`, error);
                        }
                    });
                }
                getHistory(limit = 10) {
                    return this.eventHistory.slice(-limit);
                }
                enable() { this.enabled = true; }
                disable() { this.enabled = false; }
            }
            const emotionManager = new EmotionEventManager();
            window.emotion_event = function(eventName, level = 'medium', meta = {}) {
                emotionManager.trigger(eventName, level, meta);
            };
            window.emotionEventManager = emotionManager;
        })();
        /* ===== END: emotion_hook.js ===== */
    </script>

    <!-- ===================== -->
    <!-- 模块加载验证 -->
    <!-- ===================== -->
    <script>
        // 验证所有模块已正确加载
        (function() {
            const checks = {
                taskChain: typeof window.taskChain !== 'undefined',
                EventBridge: typeof window.EventBridge !== 'undefined',
                NavigationStrategy: typeof window.NavigationStrategy !== 'undefined',
                emitHazardEvent: typeof window.emitHazardEvent !== 'undefined',
                emitStepEvent: typeof window.emitStepEvent !== 'undefined',
                emitNavigationEvent: typeof window.emitNavigationEvent !== 'undefined',
                emotion_event: typeof window.emotion_event !== 'undefined'
            };
            const allLoaded = Object.values(checks).every(v => v === true);
            if (allLoaded) {
                console.log('✅ 所有规范模块已加载完成', checks);
                console.log('✅ EventBridge模式:', window.EventBridge?.mode);
                console.log('✅ NavigationStrategy当前策略:', window.NavigationStrategy?.current);
                console.log('✅ 可用导航策略:', window.NavigationStrategy?.getCurrentStrategy?.()?.available);
            } else {
                console.warn('⚠️ 部分模块未加载', checks);
            }
        })();
    <!-- ========================= -->
    <!-- Safe Mode -->
    <!-- ========================= -->
    <script>
        /* BEGIN: safe_mode.js */
/**
 * Safe Mode（安全模式）系统（规范要求）
 * 提供安全模式，暂停核心功能但保留基础能力
 */

(function() {
    'use strict';

    window.SafeMode = {
        enabled: false,
        reason: null,
        originalStates: {},  // 保存原始状态
        
        /**
         * 启用安全模式
         */
        enable(reason = "用户手动启用") {
            if (this.enabled) {
                console.log('⚠️ [SafeMode] 安全模式已启用', { module: 'safe_mode' });
                return;
            }
            
            this.enabled = true;
            this.reason = reason;
            
            console.log(`🛡️ [SafeMode] 启用安全模式: ${reason}`, { module: 'safe_mode' });
            
            // 保存原始状态
            this.originalStates = {
                visionActive: window.productModeActive || false,
                navigationActive: window.navigationActive || false,
                taskChainActive: window.taskChain ? window.taskChain.running : false
            };
            
            // 暂停视觉分析
            if (window.productModeActive !== undefined) {
                window.productModeActive = false;
            }
            
            // 暂停导航决策
            if (window.navigationActive !== undefined) {
                window.navigationActive = false;
            }
            
            // 暂停任务链执行（通过标志）
            if (window.taskChain) {
                window.taskChain.running = false;
            }
            
            // 显示安全模式状态条
            this._showStatusBar();
            
            // 播报提示
            if (window.speakText) {
                window.speakText(`系统已进入安全模式：${reason}`, 'calm', false);
            }
            
            // 触发情绪事件
            if (window.emotion_event) {
                window.emotion_event('safe_mode_enabled', 'medium', { reason });
            }
        },
        
        /**
         * 禁用安全模式
         */
        disable() {
            if (!this.enabled) {
                console.log('ℹ️ [SafeMode] 安全模式未启用', { module: 'safe_mode' });
                return;
            }
            
            console.log('✅ [SafeMode] 禁用安全模式', { module: 'safe_mode' });
            
            this.enabled = false;
            const reason = this.reason;
            this.reason = null;
            
            // 恢复原始状态
            if (this.originalStates.visionActive !== undefined) {
                window.productModeActive = this.originalStates.visionActive;
            }
            
            if (this.originalStates.navigationActive !== undefined) {
                window.navigationActive = this.originalStates.navigationActive;
            }
            
            if (window.taskChain && this.originalStates.taskChainActive) {
                window.taskChain.running = true;
                // 重新处理队列
                if (window.taskChain.queue && window.taskChain.queue.length > 0) {
                    window.taskChain._processQueue();
                }
            }
            
            // 隐藏状态条
            this._hideStatusBar();
            
            // 播报提示
            if (window.speakText) {
                window.speakText('安全模式已关闭，系统恢复正常运行', 'cheerful', false);
            }
            
            // 触发情绪事件
            if (window.emotion_event) {
                window.emotion_event('safe_mode_disabled', 'medium', { previous_reason: reason });
            }
        },
        
        /**
         * 检查是否启用
         */
        isEnabled() {
            return this.enabled;
        },
        
        /**
         * 显示安全模式状态条
         */
        _showStatusBar() {
            // 移除旧的状态条（如果存在）
            const existingBar = document.getElementById('safeModeStatusBar');
            if (existingBar) {
                existingBar.remove();
            }
            
            // 创建状态条
            const statusBar = document.createElement('div');
            statusBar.id = 'safeModeStatusBar';
            statusBar.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                background: #ff9800;
                color: white;
                padding: 10px;
                text-align: center;
                font-weight: bold;
                z-index: 10000;
                box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            `;
            statusBar.textContent = `🛡️ SAFE MODE ACTIVE: ${this.reason}`;
            
            document.body.insertBefore(statusBar, document.body.firstChild);
        },
        
        /**
         * 隐藏安全模式状态条
         */
        _hideStatusBar() {
            const statusBar = document.getElementById('safeModeStatusBar');
            if (statusBar) {
                statusBar.remove();
            }
        },
        
        /**
         * 检查是否应该处理事件（在事件处理函数中调用）
         */
        shouldProcess() {
            return !this.enabled;
        }
    };
    
    console.log('✅ SafeMode模块加载完成', { module: 'safe_mode' });
})();


        /* END: safe_mode.js */
    </script>

    <!-- ========================= -->
    <!-- Recovery Mode -->
    <!-- ========================= -->
    <script>
        /* BEGIN: recovery_mode.js */
/**
 * Recovery Mode（恢复模式）系统（规范要求）
 * 提供系统恢复和重置功能
 */

(function() {
    'use strict';

    window.RecoveryMode = {
        /**
         * 重置所有状态
         */
        resetAll() {
            console.log('🔄 [RecoveryMode] 开始重置所有状态...', { module: 'recovery_mode' });
            
            // 1. 清理所有定时器
            if (window.__intervals) {
                let clearedCount = 0;
                for (const key in window.__intervals) {
                    if (window.__intervals.hasOwnProperty(key)) {
                        clearInterval(window.__intervals[key]);
                        clearedCount++;
                    }
                }
                window.__intervals = {};
                console.log(`  ✅ 已清理 ${clearedCount} 个定时器`, { module: 'recovery_mode' });
            }
            
            // 2. 清空TTS队列
            if (window.priorityTTSQueue) {
                window.priorityTTSQueue.queue = [];
                window.priorityTTSQueue.currentAudio = null;
                window.priorityTTSQueue.currentPriority = 999;
                console.log('  ✅ 已清空TTS队列', { module: 'recovery_mode' });
            }
            
            if (window.ttsQueue && Array.isArray(window.ttsQueue)) {
                window.ttsQueue.length = 0;
                console.log('  ✅ 已清空旧TTS队列', { module: 'recovery_mode' });
            }
            
            // 3. 清空任务链队列
            if (window.taskChain) {
                window.taskChain.clear();
                console.log('  ✅ 已清空任务链队列', { module: 'recovery_mode' });
            }
            
            // 4. 清空视觉/导航相关的临时状态
            if (window.lastSpokenGuidance) {
                window.lastSpokenGuidance = {};
            }
            
            if (window.cameraMotionState) {
                window.cameraMotionState.lastFrame = null;
                window.cameraMotionState.motionDetected = false;
                window.cameraMotionState.lastMotionTime = 0;
            }
            
            // 5. 停止所有正在播放的声音
            if (window.priorityTTSQueue && window.priorityTTSQueue.currentAudio) {
                try {
                    window.priorityTTSQueue.currentAudio.pause();
                    window.priorityTTSQueue.currentAudio.currentTime = 0;
                    window.priorityTTSQueue.currentAudio = null;
                } catch (e) {
                    console.warn('  ⚠️ 停止音频失败:', e);
                }
            }
            
            // 6. 重置导航状态（如果存在）
            if (window.getNavStateManager) {
                try {
                    const navManager = window.getNavStateManager();
                    if (navManager && navManager.cancel) {
                        navManager.cancel('系统重置');
                    }
                } catch (e) {
                    console.warn('  ⚠️ 重置导航状态失败:', e);
                }
            }
            
            // 7. 重置导航FSM（如果存在）
            if (window.NavigationFSM && window.NavigationFSM.reset) {
                window.NavigationFSM.reset();
                console.log('  ✅ 已重置导航状态机', { module: 'recovery_mode' });
            }
            
            // 8. 清空路点（如果存在）
            if (window.WaypointManager && window.WaypointManager.clearWaypoints) {
                window.WaypointManager.clearWaypoints();
                console.log('  ✅ 已清空路点', { module: 'recovery_mode' });
            }
            
            console.log('✅ [RecoveryMode] 重置完成', { module: 'recovery_mode' });
            
            // 触发情绪事件
            if (window.emotion_event) {
                window.emotion_event('system_reset', 'medium', {});
            }
        },
        
        /**
         * 重启核心模块
         */
        restartCore() {
            console.log('🔄 [RecoveryMode] 开始重启核心模块...', { module: 'recovery_mode' });
            
            // 1. 先重置所有状态
            this.resetAll();
            
            // 2. 重新初始化（按顺序）
            try {
                // 2.1 重新初始化任务链（如果存在）
                if (window.taskChain) {
                    // 任务链会自动初始化，这里只需要确保运行标志正确
                    window.taskChain.running = false;
                    console.log('  ✅ 任务链已准备就绪', { module: 'recovery_mode' });
                }
                
                // 2.2 重新初始化视觉模块（如果有初始化函数）
                if (typeof window.initProductMode === 'function') {
                    // 不直接调用，避免重复初始化
                    console.log('  ℹ️ 视觉模块初始化函数存在，但跳过自动调用', { module: 'recovery_mode' });
                }
                
                // 2.3 恢复UI按钮状态
                const startBtn = document.getElementById('startProductModeBtn');
                const stopBtn = document.getElementById('stopProductModeBtn');
                if (startBtn) {
                    startBtn.disabled = false;
                }
                if (stopBtn) {
                    stopBtn.disabled = true;
                }
                
                // 2.4 重置产品模式状态
                if (window.productModeActive !== undefined) {
                    window.productModeActive = false;
                }
                
                console.log('✅ [RecoveryMode] 核心模块重启完成', { module: 'recovery_mode' });
                
                // 3. 播报恢复消息
                if (window.speakText) {
                    setTimeout(() => {
                        window.speakText('系统已恢复，可以重新开始使用', 'cheerful', false);
                    }, 500);
                }
                
                // 触发情绪事件
                if (window.emotion_event) {
                    window.emotion_event('system_recovered', 'medium', {});
                }
                
            } catch (error) {
                console.error('❌ [RecoveryMode] 重启失败:', error, { module: 'recovery_mode' });
                
                // 即使失败也播报消息
                if (window.speakText) {
                    window.speakText('系统恢复过程中遇到问题，请手动重启', 'urgent', true);
                }
            }
        },
        
        /**
         * 软重启（只重置关键状态，不重启整个系统）
         */
        softReset() {
            console.log('🔄 [RecoveryMode] 执行软重置...', { module: 'recovery_mode' });
            
            // 只清理队列和定时器，不重启模块
            if (window.__intervals) {
                for (const key in window.__intervals) {
                    if (window.__intervals.hasOwnProperty(key)) {
                        clearInterval(window.__intervals[key]);
                    }
                }
                window.__intervals = {};
            }
            
            if (window.taskChain) {
                window.taskChain.clear();
            }
            
            if (window.priorityTTSQueue) {
                window.priorityTTSQueue.queue = [];
            }
            
            console.log('✅ [RecoveryMode] 软重置完成', { module: 'recovery_mode' });
        }
    };
    
    console.log('✅ RecoveryMode模块加载完成', { module: 'recovery_mode' });
})();


        /* END: recovery_mode.js */
    </script>

    <!-- ========================= -->
    <!-- Navigation Fsm -->
    <!-- ========================= -->
    <script>
        /* BEGIN: navigation_fsm.js */
/**
 * Navigation FSM（导航状态机）（规范要求）
 * 标准化导航状态流转：开始 → 运行 → 暂停 → 恢复 → 完成
 */

(function() {
    'use strict';

    /**
     * 导航状态枚举
     */
    const NavState = {
        IDLE: "IDLE",
        STARTING: "STARTING",
        ACTIVE: "ACTIVE",
        PAUSED: "PAUSED",
        RECOVERING: "RECOVERING",
        FINISHED: "FINISHED"
    };

    window.NavigationFSM = {
        state: NavState.IDLE,
        startTime: null,
        pauseTime: null,
        history: [],
        maxHistory: 50,
        
        /**
         * 开始导航
         */
        start(destination = null) {
            if (this.state === NavState.ACTIVE) {
                console.warn('⚠️ [NavigationFSM] 导航已在进行中', { module: 'navigation_fsm' });
                return false;
            }
            
            const oldState = this.state;
            this.state = NavState.STARTING;
            this.startTime = Date.now();
            
            console.log(`🔄 [NavigationFSM] 状态转换: ${oldState} → ${NavState.STARTING}`, { module: 'navigation_fsm' });
            
            // 记录历史
            this._recordTransition(oldState, NavState.STARTING, { destination });
            
            // 短暂延迟后进入ACTIVE状态（模拟启动过程）
            setTimeout(() => {
                if (this.state === NavState.STARTING) {
                    this.state = NavState.ACTIVE;
                    console.log(`✅ [NavigationFSM] 状态转换: ${NavState.STARTING} → ${NavState.ACTIVE}`, { module: 'navigation_fsm' });
                    this._recordTransition(NavState.STARTING, NavState.ACTIVE, { destination });
                    
                    // 触发情绪事件
                    if (window.emotion_event) {
                        window.emotion_event('navigation_started', 'medium', { destination });
                    }
                }
            }, 100);
            
            return true;
        },
        
        /**
         * 暂停导航
         */
        pause(reason = "用户暂停") {
            if (this.state !== NavState.ACTIVE) {
                console.warn(`⚠️ [NavigationFSM] 无法暂停，当前状态: ${this.state}`, { module: 'navigation_fsm' });
                return false;
            }
            
            const oldState = this.state;
            this.state = NavState.PAUSED;
            this.pauseTime = Date.now();
            
            console.log(`⏸️ [NavigationFSM] 状态转换: ${oldState} → ${NavState.PAUSED} (原因: ${reason})`, { module: 'navigation_fsm' });
            this._recordTransition(oldState, NavState.PAUSED, { reason });
            
            // 触发情绪事件
            if (window.emotion_event) {
                window.emotion_event('navigation_paused', 'medium', { reason });
            }
            
            return true;
        },
        
        /**
         * 恢复导航
         */
        resume() {
            if (this.state !== NavState.PAUSED) {
                console.warn(`⚠️ [NavigationFSM] 无法恢复，当前状态: ${this.state}`, { module: 'navigation_fsm' });
                return false;
            }
            
            const oldState = this.state;
            this.state = NavState.RECOVERING;
            
            console.log(`🔄 [NavigationFSM] 状态转换: ${oldState} → ${NavState.RECOVERING}`, { module: 'navigation_fsm' });
            this._recordTransition(oldState, NavState.RECOVERING, {});
            
            // 短暂延迟后进入ACTIVE状态
            setTimeout(() => {
                if (this.state === NavState.RECOVERING) {
                    this.state = NavState.ACTIVE;
                    const pauseDuration = this.pauseTime ? Date.now() - this.pauseTime : 0;
                    this.pauseTime = null;
                    
                    console.log(`✅ [NavigationFSM] 状态转换: ${NavState.RECOVERING} → ${NavState.ACTIVE}`, { module: 'navigation_fsm' });
                    this._recordTransition(NavState.RECOVERING, NavState.ACTIVE, { pauseDuration });
                    
                    // 触发情绪事件
                    if (window.emotion_event) {
                        window.emotion_event('navigation_resumed', 'medium', { pauseDuration });
                    }
                }
            }, 100);
            
            return true;
        },
        
        /**
         * 完成导航
         */
        finish(success = true) {
            if (this.state !== NavState.ACTIVE && this.state !== NavState.PAUSED) {
                console.warn(`⚠️ [NavigationFSM] 无法完成，当前状态: ${this.state}`, { module: 'navigation_fsm' });
                return false;
            }
            
            const oldState = this.state;
            this.state = NavState.FINISHED;
            const duration = this.startTime ? Date.now() - this.startTime : 0;
            
            console.log(`🏁 [NavigationFSM] 状态转换: ${oldState} → ${NavState.FINISHED} (成功: ${success}, 耗时: ${duration}ms)`, { module: 'navigation_fsm' });
            this._recordTransition(oldState, NavState.FINISHED, { success, duration });
            
            // 触发情绪事件
            if (window.emotion_event) {
                window.emotion_event('navigation_completed', 'medium', { success, duration });
            }
            
            return true;
        },
        
        /**
         * 重置状态机
         */
        reset() {
            const oldState = this.state;
            this.state = NavState.IDLE;
            this.startTime = null;
            this.pauseTime = null;
            
            console.log(`🔄 [NavigationFSM] 状态重置: ${oldState} → ${NavState.IDLE}`, { module: 'navigation_fsm' });
            this._recordTransition(oldState, NavState.IDLE, { reason: 'reset' });
        },
        
        /**
         * 处理导航事件
         */
        handleEvent(navData) {
            if (!navData) {
                return;
            }
            
            // 根据事件数据更新状态（如果需要）
            const { action, direction, distance } = navData;
            
            // 如果导航完成
            if (action === 'stop' || action === 'complete') {
                if (this.state === NavState.ACTIVE) {
                    this.finish(true);
                }
            }
            
            // 记录事件（用于状态机日志）
            this._recordEvent(navData);
        },
        
        /**
         * 记录状态转换
         */
        _recordTransition(from, to, meta) {
            this.history.push({
                type: 'transition',
                from,
                to,
                timestamp: Date.now(),
                meta
            });
            
            if (this.history.length > this.maxHistory) {
                this.history.shift();
            }
        },
        
        /**
         * 记录事件
         */
        _recordEvent(eventData) {
            this.history.push({
                type: 'event',
                state: this.state,
                data: eventData,
                timestamp: Date.now()
            });
            
            if (this.history.length > this.maxHistory) {
                this.history.shift();
            }
        },
        
        /**
         * 获取当前状态信息
         */
        getState() {
            return {
                state: this.state,
                startTime: this.startTime,
                pauseTime: this.pauseTime,
                duration: this.startTime ? Date.now() - this.startTime : 0,
                pauseDuration: this.pauseTime ? Date.now() - this.pauseTime : 0
            };
        },
        
        /**
         * 获取历史记录
         */
        getHistory(limit = 10) {
            return this.history.slice(-limit);
        }
    };
    
    console.log('✅ NavigationFSM模块加载完成', { module: 'navigation_fsm' });
})();


        /* END: navigation_fsm.js */
    </script>

    <!-- ========================= -->
    <!-- Waypoint System -->
    <!-- ========================= -->
    <script>
        /* BEGIN: waypoint_system.js */
/**
 * Waypoint System（路点系统）（规范要求）
 * 支持多路点导航能力（医院、地铁、商场等）
 */

(function() {
    'use strict';

    window.WaypointManager = {
        waypoints: [],
        currentIndex: 0,
        reachedWaypoints: [],
        
        /**
         * 添加路点
         */
        addWaypoint(wp) {
            if (!wp || !wp.id) {
                console.warn('⚠️ [WaypointManager] 无效的路点数据', { module: 'waypoint_system' });
                return false;
            }
            
            // 检查是否已存在
            const exists = this.waypoints.find(w => w.id === wp.id);
            if (exists) {
                console.warn(`⚠️ [WaypointManager] 路点已存在: ${wp.id}`, { module: 'waypoint_system' });
                return false;
            }
            
            // 确保有必要的字段
            const waypoint = {
                id: wp.id,
                type: wp.type || 'custom',
                label: wp.label || wp.id,
                tts_message: wp.tts_message || `到达${wp.label || wp.id}`,
                metadata: wp.metadata || {},
                order: wp.order !== undefined ? wp.order : this.waypoints.length,
                ...wp
            };
            
            this.waypoints.push(waypoint);
            
            // 按order排序
            this.waypoints.sort((a, b) => a.order - b.order);
            
            console.log(`✅ [WaypointManager] 添加路点: ${waypoint.id} (${waypoint.label})`, { module: 'waypoint_system' });
            
            return true;
        },
        
        /**
         * 清空所有路点
         */
        clearWaypoints() {
            const count = this.waypoints.length;
            this.waypoints = [];
            this.currentIndex = 0;
            this.reachedWaypoints = [];
            
            console.log(`🗑️ [WaypointManager] 已清空 ${count} 个路点`, { module: 'waypoint_system' });
        },
        
        /**
         * 获取当前路点
         */
        getCurrent() {
            if (this.waypoints.length === 0) {
                return null;
            }
            
            if (this.currentIndex >= this.waypoints.length) {
                return null;  // 所有路点已完成
            }
            
            return this.waypoints[this.currentIndex];
        },
        
        /**
         * 标记当前路点已到达
         */
        markReached(waypointId = null) {
            const targetId = waypointId || (this.getCurrent()?.id);
            
            if (!targetId) {
                console.warn('⚠️ [WaypointManager] 无法标记到达：无目标路点', { module: 'waypoint_system' });
                return false;
            }
            
            const waypoint = this.waypoints.find(w => w.id === targetId);
            if (!waypoint) {
                console.warn(`⚠️ [WaypointManager] 路点不存在: ${targetId}`, { module: 'waypoint_system' });
                return false;
            }
            
            // 检查是否已到达
            if (this.reachedWaypoints.includes(targetId)) {
                console.log(`ℹ️ [WaypointManager] 路点已标记为到达: ${targetId}`, { module: 'waypoint_system' });
                return false;
            }
            
            // 标记为已到达
            this.reachedWaypoints.push(targetId);
            
            // 如果到达的是当前路点，移动到下一个
            if (this.getCurrent()?.id === targetId) {
                this.currentIndex++;
            }
            
            console.log(`✅ [WaypointManager] 路点已到达: ${waypoint.label} (${targetId})`, { module: 'waypoint_system' });
            
            // 播报TTS消息
            if (waypoint.tts_message && window.speakText) {
                window.speakText(waypoint.tts_message, 'cheerful', false);
            }
            
            // 触发情绪事件
            if (window.emotion_event) {
                window.emotion_event('waypoint_reached', 'medium', {
                    waypoint_id: targetId,
                    waypoint_label: waypoint.label,
                    progress: this.getProgress()
                });
            }
            
            return true;
        },
        
        /**
         * 检查导航进度
         */
        checkProgress(navData) {
            if (!navData || this.waypoints.length === 0) {
                return null;
            }
            
            const currentWaypoint = this.getCurrent();
            if (!currentWaypoint) {
                // 所有路点已完成
                return {
                    completed: true,
                    progress: 1.0,
                    message: "所有路点已完成"
                };
            }
            
            // 简单的到达判断逻辑（可根据实际需求扩展）
            const { action, direction, distance, detectedObjects, signboards } = navData;
            
            // 检查1：方向匹配
            if (currentWaypoint.metadata.expectedDirection) {
                if (direction !== currentWaypoint.metadata.expectedDirection) {
                    return null;  // 方向不匹配，未到达
                }
            }
            
            // 检查2：距离判断
            if (currentWaypoint.metadata.expectedDistance !== undefined) {
                const expectedDist = currentWaypoint.metadata.expectedDistance;
                const tolerance = currentWaypoint.metadata.distanceTolerance || 5;
                if (distance && Math.abs(distance - expectedDist) > tolerance) {
                    return null;  // 距离不匹配
                }
            }
            
            // 检查3：标识牌匹配
            if (currentWaypoint.metadata.expectedSign) {
                const expectedSign = currentWaypoint.metadata.expectedSign;
                if (signboards && Array.isArray(signboards)) {
                    const found = signboards.some(sb => 
                        sb.text && sb.text.includes(expectedSign)
                    );
                    if (!found) {
                        return null;  // 标识牌不匹配
                    }
                }
            }
            
            // 检查4：设施匹配
            if (currentWaypoint.metadata.expectedFacility) {
                const expectedFacility = currentWaypoint.metadata.expectedFacility;
                if (detectedObjects && Array.isArray(detectedObjects)) {
                    const found = detectedObjects.some(obj => 
                        obj.class && obj.class.includes(expectedFacility)
                    );
                    if (!found) {
                        return null;  // 设施不匹配
                    }
                }
            }
            
            // 如果所有条件都满足（或没有条件），标记为到达
            if (action === 'stop' || (distance !== undefined && distance < 3)) {
                this.markReached(currentWaypoint.id);
                return {
                    reached: true,
                    waypoint: currentWaypoint,
                    progress: this.getProgress()
                };
            }
            
            return {
                current: currentWaypoint,
                progress: this.getProgress(),
                remaining: this.waypoints.length - this.currentIndex
            };
        },
        
        /**
         * 获取进度
         */
        getProgress() {
            if (this.waypoints.length === 0) {
                return 0;
            }
            
            return {
                current: this.currentIndex + 1,
                total: this.waypoints.length,
                percentage: Math.round(((this.currentIndex + 1) / this.waypoints.length) * 100),
                reached: this.reachedWaypoints.length,
                remaining: this.waypoints.length - this.currentIndex
            };
        },
        
        /**
         * 获取所有路点
         */
        getAllWaypoints() {
            return this.waypoints.map((wp, index) => ({
                ...wp,
                index,
                reached: this.reachedWaypoints.includes(wp.id),
                isCurrent: index === this.currentIndex
            }));
        }
    };
    
    console.log('✅ WaypointManager模块加载完成', { module: 'waypoint_system' });
})();


        /* END: waypoint_system.js */
    </script>

    <!-- ========================= -->
    <!-- Auto Recovery -->
    <!-- ========================= -->
    <script>
        /* BEGIN: auto_recovery.js */
/**
 * Auto-Recovery（自动恢复）模块（规范要求）
 * 监控核心模块是否异常，并调用RecoveryMode自愈
 */

(function() {
    'use strict';

    window.AutoRecovery = {
        stats: {
            visionErrors: 0,
            navErrors: 0,
            ttsBlockedCount: 0,
            taskChainStallCount: 0,
            lastCheckTime: Date.now()
        },
        
        thresholds: {
            visionErrors: 3,      // 视觉错误超过3次触发恢复
            navErrors: 3,         // 导航错误超过3次触发恢复
            ttsBlocked: 5,        // TTS阻塞超过5次触发恢复
            taskChainStall: 10,   // 任务链停滞超过10次触发恢复
            checkInterval: 5000   // 每5秒检查一次
        },
        
        errorHistory: [],
        maxHistory: 20,
        
        /**
         * 记录错误
         */
        record(module, type, detail = {}) {
            const record = {
                module,
                type,
                detail,
                timestamp: Date.now()
            };
            
            this.errorHistory.push(record);
            if (this.errorHistory.length > this.maxHistory) {
                this.errorHistory.shift();
            }
            
            // 更新统计
            if (module === 'vision' && type === 'error') {
                this.stats.visionErrors++;
            } else if (module === 'navigation' && type === 'error') {
                this.stats.navErrors++;
            } else if (module === 'tts' && type === 'blocked') {
                this.stats.ttsBlockedCount++;
            } else if (module === 'taskChain' && type === 'stall') {
                this.stats.taskChainStallCount++;
            }
            
            console.log(`📊 [AutoRecovery] 记录错误: ${module}.${type}`, { module: 'auto_recovery', detail });
            
            // 如果超过阈值，立即检查
            if (this._shouldTriggerRecovery(module, type)) {
                console.warn(`⚠️ [AutoRecovery] ${module}错误超过阈值，触发检查`, { module: 'auto_recovery' });
                this.checkAndRecover();
            }
        },
        
        /**
         * 检查并恢复
         */
        checkAndRecover() {
            const now = Date.now();
            const timeSinceLastCheck = now - this.stats.lastCheckTime;
            this.stats.lastCheckTime = now;
            
            console.log('🔍 [AutoRecovery] 执行健康检查...', { module: 'auto_recovery' });
            
            let recoveryNeeded = false;
            const recoveryReasons = [];
            
            // 1. 检查视觉模块
            if (this.stats.visionErrors >= this.thresholds.visionErrors) {
                recoveryNeeded = true;
                recoveryReasons.push(`视觉错误过多 (${this.stats.visionErrors}次)`);
            }
            
            // 2. 检查导航模块
            if (this.stats.navErrors >= this.thresholds.navErrors) {
                recoveryNeeded = true;
                recoveryReasons.push(`导航错误过多 (${this.stats.navErrors}次)`);
            }
            
            // 3. 检查TTS队列
            if (this.stats.ttsBlockedCount >= this.thresholds.ttsBlocked) {
                recoveryNeeded = true;
                recoveryReasons.push(`TTS队列阻塞 (${this.stats.ttsBlockedCount}次)`);
            }
            
            // 4. 检查任务链
            if (this.stats.taskChainStallCount >= this.thresholds.taskChainStall) {
                recoveryNeeded = true;
                recoveryReasons.push(`任务链停滞 (${this.stats.taskChainStallCount}次)`);
            }
            
            // 5. 检查任务链是否真的停滞
            if (window.taskChain) {
                const stats = window.taskChain.getStats();
                const currentTask = stats.currentTask;
                
                // 如果当前任务运行时间过长（超过30秒）
                if (currentTask && currentTask.status === 'running') {
                    const taskAge = now - (currentTask.timestamp || 0);
                    if (taskAge > 30000) {
                        recoveryNeeded = true;
                        recoveryReasons.push(`任务链任务运行超时 (${Math.round(taskAge/1000)}秒)`);
                    }
                }
            }
            
            // 6. 检查TTS队列是否长时间未处理
            if (window.priorityTTSQueue) {
                const queueLength = window.priorityTTSQueue.queue ? window.priorityTTSQueue.queue.length : 0;
                if (queueLength > 10) {
                    recoveryNeeded = true;
                    recoveryReasons.push(`TTS队列积压过多 (${queueLength}条)`);
                }
            }
            
            if (recoveryNeeded) {
                console.warn(`⚠️ [AutoRecovery] 检测到异常，开始恢复...`, { 
                    module: 'auto_recovery',
                    reasons: recoveryReasons
                });
                
                // 记录日志
                if (window.lunaLog) {
                    window.lunaLog('warning', '自动恢复触发', {
                        reasons: recoveryReasons,
                        stats: { ...this.stats }
                    });
                }
                
                // 触发情绪事件
                if (window.emotion_event) {
                    window.emotion_event('system_error', 'high', {
                        type: 'auto_recovery_triggered',
                        reasons: recoveryReasons,
                        stats: { ...this.stats }
                    });
                }
                
                // 执行恢复
                if (window.RecoveryMode) {
                    // 根据严重程度选择恢复方式
                    const isCritical = recoveryReasons.some(r => r.includes('超时') || r.includes('积压'));
                    
                    if (isCritical) {
                        console.log('  🔄 [AutoRecovery] 执行完整重启...', { module: 'auto_recovery' });
                        window.RecoveryMode.restartCore();
                    } else {
                        console.log('  🔄 [AutoRecovery] 执行软重置...', { module: 'auto_recovery' });
                        window.RecoveryMode.softReset();
                    }
                } else {
                    console.warn('  ⚠️ [AutoRecovery] RecoveryMode未加载，无法执行恢复', { module: 'auto_recovery' });
                }
                
                // 重置错误计数（避免重复触发）
                this.stats.visionErrors = 0;
                this.stats.navErrors = 0;
                this.stats.ttsBlockedCount = 0;
                this.stats.taskChainStallCount = 0;
                
                console.log('✅ [AutoRecovery] 恢复完成', { module: 'auto_recovery' });
            } else {
                console.log('✅ [AutoRecovery] 系统健康，无需恢复', { module: 'auto_recovery' });
            }
        },
        
        /**
         * 判断是否应该触发恢复
         */
        _shouldTriggerRecovery(module, type) {
            if (module === 'vision' && type === 'error') {
                return this.stats.visionErrors >= this.thresholds.visionErrors;
            }
            if (module === 'navigation' && type === 'error') {
                return this.stats.navErrors >= this.thresholds.navErrors;
            }
            if (module === 'tts' && type === 'blocked') {
                return this.stats.ttsBlockedCount >= this.thresholds.ttsBlocked;
            }
            if (module === 'taskChain' && type === 'stall') {
                return this.stats.taskChainStallCount >= this.thresholds.taskChainStall;
            }
            return false;
        },
        
        /**
         * 启动自动监控
         */
        startMonitoring() {
            if (this.monitoringInterval) {
                console.log('ℹ️ [AutoRecovery] 监控已在运行', { module: 'auto_recovery' });
                return;
            }
            
            console.log('✅ [AutoRecovery] 启动自动监控', { module: 'auto_recovery' });
            
            // 注册到全局定时器管理
            if (window.__intervals) {
                window.__intervals.autoRecovery = setInterval(() => {
                    this.checkAndRecover();
                }, this.thresholds.checkInterval);
            } else {
                // 降级：直接使用setInterval
                this.monitoringInterval = setInterval(() => {
                    this.checkAndRecover();
                }, this.thresholds.checkInterval);
            }
        },
        
        /**
         * 停止自动监控
         */
        stopMonitoring() {
            if (window.__intervals && window.__intervals.autoRecovery) {
                clearInterval(window.__intervals.autoRecovery);
                delete window.__intervals.autoRecovery;
            }
            
            if (this.monitoringInterval) {
                clearInterval(this.monitoringInterval);
                this.monitoringInterval = null;
            }
            
            console.log('⏸️ [AutoRecovery] 停止自动监控', { module: 'auto_recovery' });
        },
        
        /**
         * 获取统计信息
         */
        getStats() {
            return {
                ...this.stats,
                errorHistory: this.errorHistory.slice(-10),  // 最近10条错误
                thresholds: this.thresholds
            };
        },
        
        /**
         * 重置统计
         */
        resetStats() {
            this.stats = {
                visionErrors: 0,
                navErrors: 0,
                ttsBlockedCount: 0,
                taskChainStallCount: 0,
                lastCheckTime: Date.now()
            };
            this.errorHistory = [];
            console.log('🔄 [AutoRecovery] 统计已重置', { module: 'auto_recovery' });
        }
    };
    
    // 自动启动监控（延迟启动，确保其他模块已加载）
    setTimeout(() => {
        if (window.AutoRecovery && window.AutoRecovery.startMonitoring) {
            window.AutoRecovery.startMonitoring();
        }
    }, 2000);
    
    console.log('✅ AutoRecovery模块加载完成', { module: 'auto_recovery' });
})();


        /* END: auto_recovery.js */
    </script>

    <!-- ===================== -->
    <!-- 最终模块加载验证 -->
    <!-- ===================== -->
    <script>
        // 验证所有新模块已正确加载
        (function() {
            const checks = {
                SafeMode: typeof window.SafeMode !== 'undefined',
                RecoveryMode: typeof window.RecoveryMode !== 'undefined',
                NavigationFSM: typeof window.NavigationFSM !== 'undefined',
                WaypointManager: typeof window.WaypointManager !== 'undefined',
                AutoRecovery: typeof window.AutoRecovery !== 'undefined'
            };
            const allLoaded = Object.values(checks).every(v => v === true);
            if (allLoaded) {
                console.log('✅ 所有新模块已加载完成', checks);
            } else {
                console.warn('⚠️ 部分新模块未加载', checks);
            }
        })();
    </script>
    </script>
</body>
</html>
"""

# ========== API响应辅助函数（规范要求：统一返回格式）==========
def api_success(data=None, message=None):
    """
    统一成功响应格式
    
    Args:
        data: 返回的数据（字典或列表）
        message: 可选的成功消息
    
    Returns:
        Flask Response: JSON格式的成功响应
    """
    response = {'success': True}
    if data is not None:
        response['data'] = data
    if message:
        response['message'] = message
    return jsonify(response)

def api_error(error, details=None, status_code=500):
    """
    统一错误响应格式
    
    Args:
        error: 错误消息（字符串）
        details: 可选的错误详情（字典）
        status_code: HTTP状态码（默认500）
    
    Returns:
        Flask Response: JSON格式的错误响应
    """
    response = {'success': False, 'error': str(error)}
    if details:
        response['details'] = details
    return jsonify(response), status_code

# API路由
@app.before_request
def log_request():
    """记录所有API请求"""
    if log_manager:
        try:
            endpoint = request.endpoint or request.path
            method = request.method
            user_agent = request.headers.get('User-Agent', 'Unknown')
            ip_address = request.remote_addr
            
            log_manager.log_system_event(
                event=f"API请求: {method} {endpoint}",
                metadata={
                    "endpoint": endpoint,
                    "method": method,
                    "user_agent": user_agent,
                    "ip_address": ip_address,
                    "path": request.path,
                    "args": dict(request.args)
                }
            )
        except Exception as e:
            logger.warning(f"⚠️ 记录请求日志失败: {e}")

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/recognize', methods=['POST'])
def recognize():
    """基础视觉识别"""
    try:
        if vision_engine is None:
            return api_error('视觉引擎未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        results = vision_engine.detect_and_recognize(image_np)
        
        # 记录日志
        if log_manager:
            try:
                log_manager.log_visual_event(
                    event_type="vision_recognition",
                    detection_result={
                        "detections_count": len(results.get('detections', [])),
                        "ocr_results_count": len(results.get('ocr_results', [])),
                        "processing_time": results.get('processing_time', 0)
                    },
                    system_response="视觉识别完成"
                )
            except Exception as e:
                logger.warning(f"⚠️ 记录视觉日志失败: {e}")
        
        return api_success({
            'detections': results.get('detections', []),
            'ocr_results': results.get('ocr_results', []),
            'processing_time': results.get('processing_time', 0)
        })
    except Exception as e:
        logger.error(f"识别错误: {e}", extra={"module": "api", "meta": {"endpoint": "/api/recognize"}})
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/detect/step', methods=['POST'])
def detect_step():
    """台阶检测"""
    try:
        if step_detector is None:
            return api_error('台阶检测器未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        result = step_detector.detect_step(image_np)
        
        # 记录日志
        if log_manager:
            try:
                log_manager.log_visual_event(
                    event_type="step_detection",
                    detection_result={
                        "detected": result is not None,
                        "result": result if result else None
                    },
                    system_response="台阶检测完成" if result else "未检测到台阶"
                )
            except Exception as e:
                logger.warning(f"⚠️ 记录台阶检测日志失败: {e}")
        
        return api_success({
            'step_detection': result if result else {'detected': False, 'message': '未检测到台阶'}
        })
    except Exception as e:
        logger.error(f"台阶检测错误: {e}", extra={"module": "api", "meta": {"endpoint": "/api/detect/step"}})
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/detect/signboard', methods=['POST'])
def detect_signboard():
    """标识牌检测"""
    try:
        if signboard_detector is None:
            return api_error('标识牌检测器未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        results = signboard_detector.detect_signboards(image_np)
        
        return api_success({
            'signboards': [r.to_dict() for r in results] if results else []
        })
    except Exception as e:
        logger.error(f"标识牌检测错误: {e}", extra={"module": "api", "meta": {"endpoint": "/api/detect/signboard"}})
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/detect/hazard', methods=['POST'])
def detect_hazard():
    """危险检测"""
    try:
        if hazard_detector is None:
            return api_error('危险检测器未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        # 如果可能，传递YOLO检测结果用于过滤误报
        detected_objects = []
        if vision_engine:
            try:
                vision_results = vision_engine.detect_and_recognize(image_np)
                detected_objects = vision_results.get('detections', [])
            except:
                pass
        
        results = hazard_detector.detect_hazards(image_np, detected_objects=detected_objects)
        
        # 记录日志
        if log_manager:
            try:
                log_manager.log_visual_event(
                    event_type="hazard_detection",
                    detection_result={
                        "hazards_count": len(results),
                        "hazards": [r.to_dict() for r in results[:5]]  # 只记录前5个
                    },
                    system_response=f"检测到{len(results)}个危险区域"
                )
            except Exception as e:
                logger.warning(f"⚠️ 记录危险检测日志失败: {e}")
        
        return api_success({
            'hazards': [r.to_dict() for r in results] if results else [],
            'summary': hazard_detector.get_detection_summary(results) if results else {}
        })
    except Exception as e:
        logger.error(f"危险检测错误: {e}", extra={"module": "api", "meta": {"endpoint": "/api/detect/hazard"}})
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/detect/facility', methods=['POST'])
def detect_facility():
    """公共设施检测"""
    try:
        if facility_detector is None:
            return api_error('公共设施检测器未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        results = facility_detector.detect_facility(image_np)
        
        return api_success({
            'facilities': [r.to_dict() for r in results] if results else []
        })
    except Exception as e:
        logger.error(f"公共设施检测错误: {e}", extra={"module": "api", "meta": {"endpoint": "/api/detect/facility"}})
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/detect/traffic_light', methods=['POST'])
def detect_traffic_light():
    """红绿灯检测"""
    try:
        if traffic_light_detector is None:
            return api_error('红绿灯检测器未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        result = traffic_light_detector.detect_traffic_light(image_np)
        
        return api_success({
            'traffic_light': result.to_dict() if result else None,
            'broadcast_message': result.get_broadcast_message() if result else None
        })
    except Exception as e:
        logger.error(f"红绿灯检测错误: {e}", extra={"module": "api", "meta": {"endpoint": "/api/detect/traffic_light"}})
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/detect/crowd_density', methods=['POST'])
def detect_crowd_density():
    """人群密度检测"""
    try:
        if crowd_density_detector is None:
            return api_error('人群密度检测器未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        result = crowd_density_detector.detect_density(image_np)
        
        return api_success({
            'density': result.to_dict() if result else None
        })
    except Exception as e:
        logger.error(f"人群密度检测错误: {e}", extra={"module": "api", "meta": {"endpoint": "/api/detect/crowd_density"}})
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/detect/queue', methods=['POST'])
def detect_queue():
    """排队检测"""
    try:
        if queue_detector is None:
            return api_error('排队检测器未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        result = queue_detector.detect_queue(image_np)
        
        return api_success({
            'queue': result.to_dict() if result else None
        })
    except Exception as e:
        logger.error(f"排队检测错误: {e}", extra={"module": "api", "meta": {"endpoint": "/api/detect/queue"}})
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/detect/doorplate', methods=['POST'])
def detect_doorplate():
    """门牌号识别"""
    try:
        if doorplate_reader is None:
            return api_error('门牌号识别器未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        results = doorplate_reader.read_doorplate(image_np)
        
        return api_success({
            'doorplates': [r.to_dict() for r in results] if results else []
        })
    except Exception as e:
        logger.error(f"门牌号识别错误: {e}", extra={"module": "api", "meta": {"endpoint": "/api/detect/doorplate"}})
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/map/generate', methods=['POST'])
def generate_local_map():
    """生成本地地图"""
    try:
        if local_map_generator is None:
            return api_error('本地地图生成器未初始化', status_code=500)
        
        data = request.get_json()
        dx = data.get('dx', 0.0)  # x方向移动距离（米）
        dy = data.get('dy', 0.0)  # y方向移动距离（米）
        angle_delta = data.get('angle_delta', 0.0)  # 角度变化（弧度）
        
        # 更新位置
        local_map_generator.update_position(dx, dy, angle_delta)
        
        # 如果有图片，添加地标
        if 'image' in request.files:
            file = request.files['image']
            image_np = image_to_numpy(file.read())
            if image_np is not None:
                # 检测地标（使用设施检测器）
                if facility_detector:
                    facilities = facility_detector.detect_facility(image_np)
                    for facility in facilities:
                        local_map_generator.add_landmark(
                            facility.type.value,
                            (0, 0),  # 位置需要根据实际情况计算
                            facility.label,
                            facility.confidence
                        )
        
        # 获取当前地图
        local_map = local_map_generator.get_map()
        
        return jsonify({
            'success': True,
            'map': local_map.to_dict() if local_map else None
        })
    except Exception as e:
        logger.error(f"本地地图生成错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/detect/comprehensive', methods=['POST'])
def comprehensive_detection():
    """综合检测 - 同时运行所有视觉检测模块"""
    try:
        file = request.files['image']
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        results = {}
        
        # 1. 基础视觉识别
        if vision_engine:
            try:
                vision_results = vision_engine.detect_and_recognize(image_np)
                results['vision'] = {
                    'detections': vision_results.get('detections', []),
                    'ocr_results': vision_results.get('ocr_results', [])
                }
            except Exception as e:
                results['vision'] = {'error': str(e)}
        
        # 2. 台阶检测
        if step_detector:
            try:
                step_result = step_detector.detect_step(image_np)
                results['step'] = step_result if step_result else {'detected': False}
            except Exception as e:
                results['step'] = {'error': str(e)}
        
        # 3. 标识牌检测
        if signboard_detector:
            try:
                signboards = signboard_detector.detect_signboards(image_np)
                results['signboard'] = [r.to_dict() for r in signboards] if signboards else []
            except Exception as e:
                results['signboard'] = {'error': str(e)}
        
        # 4. 危险检测
        if hazard_detector:
            try:
                # 传递YOLO检测结果用于过滤误报
                detected_objects = results.get('vision', {}).get('detections', [])
                hazards = hazard_detector.detect_hazards(image_np, detected_objects=detected_objects)
                results['hazard'] = [r.to_dict() for r in hazards] if hazards else []
            except Exception as e:
                results['hazard'] = {'error': str(e)}
        
        # 5. 公共设施检测
        if facility_detector:
            try:
                facilities = facility_detector.detect_facility(image_np)
                results['facility'] = [r.to_dict() for r in facilities] if facilities else []
            except Exception as e:
                results['facility'] = {'error': str(e)}
        
        # 6. 红绿灯检测
        if traffic_light_detector:
            try:
                traffic_light = traffic_light_detector.detect_traffic_light(image_np)
                results['traffic_light'] = traffic_light.to_dict() if traffic_light else None
            except Exception as e:
                results['traffic_light'] = {'error': str(e)}
        
        # 7. 人群密度检测
        if crowd_density_detector:
            try:
                density = crowd_density_detector.detect_density(image_np)
                results['crowd_density'] = density.to_dict() if density else None
            except Exception as e:
                results['crowd_density'] = {'error': str(e)}
        
        # 8. 排队检测
        if queue_detector:
            try:
                queue = queue_detector.detect_queue(image_np)
                results['queue'] = queue.to_dict() if queue else None
            except Exception as e:
                results['queue'] = {'error': str(e)}
        
        # 9. 门牌号识别
        if doorplate_reader:
            try:
                doorplates = doorplate_reader.read_doorplate(image_np)
                results['doorplate'] = [d.to_dict() for d in doorplates] if doorplates else []
            except Exception as e:
                results['doorplate'] = {'error': str(e)}
        
        return jsonify({
            'success': True,
            'results': results,
            'timestamp': time.time()
        })
    except Exception as e:
        logger.error(f"综合检测错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/recognize/voice', methods=['POST'])
def recognize_voice():
    """语音识别（改进版：音频格式标准化）"""
    try:
        if whisper_recognizer is None:
            return api_error('语音识别器未初始化', status_code=500)
        
        if 'audio' not in request.files:
            return api_error('未上传音频', status_code=400)
        
        # 保存临时文件
        audio_file = request.files['audio']
        mime_type = audio_file.content_type or 'audio/webm'
        
        # 保存原始音频
        with tempfile.NamedTemporaryFile(delete=False, suffix='.tmp') as tmp_file:
            audio_file.save(tmp_file.name)
            tmp_path = tmp_file.name
        
        try:
            # 音频格式转换（统一转换为WAV格式，16kHz，单声道）
            converted_path = tmp_path
            try:
                import subprocess
                import os
                
                # 检查是否需要转换（非WAV格式需要转换）
                if not mime_type.startswith('audio/wav') and not tmp_path.endswith('.wav'):
                    wav_path = tmp_path + '.wav'
                    # 使用ffmpeg转换（如果可用）
                    try:
                        subprocess.run([
                            'ffmpeg', '-i', tmp_path,
                            '-ar', '16000',  # 采样率16kHz
                            '-ac', '1',      # 单声道
                            '-f', 'wav',     # WAV格式
                            '-y',            # 覆盖输出文件
                            wav_path
                        ], check=True, capture_output=True, timeout=10)
                        converted_path = wav_path
                        logger.info(f"音频格式转换成功: {mime_type} -> WAV")
                    except (subprocess.CalledProcessError, FileNotFoundError):
                        # ffmpeg不可用，尝试直接使用（Whisper支持多种格式）
                        logger.warning("ffmpeg不可用，使用原始音频格式")
                        converted_path = tmp_path
            except Exception as e:
                logger.warning(f"音频格式转换失败，使用原始格式: {e}")
                converted_path = tmp_path
            
            # 加载模型（如果未加载）
            if not whisper_recognizer.is_loaded:
                whisper_recognizer.load_model()
            
            # 识别（使用优化的参数）
            result = whisper_recognizer.model.transcribe(
                converted_path,
                language="zh",
                task="transcribe",
                temperature=0.0,  # 降低随机性，提高一致性
                beam_size=5,      # 束搜索大小
                best_of=5,        # 候选数量
                fp16=False        # 使用FP32提高准确率（如果CPU）
            )
            
            text = result.get("text", "").strip()
            
            # 提取详细结果
            details = {
                "language": result.get("language", "zh"),
                "duration": result.get("segments", [{}])[0].get("duration", 0) if result.get("segments") else 0,
                "confidence": whisper_recognizer._calculate_confidence(result),
                "segments": [
                    {
                        "start": seg.get("start", 0),
                        "end": seg.get("end", 0),
                        "text": seg.get("text", "").strip(),
                        "confidence": 1.0 - seg.get("no_speech_prob", 0.5)
                    }
                    for seg in result.get("segments", [])
                ]
            }
            
            logger.info(f"✅ 识别成功: {text} (置信度: {details['confidence']:.2f})")
            
            # 记录日志
            if log_manager:
                try:
                    log_manager.log_voice_intent(
                        intent="voice_recognition",
                        content=text,
                        system_response="语音识别完成",
                        metadata={
                            "language": details.get("language", "zh"),
                            "confidence": details.get("confidence", 0.0),
                            "segments_count": len(details.get("segments", []))
                        }
                    )
                except Exception as e:
                    logger.warning(f"⚠️ 记录语音日志失败: {e}")
            
            return jsonify({
                'success': True,
                'text': text,
                'details': details,
                'audio_format': mime_type
            })
        finally:
            # 清理临时文件
            for path in [tmp_path, tmp_path + '.wav']:
                if os.path.exists(path):
                    try:
                        os.unlink(path)
                    except:
                        pass
    except Exception as e:
        logger.error(f"语音识别错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/tts', methods=['POST'])
def text_to_speech():
    """语音合成（支持长文本自动分段）"""
    try:
        import asyncio
        import edge_tts
        
        data = request.json
        text = data.get('text', '')
        style_str = data.get('style', 'cheerful')
        
        if not text:
            return api_error('未提供文本', status_code=400)
        
        # Edge-TTS单次请求限制：5000字符
        MAX_CHARS_PER_REQUEST = 5000
        
        # 风格映射 - rate需要是字符串格式，如"+20%"表示加快20%
        style_map = {
            'cheerful': ('zh-CN-XiaoxiaoNeural', '+20%'),  # 加快20%
            'calm': ('zh-CN-XiaoyiNeural', '-5%'),         # 减慢5%
            'urgent': ('zh-CN-XiaoxiaoNeural', '+50%'),    # 加快50%
            'empathetic': ('zh-CN-YunxiNeural', '-10%'),   # 减慢10%
            'angry': ('zh-CN-YunjianNeural', '+30%'),      # 加快30%
            'gentle': ('zh-CN-YunxiNeural', '-15%')        # 减慢15%
        }
        
        voice, rate = style_map.get(style_str, style_map['cheerful'])
        
        start_time = time.time()
        
        # ========== 快速缓存检查（优化：优先使用缓存）==========
        if fast_tts_cache:
            cached_audio = fast_tts_cache.get_cached_audio(text, voice, rate)
            if cached_audio:
                cache_time = time.time() - start_time
                logger.info(f"⚡ 缓存命中！延迟: {cache_time*1000:.0f}ms - {text[:30]}...")
                
                # 转换为base64
                audio_base64 = base64.b64encode(cached_audio).decode('utf-8')
                
                # 记录日志
                if log_manager:
                    try:
                        log_manager.log_tts_output(
                            text=text[:100] + "..." if len(text) > 100 else text,
                            success=True,
                            metadata={
                                "text_length": len(text),
                                "style": style_str,
                                "cached": True,
                                "latency_ms": cache_time * 1000
                            }
                        )
                    except Exception as e:
                        logger.warning(f"⚠️ 记录TTS日志失败: {e}")
                
                return jsonify({
                    'success': True,
                    'audio': audio_base64,
                    'cached': True,
                    'latency_ms': round(cache_time * 1000, 2)
                })
        
        # ========== 未缓存，需要生成（优化：异步保存到缓存）==========
        logger.info(f"🔄 生成新音频: {text[:30]}... (风格: {style_str})")
        def split_text(text, max_length):
            """智能分段：优先在句号、问号、感叹号处分割"""
            if len(text) <= max_length:
                return [text]
            
            segments = []
            current_segment = ""
            
            # 按句子分割（中英文标点）
            import re
            sentences = re.split(r'([。！？.!?])', text)
            
            for i in range(0, len(sentences), 2):
                sentence = sentences[i] + (sentences[i+1] if i+1 < len(sentences) else "")
                
                # 如果当前段落加上新句子不超过限制
                if len(current_segment) + len(sentence) <= max_length:
                    current_segment += sentence
                else:
                    # 保存当前段落
                    if current_segment:
                        segments.append(current_segment.strip())
                    # 如果单个句子就超过限制，强制分割
                    if len(sentence) > max_length:
                        # 按字符强制分割
                        for j in range(0, len(sentence), max_length):
                            segments.append(sentence[j:j+max_length])
                        current_segment = ""
                    else:
                        current_segment = sentence
            
            # 添加最后一段
            if current_segment:
                segments.append(current_segment.strip())
            
            return segments
        
        # 生成单段语音
        async def generate_audio_segment(segment_text):
            communicate = edge_tts.Communicate(text=segment_text, voice=voice, rate=rate)
            audio_data = b""
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    audio_data += chunk["data"]
            return audio_data
        
        # 检查是否需要分段
        text_length = len(text)
        if text_length <= MAX_CHARS_PER_REQUEST:
            # 单段处理
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            audio_data = loop.run_until_complete(generate_audio_segment(text))
            loop.close()
        else:
            # 分段处理
            logger.info(f"文本长度 {text_length} 字符，超过限制 {MAX_CHARS_PER_REQUEST}，开始分段处理")
            segments = split_text(text, MAX_CHARS_PER_REQUEST)
            logger.info(f"分为 {len(segments)} 段")
            
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            # 逐段生成并拼接
            audio_segments = []
            for i, segment in enumerate(segments):
                logger.info(f"正在合成第 {i+1}/{len(segments)} 段（{len(segment)} 字符）")
                segment_audio = loop.run_until_complete(generate_audio_segment(segment))
                audio_segments.append(segment_audio)
                # 段之间添加短暂静音（可选）
                # silence = b'\x00' * (16000 * 0.3)  # 0.3秒静音
                # audio_segments.append(silence)
            
            loop.close()
            
            # 拼接所有音频段
            audio_data = b"".join(audio_segments)
            logger.info(f"分段合成完成，总音频长度: {len(audio_data)} 字节")
        
        # 保存到缓存（后台异步，不阻塞）
        if fast_tts_cache and audio_data:
            try:
                fast_tts_cache.save_cached_audio(text, voice, rate, audio_data)
            except Exception as e:
                logger.warning(f"⚠️ 保存缓存失败: {e}")
        
        generation_time = time.time() - start_time
        
        if audio_data:
            # 转换为base64
            audio_base64 = base64.b64encode(audio_data).decode('utf-8')
            
            # 记录日志
            if log_manager:
                try:
                    log_manager.log_tts_output(
                        text=text[:100] + "..." if len(text) > 100 else text,  # 只记录前100字符
                        success=True,
                        metadata={
                            "text_length": text_length,
                            "style": style_str,
                            "cached": False,
                            "latency_ms": generation_time * 1000
                        }
                    )
                except Exception as e:
                    logger.warning(f"⚠️ 记录TTS日志失败: {e}")
            
            logger.info(f"✅ TTS生成完成，延迟: {generation_time*1000:.0f}ms")
            
            return jsonify({
                'success': True,
                'audio': audio_base64,
                'cached': False,
                'latency_ms': generation_time * 1000
            })
        else:
            return api_error('语音合成失败', status_code=500)
    except Exception as e:
        logger.error(f"TTS错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/performance/metrics', methods=['GET'])
def get_performance_metrics():
    """获取性能指标"""
    try:
        try:
            import psutil
            process = psutil.Process()
            memory_mb = process.memory_info().rss / 1024 / 1024
        except:
            memory_mb = 0
        
        # 计算延迟统计
        vision_latencies = performance_metrics.get('vision_latency', [])
        audio_latencies = performance_metrics.get('audio_latency', [])
        
        def calc_stats(latencies):
            if not latencies:
                return {'avg': 0, 'p95': 0, 'p99': 0, 'min': 0, 'max': 0, 'count': 0}
            
            sorted_latencies = sorted(latencies[-100:])  # 最近100次
            count = len(sorted_latencies)
            avg = sum(sorted_latencies) / count if count > 0 else 0
            p95_index = int(count * 0.95)
            p99_index = int(count * 0.99)
            
            return {
                'avg': round(avg, 2),
                'p95': round(sorted_latencies[p95_index] if p95_index < count else 0, 2),
                'p99': round(sorted_latencies[p99_index] if p99_index < count else 0, 2),
                'min': round(sorted_latencies[0] if count > 0 else 0, 2),
                'max': round(sorted_latencies[-1] if count > 0 else 0, 2),
                'count': count
            }
        
        vision_stats = calc_stats(vision_latencies)
        audio_stats = calc_stats(audio_latencies)
        
        # 计算FPS
        fps_history = performance_metrics.get('fps', [])
        current_fps = fps_history[-1] if fps_history else 0
        avg_fps = sum(fps_history[-30:]) / len(fps_history[-30:]) if fps_history else 0
        
        return jsonify({
            'success': True,
            'metrics': {
                'memory_mb': round(memory_mb, 2),
                'vision': vision_stats,
                'audio': audio_stats,
                'fps': {
                    'current': round(current_fps, 1),
                    'average': round(avg_fps, 1)
                },
                'degrade_level': graceful_degrader.current_level.value if graceful_degrader else 'normal'
            }
        })
    except Exception as e:
        logger.error(f"获取性能指标错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/tts/cache/stats', methods=['GET'])
def tts_cache_stats():
    """获取TTS缓存统计信息"""
    try:
        if fast_tts_cache:
            stats = fast_tts_cache.get_cache_stats()
            return api_success({
                'stats': stats
            })
        else:
            return api_error('TTS缓存系统未初始化', status_code=500)
    except Exception as e:
        logger.error(f"获取缓存统计失败: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/health', methods=['GET'])
def health():
    """健康检查"""
    return jsonify({
        'status': 'ok',
        'modules': {
            'vision_engine': vision_engine is not None,
            'step_detector': step_detector is not None,
            'signboard_detector': signboard_detector is not None,
            'hazard_detector': hazard_detector is not None,
            'whisper_recognizer': whisper_recognizer is not None,
            'tts_manager': tts_manager is not None,
            'navigation_manager': navigation_manager is not None,
            'path_planner': path_planner is not None,
            'scene_memory_system': scene_memory_system is not None,
            'facility_detector': facility_detector is not None,
            'traffic_light_detector': traffic_light_detector is not None,
            'crowd_density_detector': crowd_density_detector is not None,
            'queue_detector': queue_detector is not None,
            'doorplate_reader': doorplate_reader is not None,
            'local_map_generator': local_map_generator is not None,
            'log_manager': log_manager is not None
        }
    })

@app.route('/api/navigation/plan', methods=['POST'])
def plan_route():
    """路径规划API"""
    try:
        if path_planner is None:
            return api_error('路径规划器未初始化', status_code=500)
        
        data = request.get_json()
        start = data.get('start', '')
        destinations = data.get('destinations', [])
        
        if not start or not destinations:
            return api_error('缺少起点或目的地参数', status_code=400)
        
        if not isinstance(destinations, list):
            destinations = [destinations]
        
        result = path_planner.plan_route(start, destinations)
        
        return api_success({
            'route': result
        })
    except Exception as e:
        logger.error(f"路径规划错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/navigation/start', methods=['POST'])
def start_navigation():
    """开始导航"""
    try:
        if navigation_manager is None:
            return api_error('导航管理器未初始化', status_code=500)
        
        data = request.get_json()
        destination = data.get('destination', '')
        route_segments = data.get('route_segments')  # 可选的路径段列表
        
        if not destination:
            return api_error('缺少目的地参数', status_code=400)
        
        success = navigation_manager.start_navigation(destination, route_segments)
        
        if success:
            status = navigation_manager.get_status()
            
            # 记录日志
            if log_manager:
                try:
                    log_manager.log_navigation(
                        action="start_navigation",
                        destination=destination,
                        path_info=route_segments,
                        system_response=f"导航已启动到{destination}"
                    )
                except Exception as e:
                    logger.warning(f"⚠️ 记录导航日志失败: {e}")
            
            return api_success({
                'status': status
            })
        else:
            return api_error('导航启动失败，可能已有导航在进行中', status_code=400)
    except Exception as e:
        logger.error(f"启动导航错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/navigation/update_position', methods=['POST'])
def update_position():
    """更新位置（支持障碍检测）"""
    try:
        if navigation_manager is None:
            return api_error('导航管理器未初始化', status_code=500)
        
        data = request.get_json()
        lat = data.get('lat')
        lng = data.get('lng')
        image_data = data.get('image')  # 可选的图片数据，用于障碍检测
        
        if lat is None or lng is None:
            return api_error('缺少位置参数', status_code=400)
        
        # 如果提供了图片，进行障碍检测
        detected_hazards = None
        if image_data and hazard_detector:
            try:
                # 解码base64图片
                import base64
                image_bytes = base64.b64decode(image_data.split(',')[-1] if ',' in image_data else image_data)
                image_np = image_to_numpy(image_bytes)
                if image_np is not None:
                    # 如果可能，传递YOLO检测结果用于过滤误报
                    detected_objects = []
                    if vision_engine:
                        try:
                            vision_results = vision_engine.detect_and_recognize(image_np)
                            detected_objects = vision_results.get('detections', [])
                        except:
                            pass
                    hazards = hazard_detector.detect_hazards(image_np, detected_objects=detected_objects)
                    detected_hazards = [h.to_dict() for h in hazards] if hazards else []
            except Exception as e:
                logger.warning(f"⚠️ 障碍检测失败: {e}")
        
        navigation_manager.update_position(lat, lng, detected_hazards)
        status = navigation_manager.get_status()
        is_idle = navigation_manager.check_idle()
        
        return api_success({
            'status': status,
            'is_idle': is_idle,
            'detected_hazards': detected_hazards or []
        })
    except Exception as e:
        logger.error(f"更新位置错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/navigation/status', methods=['GET'])
def get_navigation_status():
    """获取导航状态"""
    try:
        if navigation_manager is None:
            return api_error('导航管理器未初始化', status_code=500)
        
        status = navigation_manager.get_status()
        is_idle = navigation_manager.check_idle() if status else False
        
        return api_success({
            'status': status,
            'is_idle': is_idle
        })
    except Exception as e:
        logger.error(f"获取导航状态错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/navigation/pause', methods=['POST'])
def pause_navigation():
    """暂停导航"""
    try:
        if navigation_manager is None:
            return api_error('导航管理器未初始化', status_code=500)
        
        data = request.get_json()
        reason = data.get('reason', '用户暂停')
        
        success = navigation_manager.pause_navigation(reason)
        
        if success:
            status = navigation_manager.get_status()
            return api_success({
                'status': status
            })
        else:
            return api_error('暂停失败', status_code=400)
    except Exception as e:
        logger.error(f"暂停导航错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/navigation/resume', methods=['POST'])
def resume_navigation():
    """恢复导航"""
    try:
        if navigation_manager is None:
            return api_error('导航管理器未初始化', status_code=500)
        
        success = navigation_manager.resume_navigation()
        
        if success:
            status = navigation_manager.get_status()
            return api_success({
                'status': status
            })
        else:
            return api_error('恢复失败', status_code=400)
    except Exception as e:
        logger.error(f"恢复导航错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/navigation/cancel', methods=['POST'])
def cancel_navigation():
    """取消导航"""
    try:
        if navigation_manager is None:
            return api_error('导航管理器未初始化', status_code=500)
        
        data = request.get_json()
        reason = data.get('reason', '用户取消')
        
        success = navigation_manager.cancel_navigation(reason)
        
        if success:
            status = navigation_manager.get_status()
            return api_success({
                'status': status
            })
        else:
            return api_error('取消失败', status_code=400)
    except Exception as e:
        logger.error(f"取消导航错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/navigation/complete', methods=['POST'])
def complete_navigation():
    """完成导航"""
    try:
        if navigation_manager is None:
            return api_error('导航管理器未初始化', status_code=500)
        
        success = navigation_manager.complete_navigation()
        
        if success:
            status = navigation_manager.get_status()
            return api_success({
                'status': status
            })
        else:
            return api_error('完成失败', status_code=400)
    except Exception as e:
        logger.error(f"完成导航错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/navigation/visual_guidance', methods=['POST'])
def visual_guidance():
    """实时视觉导航指引（基于摄像头画面）"""
    try:
        if vision_engine is None:
            return api_error('视觉引擎未初始化', status_code=500)
        
        if scene_memory_system is None:
            return api_error('场景记忆系统未初始化', status_code=500)
        
        file = request.files.get('image')
        if not file:
            return api_error('未上传图片', status_code=400)
        
        image_np = image_to_numpy(file.read())
        if image_np is None:
            return api_error('图片格式错误', status_code=400)
        
        start_time = time.time()
        
        # ========== 优化1: 显著性ROI提取（提高检测速度）==========
        use_roi_optimization = saliency_roi is not None
        vision_results = None
        
        if use_roi_optimization:
            try:
                # 提取高显著性区域
                roi_regions = saliency_roi.extract_roi(image_np, top_k=5)
                
                if roi_regions and len(roi_regions) > 0:
                    # 只在ROI区域进行检测（提高速度）
                    all_objects = []
                    all_texts = []
                    
                    for roi in roi_regions:
                        x, y, w, h = roi['bbox']
                        roi_image = image_np[y:y+h, x:x+w]
                        
                        if roi_image.size == 0:
                            continue
                        
                        # 在ROI区域进行检测
                        try:
                            roi_results = vision_engine.detect_and_recognize(roi_image)
                            
                            # 调整坐标（从ROI坐标转换到原图坐标）
                            for obj in roi_results.get('detections', []):
                                if 'bbox' in obj:
                                    orig_x, orig_y, orig_w, orig_h = obj['bbox']
                                    obj['bbox'] = (orig_x + x, orig_y + y, orig_w, orig_h)
                                all_objects.append(obj)
                            
                            for text in roi_results.get('ocr_results', []):
                                if 'bbox' in text:
                                    orig_x, orig_y, orig_w, orig_h = text['bbox']
                                    text['bbox'] = (orig_x + x, orig_y + y, orig_w, orig_h)
                                all_texts.append(text)
                        except Exception as e:
                            logger.warning(f"ROI区域检测失败: {e}")
                    
                    vision_results = {
                        'detections': all_objects,
                        'ocr_results': all_texts,
                        'processing_time': (time.time() - start_time),
                        'roi_optimized': True
                    }
                else:
                    # ROI提取失败，使用全图检测
                    vision_results = vision_engine.detect_and_recognize(image_np)
                    vision_results['roi_optimized'] = False
            except Exception as e:
                logger.warning(f"显著性ROI优化失败，使用全图检测: {e}")
                vision_results = vision_engine.detect_and_recognize(image_np)
                vision_results['roi_optimized'] = False
        else:
            # 未启用ROI优化，使用全图检测
            vision_results = vision_engine.detect_and_recognize(image_np)
            vision_results['roi_optimized'] = False
        
        # 1. 视觉识别：检测物体和文字（已完成）
        
        # 2. 检测关键节点（门牌、标识牌等）
        node_detector = scene_memory_system.node_detector
        detected_nodes = node_detector.detect_nodes(image_np) if node_detector else []
        
        # 3. 检测标识牌
        signboard_results = []
        if signboard_detector:
            try:
                signboard_results = signboard_detector.detect_signboards(image_np)
            except:
                pass
        
        # 4. 检测台阶和危险
        step_detected = False
        hazards_detected = []
        if step_detector:
            try:
                step_result = step_detector.detect_step(image_np)
                step_detected = step_result is not None
            except:
                pass
        
        if hazard_detector:
            try:
                # 传递YOLO检测结果，用于过滤人脸误报
                detected_objects = vision_results.get('detections', [])
                hazards_detected = hazard_detector.detect_hazards(image_np, detected_objects=detected_objects)
            except:
                pass
        
        # ========== 优化2: 时序融合（提高稳定性，减少误检）==========
        detection_data = {
            'objects': vision_results.get('detections', []),
            'texts': vision_results.get('ocr_results', []),
            'signboards': [{'type': r.type.value, 'bbox': r.bbox, 'confidence': r.confidence} 
                          for r in signboard_results] if signboard_results else [],
            'step_detected': step_detected,
            'hazards': [{'type': h.type.value, 'bbox': h.bbox, 'severity': h.severity.value, 'confidence': h.confidence}
                       for h in hazards_detected] if hazards_detected else []
        }
        
        stable_detection = detection_data  # 默认使用原始检测
        if temporal_fusion:
            try:
                stable_detection = temporal_fusion.fuse(detection_data)
                logger.debug(f"时序融合完成，稳定性得分: {stable_detection.get('stability_score', 0):.2f}")
            except Exception as e:
                logger.warning(f"时序融合失败: {e}")
        
        # 更新检测结果（使用稳定后的结果）
        vision_results['detections'] = stable_detection.get('objects', [])
        vision_results['ocr_results'] = stable_detection.get('texts', [])
        signboard_results_stable = stable_detection.get('signboards', [])
        step_detected = stable_detection.get('step_detected', step_detected)
        hazards_detected_stable = stable_detection.get('hazards', [])
        
        # ========== 优化3: 视觉-语言融合（如果有语音指令）==========
        voice_command = request.form.get('voice_command')  # 可选参数
        fusion_decision = None
        
        if voice_command and visual_language_fusion:
            try:
                fusion_detection = {
                    'objects': [{'class': obj.get('class', ''), 'bbox': obj.get('bbox', (0,0,0,0)), 
                               'confidence': obj.get('confidence', 0.0)} 
                              for obj in stable_detection.get('objects', [])],
                    'texts': [text.get('text', '') for text in stable_detection.get('texts', [])],
                    'signboards': signboard_results_stable
                }
                
                fusion_decision = visual_language_fusion.fuse(fusion_detection, voice_command)
                if fusion_decision:
                    logger.info(f"视觉-语言融合成功: {fusion_decision.get('message', '')}")
            except Exception as e:
                logger.warning(f"视觉-语言融合失败: {e}")
        
        # 5. 生成前进指引
        guidance_messages = []
        guidance_direction = "forward"  # forward, left, right, stop
        
        # 提取OCR文本（用于后续处理）
        ocr_texts = [r.get('text', '') for r in vision_results.get('ocr_results', [])]
        
        # 如果视觉-语言融合有结果，优先使用融合后的决策
        if fusion_decision:
            guidance_direction = fusion_decision.get('direction', 'forward')
            guidance_messages.append(fusion_decision.get('message', ''))
        else:
            # 分析OCR结果，查找方向指示
            all_text = ' '.join(ocr_texts).lower()
            
            # 检测方向关键词
            if any(keyword in all_text for keyword in ['左', 'left', '←']):
                guidance_direction = "left"
                guidance_messages.append("检测到左侧标识，请向左转")
            elif any(keyword in all_text for keyword in ['右', 'right', '→']):
                guidance_direction = "right"
                guidance_messages.append("检测到右侧标识，请向右转")
            elif any(keyword in all_text for keyword in ['直行', 'straight', 'forward', '↑']):
                guidance_direction = "forward"
                guidance_messages.append("请直行")
        
        # 检测门牌号/房间号
        room_numbers = []
        for text in ocr_texts:
            import re
            # 匹配房间号模式：数字+室/号/room等
            room_match = re.search(r'(\d+)[室号]|room\s*(\d+)', text, re.IGNORECASE)
            if room_match:
                room_num = room_match.group(1) or room_match.group(2)
                room_numbers.append(room_num)
        
        if room_numbers:
            guidance_messages.append(f"检测到房间号：{', '.join(room_numbers)}")
        
        # 检测标识牌（使用稳定后的结果）
        if signboard_results_stable:
            signboard_types = [r.get('type', '') for r in signboard_results_stable]
            if 'toilet' in signboard_types or 'restroom' in signboard_types:
                guidance_messages.append("检测到洗手间标识")
            if 'elevator' in signboard_types or 'lift' in signboard_types:
                guidance_messages.append("检测到电梯标识")
            if 'exit' in signboard_types or '出口' in signboard_types:
                guidance_messages.append("检测到出口标识")
        
        # 检测台阶警告
        if step_detected:
            guidance_direction = "stop"
            guidance_messages.append("⚠️ 前方有台阶，请小心")
        
        # 检测危险警告（使用稳定后的结果）
        if hazards_detected_stable:
            critical_hazards = [h for h in hazards_detected_stable if h.get('severity', '') in ['critical', 'high']]
            if critical_hazards:
                guidance_direction = "stop"
                guidance_messages.append(f"⚠️ 检测到{len(critical_hazards)}个危险区域，请谨慎前行")
        
        # 如果没有检测到明确的指引，提供通用建议
        if not guidance_messages:
            # 分析检测到的物体
            detections = vision_results.get('detections', [])
            ocr_texts = [r.get('text', '') for r in vision_results.get('ocr_results', [])]
            
            if detections:
                # 提取物体类型
                object_types = [d.get('class', '') for d in detections if d.get('class')]
                if object_types:
                    unique_types = list(set(object_types))[:3]  # 最多显示3种
                    guidance_messages.append(f"检测到前方有：{', '.join(unique_types)}，请保持直行并注意观察")
                else:
                    guidance_messages.append("检测到前方有物体，请保持直行并注意观察")
            elif ocr_texts:
                # 有文字但无明确方向
                guidance_messages.append("检测到文字信息，前方道路畅通，请继续前行")
            else:
                # 什么都没有检测到
                guidance_messages.append("前方道路畅通，请继续前行")
        
        # 记录日志
        if log_manager:
            try:
                log_manager.log_visual_event(
                    event_type="visual_guidance",
                    detection_result={
                        "direction": guidance_direction,
                        "messages": guidance_messages,
                        "nodes_detected": len(detected_nodes),
                        "signboards_detected": len(signboard_results_stable),
                        "step_detected": step_detected,
                        "hazards_detected": len(hazards_detected_stable),
                        "roi_optimized": vision_results.get('roi_optimized', False),
                        "temporal_fused": temporal_fusion is not None,
                        "visual_language_fused": fusion_decision is not None
                    },
                    system_response="视觉导航指引已生成（已应用优化）"
                )
            except Exception as e:
                logger.warning(f"⚠️ 记录视觉导航日志失败: {e}")
        
        total_time = (time.time() - start_time) * 1000
        
        # 记录性能指标
        if 'vision_latency' in performance_metrics:
            performance_metrics['vision_latency'].append(total_time)
            if len(performance_metrics['vision_latency']) > 100:
                performance_metrics['vision_latency'].pop(0)
        
        return api_success({
            'guidance': {
                'direction': guidance_direction,
                'messages': guidance_messages,
                'room_numbers': room_numbers,
                'optimizations': {
                    'roi_optimized': vision_results.get('roi_optimized', False),
                    'temporal_fused': temporal_fusion is not None,
                    'visual_language_fused': fusion_decision is not None
                },
                'detected_nodes': detected_nodes[:5],  # 只返回前5个
                'signboards': [{'type': r.get('type', ''), 'bbox': r.get('bbox', ()), 'confidence': r.get('confidence', 0.0)} 
                              for r in signboard_results_stable[:3]],  # 只返回前3个
                'step_detected': step_detected,
                'hazards_count': len(hazards_detected_stable)
            },
            'vision_summary': {
                'objects_detected': len(vision_results.get('detections', [])),
                'texts_detected': len(vision_results.get('ocr_results', [])),
                'processing_time_ms': round(total_time, 2)
            }
        })
    except Exception as e:
        logger.error(f"视觉导航指引错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/navigation/paths', methods=['GET'])
def get_available_paths():
    """获取可用路径列表"""
    try:
        if scene_memory_system is None:
            return api_error('场景记忆系统未初始化', status_code=500)
        
        paths = {}
        for path_id, path_memory in scene_memory_system.memory_mapper.memories.items():
            paths[path_id] = {
                'path_id': path_id,
                'path_name': path_memory.path_name,
                'node_count': len(path_memory.nodes),
                'nodes': [node.label for node in path_memory.nodes]
            }
        
        return jsonify({
            'success': True,
            'paths': paths
        })
    except Exception as e:
        logger.error(f"获取路径列表错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/logs/upload', methods=['POST'])
def upload_logs():
    """上传日志到后台"""
    try:
        if log_manager is None:
            return api_error('日志管理器未初始化', status_code=500)
        
        # 刷新缓冲区，确保所有日志都已写入文件
        log_manager.flush()
        
        data = request.get_json() or {}
        date = data.get('date')  # 可选，指定日期，默认今天
        
        # 读取日志
        logs = log_manager.read_logs(date=date)
        
        if not logs:
            return api_success({
                'message': '没有日志需要上传',
                'log_count': 0
            })
        
        # 准备上传数据
        upload_data = {
            'user_id': log_manager.user_id,
            'date': date or time.strftime('%Y-%m-%d'),
            'logs': logs,
            'total_count': len(logs),
            'upload_time': time.time()
        }
        
        # 这里可以添加实际上传到后台的逻辑
        # 例如：requests.post('https://api.luna.ai/logs/upload', json=upload_data)
        # 目前先保存到本地文件，供后续上传
        
        upload_file_path = f"logs/web_test/uploads/{time.strftime('%Y%m%d_%H%M%S')}_logs.json"
        os.makedirs(os.path.dirname(upload_file_path), exist_ok=True)
        
        with open(upload_file_path, 'w', encoding='utf-8') as f:
            import json
            json.dump(upload_data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"📤 日志已准备上传: {len(logs)} 条日志")
        
        return api_success({
            'message': f'日志已准备上传（{len(logs)} 条）',
            'log_count': len(logs),
            'upload_file': upload_file_path,
            'date': date or time.strftime('%Y-%m-%d')
        })
    except Exception as e:
        logger.error(f"上传日志错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/logs/realtime', methods=['GET'])
def get_realtime_logs():
    """获取实时日志（自指定时间戳之后的新日志）"""
    try:
        if log_manager is None:
            return api_error('日志管理器未初始化', status_code=500)
        
        since = request.args.get('since')  # 可选，指定时间戳
        
        # 刷新缓冲区
        log_manager.flush()
        
        # 读取日志
        logs = log_manager.read_logs()
        
        # 如果指定了since，只返回该时间戳之后的日志
        if since:
            filtered_logs = []
            for log in logs:
                if log.get('timestamp', '') > since:
                    filtered_logs.append(log)
            logs = filtered_logs
        
        # 只返回最近50条
        logs = logs[-50:]
        
        return jsonify({
            'success': True,
            'logs': logs,
            'count': len(logs)
        })
    except Exception as e:
        logger.error(f"获取实时日志错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/logs/view', methods=['GET'])
def view_logs():
    """查看日志"""
    try:
        if log_manager is None:
            return api_error('日志管理器未初始化', status_code=500)
        
        date = request.args.get('date')  # 可选日期参数
        limit = request.args.get('limit', type=int)  # 可选限制条数
        
        # 刷新缓冲区
        log_manager.flush()
        
        # 读取日志
        if date:
            logs = log_manager.read_logs(date=date, limit=limit)
            actual_date = date
        else:
            # 如果没有指定日期，尝试读取今天的日志
            logs = log_manager.read_logs(date=None, limit=limit)
            actual_date = time.strftime('%Y-%m-%d')
            
            # 如果今天没有日志，自动查找最新的日志
            if not logs:
                available_dates = log_manager.list_available_dates()
                if available_dates:
                    actual_date = available_dates[0]
                    logs = log_manager.read_logs(date=actual_date, limit=limit)
        
        return api_success({
            'logs': logs,
            'count': len(logs),
            'date': actual_date,
            'available_dates': log_manager.list_available_dates()
        })
    except Exception as e:
        logger.error(f"查看日志错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/logs/statistics', methods=['GET'])
def get_log_statistics():
    """获取日志统计信息"""
    try:
        if log_manager is None:
            return api_error('日志管理器未初始化', status_code=500)
        
        date = request.args.get('date')  # 可选日期参数
        
        # 刷新缓冲区
        log_manager.flush()
        
        # 获取统计信息
        stats = log_manager.get_statistics(date=date)
        
        return api_success({
            'statistics': stats,
            'date': date or time.strftime('%Y-%m-%d')
        })
    except Exception as e:
        logger.error(f"获取日志统计错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/api/logs/download', methods=['GET'])
def download_logs():
    """下载日志文件"""
    try:
        if log_manager is None:
            return api_error('日志管理器未初始化', status_code=500)
        
        date = request.args.get('date')  # 可选日期参数
        
        # 刷新缓冲区
        log_manager.flush()
        
        # 读取日志
        if date:
            # 如果指定了日期，读取指定日期的日志
            logs = log_manager.read_logs(date=date)
            actual_date = date
        else:
            # 如果没有指定日期，尝试读取今天的日志
            logs = log_manager.read_logs(date=None)
            actual_date = time.strftime('%Y-%m-%d')
            
            # 如果今天没有日志，自动查找最新的日志
            if not logs:
                available_dates = log_manager.list_available_dates()
                if available_dates:
                    # 使用最新的日志日期
                    actual_date = available_dates[0]
                    logs = log_manager.read_logs(date=actual_date)
                    logger.info(f"📋 今天没有日志，使用最新日志日期: {actual_date}")
                else:
                    # 完全没有日志文件
                    return api_error('没有日志数据', details={'message': '系统中暂无任何日志文件，请先使用系统功能生成日志'}, status_code=404)
        
        if not logs:
            return api_error(f'{actual_date} 没有日志数据', details={'available_dates': log_manager.list_available_dates()}, status_code=404)
        
        # 准备下载数据
        download_data = {
            'user_id': log_manager.user_id,
            'date': actual_date,
            'logs': logs,
            'total_count': len(logs),
            'export_time': time.strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # 创建临时JSON文件
        import tempfile
        import json
        temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False, encoding='utf-8')
        json.dump(download_data, temp_file, ensure_ascii=False, indent=2)
        temp_file.close()
        
        return send_file(
            temp_file.name,
            mimetype='application/json',
            as_attachment=True,
            download_name=f'luna_logs_{actual_date.replace("-", "")}.json'
        )
    except Exception as e:
        logger.error(f"下载日志错误: {e}")
        return api_error(str(e), details={"exception_type": type(e).__name__}, status_code=500)

@app.route('/install-cert')
def install_cert():
    """证书安装页面"""
    cert_install_html = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>安装SSL证书 - Luna</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-size: 28px;
        }
        .step {
            background: #f8f9fa;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 12px;
            border-left: 4px solid #667eea;
        }
        .step-number {
            display: inline-block;
            width: 30px;
            height: 30px;
            background: #667eea;
            color: white;
            border-radius: 50%;
            text-align: center;
            line-height: 30px;
            font-weight: bold;
            margin-right: 10px;
        }
        .step-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        .step-content {
            color: #666;
            line-height: 1.6;
            margin-left: 40px;
        }
        .btn {
            display: block;
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-align: center;
            border-radius: 12px;
            text-decoration: none;
            font-weight: bold;
            font-size: 18px;
            margin-top: 20px;
            transition: all 0.3s;
        }
        .btn:active {
            transform: scale(0.98);
            opacity: 0.9;
        }
        .btn-secondary {
            background: #28a745;
            margin-top: 10px;
        }
        .warning {
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            color: #856404;
        }
        .success {
            background: #d4edda;
            border: 1px solid #28a745;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            color: #155724;
        }
        .code {
            background: #f4f4f4;
            padding: 10px;
            border-radius: 6px;
            font-family: monospace;
            margin: 10px 0;
            word-break: break-all;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔒 安装SSL证书</h1>
        
        <div class="warning">
            <strong>⚠️ 重要提示：</strong><br>
            这是自签名证书，仅用于开发和测试。安装后需要在系统设置中信任证书。
        </div>
        
        <div class="step">
            <div class="step-title">
                <span class="step-number">1</span>
                下载证书文件
            </div>
            <div class="step-content">
                点击下面的按钮下载证书文件
            </div>
            <a href="/ssl/cert.pem" class="btn" download="luna-cert.pem">
                📥 下载证书文件
            </a>
        </div>
        
        <div class="step">
            <div class="step-title">
                <span class="step-number">2</span>
                安装证书
            </div>
            <div class="step-content">
                <strong>iPhone/iPad:</strong><br>
                1. 下载后，系统会提示"已下载描述文件"<br>
                2. 打开 <strong>设置</strong> > <strong>通用</strong> > <strong>VPN与设备管理</strong>（或<strong>描述文件</strong>）<br>
                3. 找到"Luna"证书，点击<strong>安装</strong><br>
                4. 输入密码确认安装
            </div>
        </div>
        
        <div class="step">
            <div class="step-title">
                <span class="step-number">3</span>
                信任证书
            </div>
            <div class="step-content">
                <strong>iPhone/iPad:</strong><br>
                1. 打开 <strong>设置</strong> > <strong>通用</strong> > <strong>关于本机</strong><br>
                2. 滚动到底部，点击 <strong>证书信任设置</strong><br>
                3. 找到"Luna"证书，打开<strong>信任开关</strong>
            </div>
        </div>
        
        <div class="step">
            <div class="step-title">
                <span class="step-number">4</span>
                访问网站
            </div>
            <div class="step-content">
                返回Safari，访问：<br>
                <div class="code">https://192.168.3.213:5001</div>
                现在应该可以正常使用了！
            </div>
            <a href="https://192.168.3.213:5001" class="btn btn-secondary">
                🌐 前往Luna测试页面
            </a>
        </div>
        
        <div class="success">
            <strong>✅ 安装完成后：</strong><br>
            • 可以使用摄像头拍照识别<br>
            • 可以使用麦克风录音识别<br>
            • 所有功能正常工作
        </div>
    </div>
</body>
</html>
    """
    return cert_install_html

@app.route('/ssl/cert.pem')
def download_cert():
    """下载证书文件"""
    cert_path = os.path.join(os.path.dirname(__file__), 'ssl', 'cert.pem')
    if os.path.exists(cert_path):
        return send_file(cert_path, mimetype='application/x-x509-ca-cert', 
                        as_attachment=True, download_name='luna-cert.pem')
    else:
        return "证书文件不存在", 404

if __name__ == '__main__':
    # 初始化所有模块
    if not init_all_modules():
        logger.warning("部分模块初始化失败，但服务器仍会启动")
    
    port = int(os.environ.get('PORT', 8080))
    
    # HTTPS配置
    ssl_cert_path = os.path.join(os.path.dirname(__file__), 'ssl', 'cert.pem')
    ssl_key_path = os.path.join(os.path.dirname(__file__), 'ssl', 'key.pem')
    use_https = os.path.exists(ssl_cert_path) and os.path.exists(ssl_key_path)
    
    logger.info(f"🚀 Luna 完整功能测试服务器启动中...")
    
    if use_https:
        # 获取本机IP地址
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
        except:
            local_ip = "localhost"
        
        logger.info(f"🔒 HTTPS模式已启用")
        logger.info(f"📱 手机访问地址: https://{local_ip}:{port}")
        logger.info(f"💻 本地访问地址: https://localhost:{port}")
        logger.info(f"⚠️  首次访问需要在手机上信任自签名证书")
        app.run(host='0.0.0.0', port=port, debug=False, ssl_context=(ssl_cert_path, ssl_key_path))
    else:
        # 获取本机IP地址
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
        except:
            local_ip = "localhost"
        
        logger.info(f"📱 手机访问地址: http://{local_ip}:{port}")
        logger.info(f"💻 本地访问地址: http://localhost:{port}")
        logger.warning(f"⚠️  HTTP模式：Safari浏览器无法使用摄像头/麦克风")
        logger.info(f"💡 提示：运行 'python3 generate_ssl_cert.py' 生成SSL证书启用HTTPS")
        app.run(host='0.0.0.0', port=port, debug=False)


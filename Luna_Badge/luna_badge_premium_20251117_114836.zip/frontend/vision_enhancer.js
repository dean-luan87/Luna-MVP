// frontend/vision_enhancer.js
/**
 * 旗舰视觉增强（YOLO六层逻辑）
 * - 多帧稳定（Stability）
 * - 伪深度估计（Pseudo-Depth）
 * - 场景分层（Scene / Geometry / Risk）
 * - 简易对象追踪（可占位实现）
 * - 环境"空场景"稳定滤波
 * - 输出统一的 visionSummary 供导航/危险逻辑使用
 */
(function () {
  'use strict';
  
  if (window.VisionEnhancer) return;

  const CENTER_REGION_RATIO = 0.5;   // 中央区域判定
  const NEAR_DISTANCE_CM = 150;      // 近距离危险阈值
  const STABILITY_WINDOW = 6;        // 多帧窗口
  const STABILITY_DANGER_THRESHOLD = 4;
  const SAFE_FRAME_WINDOW = 10;
  const SAFE_FRAME_THRESHOLD = 7;

  class StabilityFilter {
    constructor() {
      this.frames = [];
    }
    push(frame) {
      this.frames.push(frame);
      if (this.frames.length > STABILITY_WINDOW) {
        this.frames.shift();
      }
    }
    isDangerStable() {
      const count = this.frames.filter(f => f.isDangerFrame).length;
      return count >= STABILITY_DANGER_THRESHOLD;
    }
    reset() {
      this.frames = [];
    }
  }

  class SafeFrameFilter {
    constructor() {
      this.safeFrames = [];
    }
    push(isSafe) {
      this.safeFrames.push(isSafe);
      if (this.safeFrames.length > SAFE_FRAME_WINDOW) {
        this.safeFrames.shift();
      }
    }
    isStableSafe() {
      const countSafe = this.safeFrames.filter(Boolean).length;
      return countSafe >= SAFE_FRAME_THRESHOLD;
    }
    reset() {
      this.safeFrames = [];
    }
  }

  class VisionEnhancer {
    constructor() {
      this.stabilityFilter = new StabilityFilter();
      this.safeFilter = new SafeFrameFilter();
      this.suppressDangerUntil = 0;
      this.lastSummary = null;
    }

    estimateDistance(box, frameWidth, frameHeight) {
      const w = (box.x2 - box.x1);
      const h = (box.y2 - box.y1);
      const area = Math.max(w * h, 1);
      const k = 20000; // 可以后续通过标定调整
      return k / Math.sqrt(area);
    }

    isBoxCenter(block, frameWidth, frameHeight) {
      const cx = (block.x1 + block.x2) / 2;
      const cy = (block.y1 + block.y2) / 2;
      const rx = frameWidth * CENTER_REGION_RATIO / 2;
      const ry = frameHeight * CENTER_REGION_RATIO / 2;
      const centerX = frameWidth / 2;
      const centerY = frameHeight / 2;
      return (Math.abs(cx - centerX) <= rx && Math.abs(cy - centerY) <= ry);
    }

    classifyScene(detections) {
      const labels = detections.map(d => d.label || d.class || '').filter(Boolean);
      if (labels.some(l => l.includes('train') || l.includes('platform'))) return 'subway';
      if (labels.some(l => l.includes('escalator') || l.includes('shopping'))) return 'mall';
      if (labels.some(l => l.includes('car') || l.includes('bus') || l.includes('vehicle'))) return 'street';
      if (labels.some(l => l.includes('bed') || l.includes('monitor') || l.includes('chair'))) return 'indoor';
      return 'unknown';
    }

    analyzeRisk(raw) {
      const { detections, frameWidth, frameHeight } = raw;
      let hasDanger = false;
      let closestDanger = null;
      const hazards = [];

      const now = Date.now();
      const dangerSuppressed = now < this.suppressDangerUntil;

      const processed = (detections || []).map(det => {
        // 兼容不同的box格式
        const box = det.box || det.bbox || { x1: 0, y1: 0, x2: 0, y2: 0 };
        const distance = this.estimateDistance(box, frameWidth || 640, frameHeight || 480);
        const inCenter = this.isBoxCenter(box, frameWidth || 640, frameHeight || 480);
        return Object.assign({}, det, { distance, inCenter, box });
      });

      for (const det of processed) {
        const { label, class: className, distance, inCenter } = det;
        const labelStr = label || className || '';

        if (labelStr.includes('person') && distance < 100 && inCenter) {
          // 认为可能是"自己"或紧贴镜头人脸，默认不报危险
          continue;
        }

        if (distance < NEAR_DISTANCE_CM && inCenter) {
          hasDanger = true;
          hazards.push({
            label: labelStr,
            distance,
            reason: 'near_center_obstacle',
          });
          if (!closestDanger || distance < closestDanger.distance) {
            closestDanger = { label: labelStr, distance };
          }
        }
      }

      const isDangerFrame = hasDanger && !dangerSuppressed;

      this.stabilityFilter.push({ isDangerFrame });
      this.safeFilter.push(!hasDanger);

      if (this.safeFilter.isStableSafe()) {
        // 连续多帧安全 → 短时间内压制危险
        this.suppressDangerUntil = Date.now() + 1000;
      }

      const stableDanger = this.stabilityFilter.isDangerStable() && !dangerSuppressed;

      const riskLevel = stableDanger
        ? (closestDanger && closestDanger.distance < 80 ? 'high' : 'medium')
        : 'low';

      const summary = {
        ts: Date.now(),
        scene: this.classifyScene(detections || []),
        hasDangerFrame: hasDanger,
        isDangerStable: this.stabilityFilter.isDangerStable(),
        dangerSuppressed,
        riskLevel,
        closestDanger,
        hazards,
        rawDetections: processed
      };

      this.lastSummary = summary;
      return summary;
    }

    processFrame(yoloOutput) {
      try {
        const summary = this.analyzeRisk(yoloOutput);

        if (window.logDebug) {
          window.logDebug('VisionEnhancer.summary', summary);
        }

        // 将结果交给后续事件流处理
        if (window.EventFlow && window.EventFlow.onVisionSummary) {
          window.EventFlow.onVisionSummary(summary);
        }

        return summary;
      } catch (e) {
        if (window.logError) {
          window.logError('VisionEnhancer.processFrame error', { error: e.toString(), stack: e.stack });
        } else {
          console.error('VisionEnhancer.processFrame error', e);
        }
        return null;
      }
    }
  }

  window.VisionEnhancer = new VisionEnhancer();
  console.log('✅ VisionEnhancer模块加载完成', { module: 'vision_enhancer' });
})();


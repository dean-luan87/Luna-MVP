// frontend/navigation_fsm.js
/**
 * 强化版导航状态机
 * 标准化导航状态：IDLE → STARTING → ACTIVE → PAUSED → RECOVERING → FINISHED
 * 让导航事件 + 路点系统 + AutoRecovery 都知道当前状态
 */
(function () {
  'use strict';
  
  if (window.NavigationFSM && window.NavigationFSM.__upgraded) return;

  const STATES = {
    IDLE: 'IDLE',
    STARTING: 'STARTING',
    ACTIVE: 'ACTIVE',
    PAUSED: 'PAUSED',
    RECOVERING: 'RECOVERING',
    FINISHED: 'FINISHED'
  };

  const ALLOWED = {
    IDLE: ['STARTING'],
    STARTING: ['ACTIVE', 'FINISHED'],
    ACTIVE: ['PAUSED', 'FINISHED', 'RECOVERING'],
    PAUSED: ['ACTIVE', 'FINISHED'],
    RECOVERING: ['ACTIVE', 'FINISHED'],
    FINISHED: ['IDLE']
  };

  const FSM = window.NavigationFSM || {};

  FSM.state = FSM.state || STATES.IDLE;
  FSM.history = FSM.history || [];
  FSM.startTime = FSM.startTime || null;
  FSM.destination = FSM.destination || null;

  FSM._transition = function (next, meta) {
    const allowed = ALLOWED[this.state] || [];
    if (!allowed.includes(next)) {
      if (window.logWarn) {
        window.logWarn('NavigationFSM illegal transition', { from: this.state, to: next, meta });
      } else {
        console.warn('NavigationFSM illegal transition', { from: this.state, to: next, meta });
      }
      return;
    }
    const prev = this.state;
    this.state = next;
    this.history.push({ ts: Date.now(), from: prev, to: next, meta: meta || {} });
    
    if (window.logInfo) {
      window.logInfo('NavigationFSM transition', { from: prev, to: next, meta });
    } else {
      console.log('NavigationFSM transition', { from: prev, to: next, meta });
    }
  };

  FSM.start = function (meta) {
    if (this.state === STATES.IDLE) {
      this.startTime = Date.now();
      this.destination = meta && meta.destination ? meta.destination : (meta || 'unknown');
      this._transition(STATES.STARTING, meta);
      this._transition(STATES.ACTIVE, meta);
    }
  };

  FSM.pause = function (meta) {
    if (this.state === STATES.ACTIVE) {
      this._transition(STATES.PAUSED, meta);
    }
  };

  FSM.resume = function (meta) {
    if (this.state === STATES.PAUSED) {
      this._transition(STATES.ACTIVE, meta);
    }
  };

  FSM.finish = function (meta) {
    if (this.state === STATES.ACTIVE || this.state === STATES.PAUSED || this.state === STATES.RECOVERING) {
      this._transition(STATES.FINISHED, meta);
    }
  };

  FSM.reset = function (meta) {
    const prev = this.state;
    this.state = STATES.IDLE;
    this.startTime = null;
    this.destination = null;
    this.history.push({ ts: Date.now(), from: prev, to: STATES.IDLE, meta: meta || { reason: 'reset' } });
    
    if (window.logInfo) {
      window.logInfo('NavigationFSM reset', { from: prev });
    } else {
      console.log('NavigationFSM reset', { from: prev });
    }
  };

  FSM.handleEvent = function (navData) {
    // 占位：未来可按危险等级 / 偏航 / 到点规则触发状态变化
    if (window.logDebug) {
      window.logDebug('NavigationFSM.handleEvent', { state: this.state, navData });
    }
  };

  FSM.getState = function () {
    return {
      state: this.state,
      startTime: this.startTime,
      destination: this.destination,
      duration: this.startTime ? Date.now() - this.startTime : 0,
      history: this.history.slice(-10) // 最近10条历史
    };
  };

  FSM.__upgraded = true;
  window.NavigationFSM = FSM;
  
  console.log('✅ NavigationFSM模块加载完成（强化版）', { module: 'navigation_fsm' });
})();

// frontend/event_flow.js
/**
 * 视觉 × 导航 × 语音总管线
 * 把 VisionEnhancer → EventBridge → NavigationStrategy → TTS / UI / emotion_event 串成统一的总线
 */
(function () {
  'use strict';
  
  if (window.EventFlow) return;

  const EventFlow = {
    onVisionSummary(summary) {
      if (!summary) return;

      // 1. 日志记录
      if (window.logDebug) {
        window.logDebug('EventFlow.onVisionSummary', summary);
      }

      // 2. 危险流：如果稳定危险 → 派发 hazard 事件
      if (summary.isDangerStable && !summary.dangerSuppressed) {
        const payload = {
          type: 'vision_hazard',
          scene: summary.scene,
          riskLevel: summary.riskLevel,
          closestDanger: summary.closestDanger,
          hazards: summary.hazards
        };
        
        if (window.emitHazardEvent) {
          window.emitHazardEvent(payload);
        }
        
        if (window.emotion_event) {
          window.emotion_event('hazard_detected', 'high', payload);
        }
      }

      // 3. 导航流：始终发送导航"环境信息"，用于策略与路点系统
      const navPayload = {
        scene: summary.scene,
        riskLevel: summary.riskLevel,
        closestDanger: summary.closestDanger,
        hasDanger: summary.hasDangerFrame,
        rawDetections: summary.rawDetections
      };

      if (window.emitNavigationEvent) {
        window.emitNavigationEvent(navPayload);
      }

      // 4. AutoRecovery：视觉异常时可记录
      if (window.AutoRecovery && summary.riskLevel === 'low' && !summary.hasDangerFrame) {
        if (window.AutoRecovery.record) {
          window.AutoRecovery.record('vision', 'stable', { ts: summary.ts });
        }
      }
    }
  };

  window.EventFlow = EventFlow;
  console.log('✅ EventFlow模块加载完成', { module: 'event_flow' });
})();


#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
情绪地图生成器增强版 v1.2.2 (已废弃，请使用 v2_render/emotion_map_renderer.py)

⚠️ 注意：此模块已被 EmotionMap v2 取代
请使用 EmotionMap v2 架构：
- v1_core/path_struct_generator.py - 数据层
- v2_render/emotion_map_renderer.py - 表现层

生成具备方向感、中文表达、区域划分和情绪标签的高质量地图图卡

v1.2 更新：
- 增强区域色块可视性（透明度70-80%，细线边框）
- 优化节点图标显示（32x32px，节点上方位置）
- 手绘风格字体和路径抖动
- 统一情绪标注样式（气泡、圆角、圆形）
- 增强纸张背景纹理（平铺支持）

v1.2.1 优化：
- 图标显示优化（节点内/上方居中，32px）
- 字体加大加粗（主标签20-22pt，#333颜色）
- 路径抖动±3px，更自然
- 背景纹理20-30%透明度
- 添加图标图例说明（左上角）
- 元信息补充icons_used字段

v1.2.2 微调：
- 图标位置优化（节点内部中心）
- 标签增加灰底气泡（22pt）
- 图例使用真实SVG图标
- 路径颜色改为深蓝灰（避免纯黑）
- 元信息补充legend_synced、label_font_size
"""

import json
import os
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
import matplotlib.patches as mpatches
from matplotlib.bezier import BezierSegment

logger = logging.getLogger(__name__)

class EmotionalMapCardGeneratorEnhanced:
    """情绪地图生成器增强版 v1.1"""
    
    def __init__(self, 
                 memory_store_path: str = "data/memory_store.json",
                 output_dir: str = "data/map_cards",
                 icons_dir: str = "assets/icons/tabler",
                 fonts_dir: str = "assets/fonts",
                 textures_dir: str = "assets/textures"):
        """初始化增强版生成器"""
        self.memory_store_path = memory_store_path
        self.output_dir = output_dir
        self.icons_dir = icons_dir
        self.fonts_dir = fonts_dir
        self.textures_dir = textures_dir
        
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)
        
        # 初始化SVG加载器
        try:
            from core.svg_icon_loader import SVGIconLoader
            self.svg_loader = SVGIconLoader
        except ImportError:
            self.svg_loader = None
        
        # 加载中文字体（v1.2.1优化）
        self.chinese_font_small = self._load_chinese_font(size=18)
        self.chinese_font_medium = self._load_chinese_font(size=20)
        self.chinese_font_large = self._load_chinese_font(size=22)
        
        # 情绪标签颜色映射（统一样式 - v1.2优化版）
        self.emotion_colors = {
            "推荐": {"bg": (255, 182, 193), "text": (255, 255, 255), "shape": "rounded", "emoji": "❤️"},  # 粉红圆角矩形
            "安静": {"bg": (144, 238, 144), "text": (0, 100, 0), "shape": "rounded", "emoji": "🌿"},      # 绿色圆角矩形
            "担忧": {"bg": (255, 165, 0), "text": (255, 255, 255), "shape": "bubble", "emoji": "⚠️"},     # 橙色气泡
            "嘈杂": {"bg": (169, 169, 169), "text": (255, 255, 255), "shape": "circle", "emoji": "🙉"},   # 灰色实心圆
            "温馨": {"bg": (255, 200, 200), "text": (255, 255, 255), "shape": "bubble", "emoji": "💝"},  # 粉色气泡
            "拥挤": {"bg": (255, 150, 150), "text": (255, 255, 255), "shape": "rounded", "emoji": "👥"},  # 浅红圆角
            "明亮": {"bg": (255, 255, 150), "text": (100, 100, 50), "shape": "rounded", "emoji": "💡"},  # 黄色圆角
        }
        
        # 区域颜色映射（增强可视性，透明度70-80%）
        self.zone_colors = {
            "候诊区": {"color": (255, 240, 245, 180), "outline": (200, 140, 150), "outline_width": 2},
            "三楼病区": {"color": (230, 245, 255, 180), "outline": (140, 170, 200), "outline_width": 2},
            "挂号大厅": {"color": (255, 250, 240, 180), "outline": (200, 180, 140), "outline_width": 2},
            "电梯间": {"color": (245, 245, 245, 180), "outline": (180, 180, 180), "outline_width": 2},
            "入口区": {"color": (255, 240, 240, 180), "outline": (200, 140, 140), "outline_width": 2},
            "医院一楼": {"color": (245, 255, 250, 180), "outline": (180, 200, 190), "outline_width": 2},
            "医院三楼": {"color": (250, 240, 255, 180), "outline": (190, 160, 200), "outline_width": 2},
        }
        
        # 样式配置（v1.2.2优化）
        self.style = {
            "paper_color": (249, 247, 238),
            "line_color": (60, 80, 100),  # v1.2.2: 深蓝灰代替纯黑
            "node_size": 48,
            "icon_size": 32,  # 节点图标大小
            "node_thickness": 3,
            "arrow_size": 20,
            "jitter_intensity": 3,  # 手绘抖动强度±3px
            "label_color": (51, 51, 51),  # #333
            "main_label_size": 22,  # 主标签20-22pt
            "region_label_size": 18,  # 区域标签
        }
        
        logger.info("🎨 情绪地图生成器增强版 v1.1 初始化完成")
    
    def _load_chinese_font(self, size: int = 16) -> Optional[ImageFont.FreeTypeFont]:
        """加载中文字体"""
        font_paths = [
            os.path.join(self.fonts_dir, "handwriting.ttf"),
            "/System/Library/Fonts/PingFang.ttc",
            "/System/Library/Fonts/STHeiti Light.ttc",
        ]
        
        for font_path in font_paths:
            if os.path.exists(font_path):
                try:
                    return ImageFont.truetype(font_path, size)
                except:
                    continue
        
        return ImageFont.load_default()
    
    def _load_svg_icon(self, icon_name: str, size: int = 48) -> Optional[Image.Image]:
        """加载SVG图标"""
        if not self.svg_loader:
            return None
        
        icon_path = os.path.join(self.icons_dir, f"{icon_name}.svg")
        if os.path.exists(icon_path):
            try:
                icon_np = self.svg_loader.load_svg_icon(icon_path, size=size)
                if icon_np is not None:
                    return Image.fromarray(icon_np)
            except:
                pass
        
        return None
    
    def _render_zone_background(self, img: Image.Image, nodes: List[Dict], 
                                layout: Dict) -> Image.Image:
        """渲染区域背景"""
        # 按区域分组节点
        zones = {}
        for i, node in enumerate(nodes):
            level = node.get("level", "")
            if level in self.zone_colors:
                if level not in zones:
                    zones[level] = []
                zones[level].append(i)
        
        if not zones:
            return img
        
        # 绘制区域
        overlay = Image.new('RGBA', img.size, (0, 0, 0, 0))
        overlay_draw = ImageDraw.Draw(overlay)
        
        positions = layout.get("positions", [])
        
        for zone_name, zone_color_info in self.zone_colors.items():
            if zone_name not in zones:
                continue
            
            zone_indices = zones[zone_name]
            
            # 计算区域边界（简化：椭圆包围）
            if zone_indices:
                xs = [positions[i][0] for i in zone_indices]
                ys = [positions[i][1] for i in zone_indices]
                
                min_x, max_x = min(xs) - 100, max(xs) + 100
                min_y, max_y = min(ys) - 100, max(ys) + 100
                
                center_x = (min_x + max_x) // 2
                center_y = (min_y + max_y) // 2
                radius_x = (max_x - min_x) // 2
                radius_y = (max_y - min_y) // 2
                
                # 绘制椭圆背景（增强可视性）
                overlay_draw.ellipse(
                    [center_x - radius_x, center_y - radius_y,
                     center_x + radius_x, center_y + radius_y],
                    fill=zone_color_info["color"],
                    outline=zone_color_info["outline"],
                    width=zone_color_info.get("outline_width", 2)
                )
                
                # 添加柔灰色细线外圈（0.8pt效果）
                overlay_draw.ellipse(
                    [center_x - radius_x - 2, center_y - radius_y - 2,
                     center_x + radius_x + 2, center_y + radius_y + 2],
                    outline=(200, 200, 200, 100),
                    width=1
                )
                
                # 绘制区域标签
                if self.chinese_font_small:
                    bbox = overlay_draw.textbbox(
                        (0, 0), zone_name, font=self.chinese_font_small)
                    text_width = bbox[2] - bbox[0]
                    text_height = bbox[3] - bbox[1]
                    
                    overlay_draw.text(
                        (center_x - text_width//2, center_y - radius_y - text_height - 10),
                        zone_name,
                        font=self.chinese_font_small,
                        fill=(50, 50, 50))
        
        # 合成
        img = Image.alpha_composite(img.convert('RGBA'), overlay).convert('RGB')
        return img
    
    def _draw_bezier_arrow(self, draw: ImageDraw.Draw,
                          from_pos: Tuple[int, int],
                          to_pos: Tuple[int, int],
                          color: Tuple[int, int, int],
                          width: int = 2) -> None:
        """使用贝塞尔曲线绘制箭头（v1.2.2：路径颜色微调）"""
        x1, y1 = from_pos
        x2, y2 = to_pos
        
        # 创建控制点（使曲线更自然）
        dx, dy = x2 - x1, y2 - y1
        mid_x = x1 + dx * 0.5
        mid_y = y1 + dy * 0.5
        
        # 垂直偏移创建曲线
        perp = np.array([-dy, dx])
        perp_norm = perp / np.linalg.norm(perp)
        offset = perp_norm * 30
        
        ctrl_x = int(mid_x + offset[0])
        ctrl_y = int(mid_y + offset[1])
        
        # 绘制贝塞尔曲线（简化：分段绘制）
        num_points = 20
        points = []
        for i in range(num_points):
            t = i / (num_points - 1)
            x = int((1-t)**2 * x1 + 2*(1-t)*t * ctrl_x + t**2 * x2)
            y = int((1-t)**2 * y1 + 2*(1-t)*t * ctrl_y + t**2 * y2)
            points.append((x, y))
        
        # 绘制曲线（带抖动 - 增强手绘风格）
        jitter = self.style.get("jitter_intensity", 2)
        for i in range(len(points) - 1):
            x1_pt, y1_pt = points[i]
            x2_pt, y2_pt = points[i + 1]
            
            jitter_x = np.random.randint(-jitter, jitter + 1)
            jitter_y = np.random.randint(-jitter, jitter + 1)
            
            draw.line([x1_pt + jitter_x, y1_pt + jitter_y,
                      x2_pt + jitter_x, y2_pt + jitter_y],
                     fill=color, width=width)
        
        # 绘制箭头
        arrow_x, arrow_y = to_pos
        angle = np.arctan2(dy, dx)
        arrow_len = 25
        arrow_angle = np.pi / 6
        
        # 箭头顶点
        arrow_left = (
            int(arrow_x - arrow_len * np.cos(angle - arrow_angle)),
            int(arrow_y - arrow_len * np.sin(angle - arrow_angle))
        )
        arrow_right = (
            int(arrow_x - arrow_len * np.cos(angle + arrow_angle)),
            int(arrow_y - arrow_len * np.sin(angle + arrow_angle))
        )
        
        # 绘制箭头
        draw.polygon([arrow_x, arrow_y, arrow_left[0], arrow_left[1],
                     arrow_right[0], arrow_right[1]],
                    fill=color, outline=color)
    
    def _render_emotion_tags(self, draw: ImageDraw.Draw,
                            emotions: List[str],
                            position: Tuple[int, int]) -> None:
        """渲染情绪标签气泡（统一样式）"""
        x, y = position
        
        for idx, emotion in enumerate(emotions[:2]):  # 最多2个
            if emotion not in self.emotion_colors:
                continue
            
            color_info = self.emotion_colors[emotion]
            shape = color_info.get("shape", "bubble")
            emoji = color_info.get("emoji", "")
            
            tag_width = 50
            tag_height = 30
            tag_x = x + idx * (tag_width + 5)
            tag_y = y
            
            # 根据shape绘制不同形状
            if shape == "circle":
                # 实心圆（嘈杂）
                center = (tag_x + tag_width//2, tag_y + tag_height//2)
                radius = min(tag_width, tag_height) // 2 - 2
                draw.ellipse(
                    [center[0] - radius, center[1] - radius,
                     center[0] + radius, center[1] + radius],
                    fill=color_info["bg"],
                    outline=color_info["bg"]
                )
            elif shape == "rounded":
                # 圆角矩形（安静、拥挤、明亮）
                draw.rounded_rectangle(
                    [tag_x, tag_y, tag_x + tag_width, tag_y + tag_height],
                    radius=10,
                    fill=color_info["bg"],
                    outline=(220, 220, 220),
                    width=1
                )
            else:
                # 气泡（推荐、担忧、温馨）
                draw.rounded_rectangle(
                    [tag_x, tag_y, tag_x + tag_width, tag_y + tag_height],
                    radius=8,
                    fill=color_info["bg"],
                    outline=color_info["bg"]
                )
            
            # 绘制文字（emoji + 文字）
            if self.chinese_font_small:
                # 先尝试绘制emoji
                try:
                    emoji_font = ImageFont.truetype(
                        "/System/Library/Fonts/Apple Color Emoji.ttc", 16
                    )
                    bbox = draw.textbbox((0, 0), emoji, font=emoji_font)
                    text_width = bbox[2] - bbox[0]
                    
                    draw.text((tag_x + 8, tag_y + 7), emoji, font=emoji_font)
                    # 添加文字
                    draw.text((tag_x + 25, tag_y + 7), emotion,
                             font=self.chinese_font_small,
                             fill=color_info["text"])
                except:
                    # Fallback: 只显示文字
                    bbox = draw.textbbox((0, 0), emotion, font=self.chinese_font_small)
                    text_width = bbox[2] - bbox[0]
                    text_height = bbox[3] - bbox[1]
                    
                    draw.text(
                        (tag_x + (tag_width - text_width) // 2,
                         tag_y + (tag_height - text_height) // 2),
                        emotion,
                        font=self.chinese_font_small,
                        fill=color_info["text"])
    
    def _draw_compass(self, draw: ImageDraw.Draw, position: Tuple[int, int]) -> None:
        """绘制指南针"""
        x, y = position
        size = 80
        
        # 绘制外圆
        draw.ellipse([x - size, y - size, x + size, y + size],
                    outline=self.style["line_color"],
                    width=2)
        
        # 绘制方向标记
        directions = [
            ("北", (x, y - size + 15), (255, 0, 0)),  # 红色北
            ("东", (x + size - 15, y), (0, 255, 0)),  # 绿色东
            ("南", (x, y + size - 15), (0, 0, 255)),  # 蓝色南
            ("西", (x - size + 15, y), (255, 165, 0)),  # 橙色西
        ]
        
        for text, (tx, ty), color in directions:
            if self.chinese_font_small:
                bbox = draw.textbbox((0, 0), text, font=self.chinese_font_small)
                text_width = bbox[2] - bbox[0]
                text_height = bbox[3] - bbox[1]
                
                draw.text((tx - text_width//2, ty - text_height//2),
                         text,
                         font=self.chinese_font_small,
                         fill=color)
        
        # 绘制指北针
        draw.line([x, y - size + 10, x, y + size - 10],
                 fill=(255, 0, 0), width=2)
    
    def _draw_icon_legend(self, draw: ImageDraw.Draw, nodes: List[Dict], img: Image.Image) -> None:
        """绘制图标图例（v1.2.2：使用真实SVG图标）"""
        # 提取所有使用的节点类型
        node_types = set()
        node_type_map = {}  # 记录节点类型到图标的映射
        for node in nodes:
            node_type = node.get("type", "default")
            if node_type:
                node_types.add(node_type.lower())
                # 记录图标映射
                icon_name_map = {
                    "destination": "map-pin",
                    "waypoint": "map-pin",
                    "entrance": "door-enter",
                    "toilet": "toilet",
                    "elevator": "elevator",
                    "stairs": "stairs",
                    "building": "building",
                    "hospital": "hospital",
                    "registration": "info-square",
                    "reception": "user",
                    "wheelchair": "wheelchair",
                    "clinic": "hospital",
                }
                icon_name = icon_name_map.get(node_type.lower(), "map-pin")
                node_type_map[node_type.lower()] = icon_name
        
        if not node_types:
            return
        
        # 图标名称映射（中文）
        icon_name_cn = {
            "destination": "目的地",
            "waypoint": "途经点",
            "entrance": "入口",
            "toilet": "厕所",
            "elevator": "电梯",
            "stairs": "楼梯",
            "building": "建筑",
            "hospital": "医院",
            "registration": "挂号",
            "reception": "接待",
            "wheelchair": "无障碍",
            "clinic": "诊室",
        }
        
        # 从左上角开始绘制图例
        legend_x = 50
        legend_y = 100
        spacing = 35
        
        # 绘制标题
        if self.chinese_font_small:
            draw.text((legend_x, legend_y), "图例",
                     font=self.chinese_font_medium,
                     fill=self.style.get("label_color", (51, 51, 51)))
            legend_y += 35
        
        # 绘制每个图标的说明（v1.2.2：使用真实SVG）
        for idx, node_type in enumerate(sorted(node_types)[:8]):  # 最多显示8个
            if node_type in node_type_map:
                name = icon_name_cn.get(node_type, node_type)
                icon_name = node_type_map[node_type]
                
                # v1.2.2: 加载真实SVG图标
                icon_img = self._load_svg_icon(icon_name, size=20)
                icon_x = legend_x + 10
                icon_y = legend_y + idx * spacing
                
                if icon_img:
                    # 绘制真实图标
                    if icon_img.mode == 'RGBA':
                        img.paste(icon_img, (icon_x - 10, icon_y - 10), icon_img)
                    else:
                        img.paste(icon_img, (icon_x - 10, icon_y - 10))
                else:
                    # Fallback: 绘制小圆点
                    draw.ellipse([icon_x - 8, icon_y - 8, icon_x + 8, icon_y + 8],
                               fill=(100, 100, 100),
                               outline=(100, 100, 100))
                
                # 绘制文字说明
                if self.chinese_font_small:
                    draw.text((icon_x + 12, icon_y - 10),
                             name,
                             font=self.chinese_font_small,
                             fill=self.style.get("label_color", (51, 51, 51)))
    
    def _apply_paper_texture(self, img: Image.Image) -> Image.Image:
        """应用纸张纹理背景（增强版 v1.2）"""
        texture_path = os.path.join(self.textures_dir, "paper_background.png")
        
        if os.path.exists(texture_path):
            try:
                texture = Image.open(texture_path)
                
                # 如果背景纹理比画布小，则平铺
                if texture.size[0] < img.size[0] or texture.size[1] < img.size[1]:
                    # 平铺纹理
                    full_texture = Image.new('RGB', img.size, (249, 247, 238))
                    for x in range(0, img.size[0], texture.size[0]):
                        for y in range(0, img.size[1], texture.size[1]):
                            full_texture.paste(texture, (x, y))
                    texture = full_texture
                else:
                    # 缩放纹理以适配画布
                    texture = texture.resize(img.size, Image.Resampling.LANCZOS)
                
                # 创建RGBA版本
                if texture.mode != 'RGBA':
                    texture = texture.convert('RGBA')
                if img.mode != 'RGBA':
                    img = img.convert('RGBA')
                
                # 半透明叠加（v1.2.1优化：20-30%透明度）
                texture.putalpha(28)
                
                # 叠加纹理
                img = Image.alpha_composite(img, texture)
                return img.convert('RGB')
            except Exception as e:
                logger.warning(f"纹理加载失败: {e}")
                pass
        
        # Fallback: 噪声纹理
        width, height = img.size
        noise = np.random.randint(0, 50, (height, width), dtype=np.uint8)
        noise_img = Image.fromarray(noise, mode='L')
        noise_img = noise_img.filter(ImageFilter.GaussianBlur(radius=1.0))
        noise_img = noise_img.point(lambda x: int(x * 30 / 255))
        
        overlay = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        overlay.paste(noise_img, mask=noise_img)
        img = Image.alpha_composite(img.convert('RGBA'), overlay).convert('RGB')
        
        return img
    
    def _calculate_layout(self, nodes: List[Dict]) -> Dict:
        """计算节点布局"""
        num_nodes = len(nodes)
        width = 2400
        height = 1800
        
        center_x, center_y = width // 2, height // 2
        angle_step = 360 / num_nodes
        radius_base = 150
        
        positions = []
        for i in range(num_nodes):
            angle = np.radians(i * angle_step)
            radius = radius_base + i * 100
            x = int(center_x + radius * np.cos(angle))
            y = int(center_y + radius * np.sin(angle))
            positions.append((x, y))
        
        return {"positions": positions, "center": (center_x, center_y)}
    
    def generate_emotional_map(self, path_id: str) -> Optional[str]:
        """
        生成情绪地图
        
        Args:
            path_id: 路径ID
            
        Returns:
            Optional[str]: 生成的文件路径
        """
        try:
            # 加载数据
            memory_data = self._load_memory_store()
            if "paths" not in memory_data:
                logger.error("无路径数据")
                return None
            
            path_data = None
            for path in memory_data["paths"]:
                if path.get("path_id") == path_id:
                    path_data = path
                    break
            
            if not path_data:
                logger.error(f"路径不存在: {path_id}")
                return None
            
            path_name = path_data.get("path_name", path_id)
            nodes = path_data.get("nodes", [])
            
            if not nodes:
                logger.error("无节点数据")
                return None
            
            # 创建图像
            width, height = 2400, 1800
            img = Image.new('RGB', (width, height), self.style["paper_color"])
            img = self._apply_paper_texture(img)
            
            # 计算布局
            layout = self._calculate_layout(nodes)
            positions = layout["positions"]
            
            # 绘制区域背景
            img = self._render_zone_background(img, nodes, layout)
            
            # 创建绘图对象
            draw = ImageDraw.Draw(img)
            
            # 绘制标题
            title = f"情绪导航地图: {path_name}"
            if self.chinese_font_large:
                draw.text((100, 80), title,
                         font=self.chinese_font_large,
                         fill=self.style["line_color"])
            
            # 绘制路径（贝塞尔曲线+箭头）
            for i in range(len(nodes) - 1):
                from_pos = positions[i]
                to_pos = positions[i + 1]
                
                self._draw_bezier_arrow(draw, from_pos, to_pos,
                                       self.style["line_color"], width=2)
                
                # 标注距离（如果有）
                distance = nodes[i].get("distance", 0)
                if distance > 0:
                    mid_x = (from_pos[0] + to_pos[0]) // 2
                    mid_y = (from_pos[1] + to_pos[1]) // 2
                    
                    distance_text = f"{distance}米"
                    if self.chinese_font_small:
                        draw.text((mid_x - 20, mid_y - 10),
                                 distance_text,
                                 font=self.chinese_font_small,
                                 fill=(100, 100, 100))
            
            # 绘制节点
            for i, (node, position) in enumerate(zip(nodes, positions)):
                x, y = position
                
                # 绘制节点图标（SVG）- 增强版 32x32px
                node_type = node.get("type", "default")
                icon_name_map = {
                    "destination": "map-pin",
                    "waypoint": "map-pin",
                    "entrance": "door-enter",
                    "toilet": "toilet",
                    "elevator": "elevator",
                    "stairs": "stairs",
                    "building": "building",
                    "hospital": "hospital",
                    "registration": "info-square",  # 挂号处可用clipboard-text
                    "reception": "user",
                    "wheelchair": "wheelchair",
                    "clinic": "hospital",  # 诊室
                }
                icon_name = icon_name_map.get(node_type.lower(), "map-pin")
                
                # 使用icon_size（32x32）而不是node_size（v1.2.2优化）
                icon_img = self._load_svg_icon(icon_name, size=self.style["icon_size"])
                if icon_img:
                    icon_offset = self.style["icon_size"] // 2
                    # v1.2.2: 图标放在节点内部中心位置
                    if icon_img.mode == 'RGBA':
                        img.paste(icon_img, (x - icon_offset, y - icon_offset - 5), icon_img)
                    else:
                        img.paste(icon_img, (x - icon_offset, y - icon_offset - 5))
                
                # 绘制节点外圆（加粗）
                draw.ellipse([x - 30, y - 30, x + 30, y + 30],
                           outline=self.style["line_color"],
                           width=self.style["node_thickness"],
                           fill=(255, 255, 255))
                
                # 绘制节点编号
                draw.text((x - 6, y - 10), str(i + 1),
                         font=ImageFont.load_default(),
                         fill=self.style["line_color"])
                
                # 绘制中文标签（v1.2.2优化：22pt字体，灰底气泡增强）
                label = node.get("label", "")
                if label and self.chinese_font_large:
                    bbox = draw.textbbox((0, 0), label, font=self.chinese_font_large)
                    text_width = bbox[2] - bbox[0]
                    text_height = bbox[3] - bbox[1]
                    
                    # v1.2.2: 添加灰底气泡背景
                    padding = 8
                    bubble_x1 = x - text_width // 2 - padding
                    bubble_y1 = y + 40
                    bubble_x2 = x + text_width // 2 + padding
                    bubble_y2 = y + 50 + text_height
                    
                    # 绘制圆角矩形背景
                    draw.rounded_rectangle(
                        [bubble_x1, bubble_y1, bubble_x2, bubble_y2],
                        radius=6,
                        fill=(240, 240, 240, 200),  # 淡灰色半透明
                        outline=(220, 220, 220),
                        width=1
                    )
                    
                    # 使用label_color（#333）和large字体（22pt）
                    draw.text((x - text_width // 2, y + 47),
                             label,
                             font=self.chinese_font_large,
                             fill=self.style.get("label_color", (51, 51, 51)))
                
                # 绘制情绪标签
                emotions = node.get("emotion", [])
                if isinstance(emotions, str):
                    emotions = [emotions]
                elif emotions is None:
                    emotions = []
                
                if emotions:
                    self._render_emotion_tags(draw, emotions, (x - 50, y + 70))
            
            # 绘制指南针
            self._draw_compass(draw, (width - 150, 150))
            
            # 绘制图标图例（v1.2.2新增：传入img参数）
            self._draw_icon_legend(draw, nodes, img)
            
            # 保存图像
            output_path = os.path.join(self.output_dir, f"{path_id}_emotional.png")
            img.save(output_path)
            
            # 生成元信息
            meta_info = self._generate_meta_info(path_data, nodes, layout)
            meta_path = os.path.join(self.output_dir, f"{path_id}_emotional.meta.json")
            with open(meta_path, 'w', encoding='utf-8') as f:
                json.dump(meta_info, f, ensure_ascii=False, indent=2)
            
            logger.info(f"✅ 情绪地图已生成: {output_path}")
            logger.info(f"✅ 元信息已生成: {meta_path}")
            
            return output_path
            
        except Exception as e:
            logger.error(f"❌ 生成失败: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _generate_meta_info(self, path_data: Dict, nodes: List[Dict],
                           layout: Dict) -> Dict:
        """生成元信息"""
        # 提取区域
        regions = set()
        for node in nodes:
            level = node.get("level", "")
            if level and level in self.zone_colors:
                regions.add(level)
        
        # 计算总距离
        total_distance = sum(node.get("distance", 0) for node in nodes)
        
        # 检查是否使用了图标
        node_types = set()
        for node in nodes:
            node_type = node.get("type", "")
            if node_type:
                node_types.add(node_type.lower())
        
        return {
            "path_id": path_data.get("path_id"),
            "path_name": path_data.get("path_name"),
            "map_direction_reference": "上 = 北",
            "compass_added": True,
            "icons_used": True,  # v1.2.1新增
            "icon_types": list(node_types),  # v1.2.1新增
            "legend_synced": True,  # v1.2.2新增
            "label_font_size": 22,  # v1.2.2新增
            "regions_detected": sorted(list(regions)),
            "node_count": len(nodes),
            "total_distance": f"{total_distance}米",
            "generation_timestamp": __import__("datetime").datetime.now().isoformat(),
        }
    
    def _load_memory_store(self) -> Dict:
        """加载记忆存储"""
        try:
            with open(self.memory_store_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"加载失败: {e}")
            return {}

def main():
    """测试主函数"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    generator = EmotionalMapCardGeneratorEnhanced()
    result = generator.generate_emotional_map("test_emotional_path")
    
    if result:
        print(f"✅ 生成成功: {result}")

if __name__ == "__main__":
    main()


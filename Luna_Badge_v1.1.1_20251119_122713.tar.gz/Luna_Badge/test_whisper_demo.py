#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Luna Badge Whisper 完整演示
演示语音识别在不同场景中的应用
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

def demo_voice_verification():
    """演示语音验证码功能"""
    print("=" * 60)
    print("🎤 演示 1: 语音验证码输入")
    print("=" * 60)
    
    from core.voice_verification_code import VoiceVerificationCodeHandler
    
    handler = VoiceVerificationCodeHandler()
    
    print("\n场景：用户注册时需要输入6位验证码")
    print("您可以语音说出验证码，系统会自动识别并转换")
    print()
    
    # 测试中文数字转换
    test_cases = [
        ("一二三四五六", "123456"),
        ("1 2 3 4 5 6", "123456"),
        ("一二三，四五六", "123456"),
        ("壹贰叁肆伍陆", ""),  # 繁体不支持
    ]
    
    print("测试中文数字转换功能：")
    for input_text, expected in test_cases:
        result = handler._convert_chinese_numbers_to_digits(input_text)
        if expected and result == expected:
            status = "✅"
        elif expected:
            status = "⚠️"
        else:
            status = "-"
        print(f"{status} {input_text:15} → {result}")
    
    print()
    print("功能说明：")
    print("  - 支持阿拉伯数字：1 2 3 4 5 6")
    print("  - 支持中文数字：一二三四五六")
    print("  - 自动去除空格和标点")
    print()
    print()

def demo_first_boot():
    """演示首次开机流程"""
    print("=" * 60)
    print("🎤 演示 2: 首次开机账号设置")
    print("=" * 60)
    
    from core.first_boot_manager import FirstBootManager, AccountSetupFlow
    
    boot_manager = FirstBootManager()
    account_flow = AccountSetupFlow()
    
    print("\n场景：首次启动Luna设备时进行账号设置")
    print()
    
    # 检查首次开机状态
    is_first_boot = boot_manager.first_boot_check()
    print(f"首次开机状态: {'是' if is_first_boot else '否'}")
    
    if is_first_boot:
        print("\n流程说明：")
        print("  1. 用户语音选择：创建新账号 或 登录已有账号")
        print("  2. Whisper识别用户语音")
        print("  3. 根据选择执行相应流程")
        print()
        print("  example: 用户说 '创建新账号' → 系统识别 → 引导注册")
    else:
        init_time = boot_manager.get_initialization_time()
        print(f"\n设备初始化时间: {init_time}")
    
    print()
    print()

def demo_voice_commands():
    """演示语音命令识别"""
    print("=" * 60)
    print("🎤 演示 3: 语音命令识别")
    print("=" * 60)
    
    from core.voice_recognition import VoiceRecognitionEngine
    
    engine = VoiceRecognitionEngine()
    
    print("\n场景：用户通过语音控制导航")
    print()
    
    test_commands = [
        ("向前走", "前进"),
        ("停止", "停止导航"),
        ("危险", "安全警报"),
        ("靠边", "靠边行走"),
        ("减速", "减速提醒"),
        ("帮助", "求助"),
    ]
    
    print("支持的命令：")
    for text, description in test_commands:
        result = engine.recognize(text=text)
        print(f"  ✅ {description:10} - 示例：'{text}'")
    
    print()
    print("使用方式：")
    print("  用户语音 → Whisper识别 → 意图解析 → 执行命令")
    print()
    print()

def demo_whisper_features():
    """演示Whisper功能特性"""
    print("=" * 60)
    print("🎤 演示 4: Whisper功能特性")
    print("=" * 60)
    
    from core.whisper_recognizer import get_whisper_recognizer
    
    recognizer = get_whisper_recognizer()
    
    print("\n支持的识别方式：")
    print("  1. 麦克风实时录音识别")
    print("      - recognize_from_microphone(duration=5)")
    print("      - 适合交互式场景")
    print()
    print("  2. 音频文件识别")
    print("      - recognize_from_file('audio.wav')")
    print("      - 适合批量处理")
    print()
    print("  3. 音频数组识别")
    print("      - recognize_from_array(audio_array)")
    print("      - 适合程序化处理")
    print()
    
    print("返回信息包含：")
    print("  - text: 识别到的文本")
    print("  - confidence: 置信度 (0-1)")
    print("  - language: 识别到的语言")
    print("  - segments: 分段识别结果")
    print()
    print()

def main():
    """主演示函数"""
    print("\n")
    print("🎤 Luna Badge Whisper 完整演示")
    print("=" * 60)
    print()
    
    # 运行所有演示
    demo_voice_verification()
    demo_first_boot()
    demo_voice_commands()
    demo_whisper_features()
    
    print("=" * 60)
    print("✅ 演示完成")
    print("=" * 60)
    print()
    print("📝 下一步：")
    print("  运行 python test_whisper_live.py 进行实际麦克风测试")
    print("  运行 python test_whisper_integration.py 进行集成测试")
    print()

if __name__ == "__main__":
    main()


#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Luna Badge 启动流程演示
展示完整的启动流程封装
"""

import asyncio
import logging
import time
from core.startup_manager import StartupManager, StartupStage
from hal_mac.hardware_mac import MacHAL
from core.ai_navigation import AINavigation

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

class LunaBadgeStartupDemo:
    """Luna Badge 启动演示类"""
    
    def __init__(self):
        """初始化演示类"""
        self.hardware_interface = None
        self.voice_interface = None
        self.ai_navigation = None
        self.startup_manager = None
        
        logger.info("🌟 Luna Badge 启动演示初始化")
    
    async def initialize_components(self):
        """初始化组件"""
        try:
            # 初始化硬件接口
            self.hardware_interface = MacHAL()
            logger.info("✅ 硬件接口初始化完成")
            
            # 初始化语音接口
            self.voice_interface = self.hardware_interface.tts
            logger.info("✅ 语音接口初始化完成")
            
            # 初始化AI导航
            self.ai_navigation = AINavigation()
            logger.info("✅ AI导航初始化完成")
            
            return True
        except Exception as e:
            logger.error(f"❌ 组件初始化失败: {e}")
            return False
    
    def create_startup_manager(self):
        """创建启动管理器"""
        self.startup_manager = StartupManager(
            hardware_interface=self.hardware_interface,
            voice_interface=self.voice_interface
        )
        
        # 设置启动配置
        config = {
            "enable_voice_feedback": True,
            "enable_status_broadcast": True,
            "welcome_message": "Luna Badge 启动完成，准备为您服务",
            "personality_style": "friendly",
            "check_intervals": {
                "hardware_check": 2.0,
                "network_check": 3.0,
                "module_init": 1.0
            }
        }
        self.startup_manager.set_config(config)
        
        # 添加状态回调
        self.startup_manager.add_status_callback(self.on_startup_status_change)
        
        logger.info("✅ 启动管理器创建完成")
    
    def on_startup_status_change(self, status):
        """启动状态变化回调"""
        logger.info(f"📊 启动状态变化: {status.stage.value} - {status.message}")
        
        # 根据状态执行相应操作
        if status.stage == StartupStage.HARDWARE_CHECK and status.success:
            logger.info("🎥 摄像头已就绪，可以开始视觉识别")
        
        elif status.stage == StartupStage.NETWORK_CHECK and status.success:
            logger.info("🌐 网络已连接，可以访问云端服务")
        
        elif status.stage == StartupStage.WELCOME_MESSAGE and status.success:
            logger.info("👋 欢迎语播报完成，用户已收到问候")
        
        elif status.stage == StartupStage.START_RECOGNITION and status.success:
            logger.info("🔄 开始识别循环，系统进入工作状态")
    
    async def run_startup_sequence(self):
        """运行启动序列"""
        logger.info("🚀 开始运行Luna Badge启动序列")
        
        # 初始化组件
        if not await self.initialize_components():
            logger.error("❌ 组件初始化失败，无法继续启动")
            return False
        
        # 创建启动管理器
        self.create_startup_manager()
        
        # 执行完整启动序列
        start_time = time.time()
        success = await self.startup_manager.full_startup_sequence()
        end_time = time.time()
        duration = end_time - start_time
        
        if success:
            logger.info(f"🎉 Luna Badge启动序列完成！耗时: {duration:.2f}秒")
            
            # 显示启动总结
            summary = self.startup_manager.get_startup_summary()
            self.display_startup_summary(summary)
            
            return True
        else:
            logger.error("❌ Luna Badge启动序列失败！")
            return False
    
    def display_startup_summary(self, summary):
        """显示启动总结"""
        logger.info("📊 启动总结:")
        logger.info(f"  - 启动完成: {summary['startup_complete']}")
        logger.info(f"  - 总阶段数: {summary['total_stages']}")
        logger.info(f"  - 成功阶段数: {summary['successful_stages']}")
        logger.info(f"  - 成功率: {summary['success_rate']:.2%}")
        logger.info(f"  - 启动耗时: {summary['startup_duration']:.2f}秒")
        
        logger.info("📋 启动阶段详情:")
        for stage_info in summary['stages']:
            status_icon = "✅" if stage_info['success'] else "❌"
            logger.info(f"  {status_icon} {stage_info['stage']}: {stage_info['message']}")
    
    async def simulate_work_cycle(self):
        """模拟工作循环"""
        logger.info("🔄 开始模拟工作循环")
        
        # 模拟工作状态
        work_states = [
            "正在识别环境...",
            "检测到行人，请注意安全",
            "路径畅通，继续前进",
            "检测到障碍物，建议绕行",
            "到达目的地，导航结束"
        ]
        
        for i, state in enumerate(work_states):
            logger.info(f"🔄 工作状态 {i+1}: {state}")
            
            # 模拟语音播报
            if self.voice_interface:
                self.voice_interface.speak_async(state)
            
            # 等待一段时间
            await asyncio.sleep(2)
        
        logger.info("✅ 工作循环模拟完成")

async def main():
    """主函数"""
    logger.info("🌟 开始Luna Badge启动流程演示")
    
    # 创建演示实例
    demo = LunaBadgeStartupDemo()
    
    try:
        # 运行启动序列
        success = await demo.run_startup_sequence()
        
        if success:
            logger.info("🎉 启动演示成功！")
            
            # 询问是否继续工作循环模拟
            logger.info("🔄 是否继续工作循环模拟？")
            await asyncio.sleep(1)
            
            # 模拟工作循环
            await demo.simulate_work_cycle()
            
        else:
            logger.error("❌ 启动演示失败！")
    
    except KeyboardInterrupt:
        logger.info("⚠️ 用户中断演示")
    except Exception as e:
        logger.error(f"❌ 演示过程中发生错误: {e}")
    finally:
        logger.info("🏁 Luna Badge启动流程演示结束")

if __name__ == "__main__":
    # 运行演示
    asyncio.run(main())
